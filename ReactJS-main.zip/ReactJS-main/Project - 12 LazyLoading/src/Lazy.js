const Lazy = () => {
    return (
        <div>
            Lazy Loading Component
        </div>
    )
};

export default Lazy;