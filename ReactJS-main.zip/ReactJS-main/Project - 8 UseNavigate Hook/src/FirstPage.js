const FirstPage = () => {
  return (
    <div>
      You have successfully created your first navigate page using "useNavigate"
    </div>
  );
};

export default FirstPage;