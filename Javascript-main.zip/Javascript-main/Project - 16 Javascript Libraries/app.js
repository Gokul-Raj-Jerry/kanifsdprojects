//loadash

const customers = ['Kanishka', 'Priyanka', 'Latha'];

const activeCustomers = ['Kanishka', 'Priyanka'];

const inactiveCustomers = _.difference(customers, activeCustomers);

console.log(inactiveCustomers);

//jQuery

