import Footer from "../Footer/Footer";
import FooterLinks from "../Footer/FooterLinks";
import HeaderLinks from "../Header/HeaderLinks";
   
import Map from "../GoogleMap/Map";
import SocialFollow from "../SocialPlatform/SocialFollow";

const PrivacyPolicy = () => {
  const location = {
    address: '1600 Amphitheatre Parkway, Mountain View, california.',
    lat: 37.42216,
    lng: -122.08427,
  }
  return (
    <>
     <HeaderLinks />
          <div style={{ margin: 100, marginTop: 20 }}>
        <div className="text-center text-primary display-4" id="ourTeam">
        Website Privacy Policy
        </div>
        <hr />
      <div>
        
        <b>GENERAL:</b>

        <ul>
          <li>Welcome to our website.</li>
          <li>
            These Terms and Conditions (“Agreement”) govern the use of the
            website and the services provided on the website www.vibgyorhigh.com
            (“website”) (“Services”) and form the entire agreement and
            understanding between the entities who visit / browse through the
            website or subscribe to the Services (“User” / “you”) and OXFORD
            (“OXFORD” / “us” / “we”).
          </li>

          <li>
            Please read this Agreement and its terms and conditions carefully
            before using the website or the Services there under. By continuing
            to browse and use this website and / or by subscribing to the
            Services provided on the website you are agreeing to comply with and
            be bound by the terms of this Agreement which govern OXFORD’s
            relationship with you in relation to your visit / browsing this
            website and the Services which you purchase / order / procure
            through this website. If you disagree with any part of the terms
            under this Agreement then you may not access the website and / or
            the Services.
          </li>

          <li>
            OXFORD may in its sole discretion change, alter or modify this
            Agreement at any time without notice to anyone. Such changes,
            alterations or modifications shall be made effective for all users
            upon posting of the modified Agreement on this website and you are
            responsible to read this Agreement from time to time to ensure that
            your use of the Services remains in compliance with this Agreement.
          </li>
        </ul>
        <b>SERVICES:</b>
        <ul>
          <li>
            OXFORD offers the following Services, which may be modified from
            time to time:
          </li>
          <li>
            To provide the highest quality of education in a safe, secure and
            nurturing environment; to help our students develop into progressive
            thinkers and lifelong bearers of skills that will prepare them for
            the challenges of a dynamically changing world.
          </li>
        </ul>
        <b>OTHER TERMS:</b>
        <ul>
          <li>
            The content of the pages of this website and the Services are owned
            by us and not open for free use.
          </li>
          <li>
            User’s use of any information or materials on this website or the
            Services is entirely at the User’s own risk, for which we shall not
            be liable. It shall be the User’s own decision and responsibility to
            ensure that any Services availed through this website meet the
            User’s specific requirements.
          </li>

          <li>
            This website contains details of Services whose material is owned by
            or licensed to us.
          </li>

          <li>
            The information on this website is provided on an "as is" basis. We
            do not provide any warranty or guarantee as to the accuracy,
            timeliness, performance, completeness or suitability relating to the
            website or of the information and materials found or offered under
            the website for any particular purpose. You acknowledge that such
            information and materials may contain inaccuracies, omissions or
            errors and we expressly exclude liability for any such inaccuracies
            or errors to the fullest extent permitted by law.
          </li>

          <li>
            Unauthorized use of data on this website including the Services may
            give rise to a claim for damages and/or be considered, treated and
            dealt with as a criminal offence.
          </li>
          <li>
            From time to time this website may also include links to other
            websites. These links are provided for your convenience to provide
            further information. They do not signify that we endorse the
            website(s). We have no responsibility for the content of the linked
            website(s).
          </li>

          <li>
            You may not create a link to this website from another website or
            document without OXFORD’s prior written consent.
          </li>
        </ul>
        <b>
          {" "}
          PERSONAL, NON-EXCLUSIVE, NON-ASSIGNABLE AND NON-TRANSFERABLE RIGHT:{" "}
        </b>
        <ul>
          <li>
            OXFORD hereby grants to the User a personal, non-exclusive,
            non-assignable and non-transferable right to access the Services of
            OXFORD solely for personal use of the User. The User cannot grant
            access to the techniques and practices associated with OXFORD
            Services and offerings or any rights therein to any third party.
            Further, the User gives an unconditional undertaking to OXFORD that
            it shall not otherwise use or exploit OXFORD’s offering for any use
            or purpose except as expressly set forth herein.
          </li>
          <li>
            Your use of our Services provided for herein is solely for your
            personal use. Any use of OXFORD’s offerings other than the
            specified personal purposes is prohibited. Your personal use shall
            be subjected to the conditions and restrictions laid down by OXFORD
            from time to time as set forth in this Agreement.
          </li>
        </ul>
        <b> INTELLECTUAL PROPERTY RIGHTS:</b>
        <ul>
          <li>
            OXFORD is the sole and exclusive owner and retains all title,
            copyright and other proprietary rights in its offerings of all the
            material and content on this website. Any developments in any
            offering of OXFORD including without limitation inventions, design,
            layout, images, documents, files, trade secrets, photographs,
            content, graphics, sound, videos, trade-dress, trademarks, patents,
            inventions, copyright ("OXFORD Content") is the sole and exclusive
            property of OXFORD and is protected by all the applicable laws,
            including without limitation copyright, trademark, trade-names,
            patents, designs, internet domain names, data protection, IT Act,
            privacy and publicity rights and other rights and statutes. Use of
            any OXFORD Content without the prior express written permission of
            OXFORD is strictly prohibited. All rights, title, ownership,
            intellectual property rights and proprietary rights in the OXFORD
            Content shall always remain with OXFORD and shall not pass on to
            the User or any third party at any time.
          </li>
          <li>
            All information, content and material, including the software, text,
            images, graphics, video and audio and the offerings and Services are
            property of OXFORD. All intellectual property rights including but
            not limited to trademarks, service marks, trade names displayed on
            this website or under the Services are proprietary to OXFORD. No
            information, content or material under the Services may be copied,
            downloaded, reproduced, modified, republished, uploaded, posted,
            shared, disseminated, transmitted or distributed in any way without
            obtaining prior written permission from OXFORD and nothing shared
            shall be deemed to confer a license of or any other right, interest
            or title to or in any of the intellectual property rights belonging
            to OXFORD to the User.
          </li>
          <li>
            The User does not acquire any rights, express or implied other than
            those specified in this Agreement. The User agrees to secure and
            protect access and usage of OXFORD’s offerings and rights therein.
            Violation of OXFORD’s intellectual property rights shall be the
            basis for immediate termination of the Services, which shall be in
            addition to and not in lieu of any remedies available to OXFORD
            under law.
          </li>
          <li>
            The User shall make all efforts to protect the Intellectual Property
            Rights of OXFORD and in connection with the execution and
            performance under this Agreement, the User shall not infringe any
            patent, copyright, trade secret, trademark, work right or any other
            proprietary right of OXFORD.
          </li>
          <li>
            All intellectual property rights reproduced in this website which
            are not the property of or licensed to us are acknowledged.
          </li>
        </ul>
        <b>
          {" "}
          PERSONAL, NON-EXCLUSIVE, NON-ASSIGNABLE AND NON-TRANSFERABLE RIGHT:{" "}
        </b>
        <ul>
          <li>
            OXFORD hereby grants to the User a personal, non-exclusive,
            non-assignable and non-transferable right to access the Services of
            OXFORD solely for personal use of the User. The User cannot grant
            access to the techniques and practices associated with OXFORD
            Services and offerings or any rights therein to any third party.
            Further, the User gives an unconditional undertaking to OXFORD that
            it shall not otherwise use or exploit OXFORD’s offering for any use
            or purpose except as expressly set forth herein.
          </li>
          <li>
            Your use of our Services provided for herein is solely for your
            personal use. Any use of OXFORD’s offerings other than the
            specified personal purposes is prohibited. Your personal use shall
            be subjected to the conditions and restrictions laid down by OXFORD
            from time to time as set forth in this Agreement.
          </li>
        </ul>
        <b>CONFIDENTIAL INFORMATION:</b>
        <ul>
          <li>
            All information on this website including all information provided
            under the Services are the proprietary and confidential information
            belonging to OXFORD (“Confidential Information”).
          </li>
          <li>
            The User agrees that at all times the User shall not disclose,
            divulge, disseminate to and/or share with any third party the
            Confidential Information.
          </li>
          <li>
            The User agrees that User shall not duplicate, reproduce, divulge,
            share, disseminate, transmit, create derivative works or distribute
            any such Confidential Information.
          </li>
          <li>
            The secrecy of the Confidential Information disclosed pursuant to
            this Agreement shall survive the termination of this Agreement.
          </li>
          <li>
            The User agrees that through this Services offerings, the User will
            have access to and becomes acquainted with the Confidential and
            proprietary information of OXFORD and that the unauthorized use or
            disclosure and any breach of these terms and conditions would cause
            irreparable harm injury, loss, prejudice and damage, the extent of
            which would be impossible to ascertain and for which monetary
            damages would not be adequate remedy. Accordingly, the User agrees
            that, in addition to any and all legal remedies available to OXFORD
            for the User's breach of these terms and conditions, OXFORD shall
            be entitled to injunctive and other equitable relief.
          </li>
        </ul>
        <b>REMEDY FOR BREACH:</b>
        <ul>
          <li>
            In the event of breach of the terms and conditions of this Agreement
            the User shall be promptly liable to indemnify and reimburse /refund
            OXFORD for all the costs, losses and damages caused to OXFORD as a
            result of such a breach.
          </li>
          <li>
            In the event of the User’s breach of this Agreement, the User agrees
            that OXFORD will be irreparably harmed and will not have an
            adequate remedy in money or damages. OXFORD therefore, shall be
            entitled in such an event to obtain an injunction against such a
            breach from any court of competent jurisdiction immediately.
            OXFORD’s right to obtain such relief shall not limit its right to
            pursue other remedies.
          </li>
        </ul>
        <b>CONTACT US:</b>
        <ul>
          <li>In case of any query you may contact us at:</li>
          <li>Email:-mediarelations@vibgyorhigh.com</li>
          <li>Mob :- +91 7566 171 801</li>
          <li>Ph :- 022 3981 7070 (Ext. 7180)</li>
        </ul>
      </div>     </div>
      <Map location={location} zoomLevel={17} />
      <FooterLinks />
      <SocialFollow />
      <Footer />
    </>
  );
};

export default PrivacyPolicy;
