import { useEffect, useState } from "react";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {ref, uploadBytesResumable, getDownloadURL  } from "firebase/storage"

const CareerOpportunity = () => {
  const [selectedPosition, setSelectedPosition] = useState("");
  const [enteredFirstName, setEnteredFirstName] = useState("");
  const [enteredLastName, setEnteredLastName] = useState("");
  const [percent, setPercent] = useState(0);
  const [enteredMobileNumber, setEnteredMobileNumber] = useState("");
  const [enteredDOB, setEnteredDOB] = useState("");
  const [enteredPreferredLocation, setEnteredPreferredLocation] = useState("");
  const [enteredRole, setEnteredRole] = useState("");
  const [file, setFile] = useState("");
  const [enteredEmail, setEnteredEmail] = useState("");
  let [selectedGender, setSelectedGender] = useState("");
  const [enteredCurrentLocation, setEnteredCurrentLocation] = useState("");
  const [enteredDepartment, setEnteredDepartment] = useState("");
  const [selectedPreviouslyApplied, setSelectedPreviouslyApplied] = useState("");
  const [formIsValid, setFormIsValid] = useState(false);
  const notify = () => toast("Your application submitted Successfully🥳");

  useEffect(()=> {
    if(
      enteredCurrentLocation && 
      enteredDOB && 
      enteredDepartment && 
      enteredEmail && 
      enteredFirstName && 
      enteredLastName && 
      enteredMobileNumber && 
      enteredPreferredLocation && 
      enteredRole 
    ) {
      setFormIsValid(true)
    } else {
      setFormIsValid(false)
    }
  },[
    enteredCurrentLocation,
    enteredDOB, 
    enteredDepartment,
    enteredEmail,
    enteredFirstName,
    enteredLastName,
    enteredMobileNumber,
    enteredPreferredLocation,
    enteredRole
  ]);

  const careerFormHandler = async(event) => {
    event.preventDefault();
    notify()
    const careerForm = {
      position: selectedPosition,
      firstName: enteredFirstName,
      lastName: enteredLastName,
      mobileNumber: enteredMobileNumber,
      dob: enteredDOB,
      preferredLocation: enteredPreferredLocation,
      role: enteredRole,
      resume: file,
      gender: selectedGender,
      email: enteredEmail,
      currentLocation: enteredCurrentLocation,
      department: enteredDepartment,
      previouslyEmployed: selectedPreviouslyApplied
    }
 console.log(careerForm)

    try {
      await fetch("https://homepageform-default-rtdb.firebaseio.com/careerForm.json", {
        method: 'POST',
        body: JSON.stringify(careerForm)
      })
    } catch(err) {
      if(err) throw new err;
    }
    setEnteredCurrentLocation("");
    setEnteredDOB("");
    setEnteredDepartment("");
    setEnteredEmail("");
    setEnteredFirstName("");
    setEnteredLastName("");
    setEnteredMobileNumber("");
    setEnteredPreferredLocation("");
    setSelectedGender("");
    setSelectedPosition("");
    setSelectedPreviouslyApplied("");
    setFile("");
    setEnteredRole("");
    setSelectedGender("");
    setSelectedPosition("");
    setSelectedPreviouslyApplied("");
  };


function handleChange(event) {
  setFile(event.target.files[0]);
}


  return (
    <>
      <div style={{ margin: 100, marginTop: 50 }}>
        <div className="text-center text-primary display-4" id="ourTeam">
          Careers @Vibgyor
        </div>
        <hr />
        <div>
          <p>
            At VIBGYOR we believe, in meeting the professional expectations of
            our employees as well as giving them a career path that helps meet
            their aspirations. With our vision to create and nurture the hidden
            potential of each child and make them leaders for tomorrow, we
            envision developing "Teachers that create future Leaders". We at
            VIBGYOR provide unending possibilities of growth to our employees
            and recognize the importance of continuous enhancement of knowledge,
            skills and capabilities. We are committed to evolving our approach
            and methodologies to meet global standards of education. VIBGYOR by
            its virtue and foundation brings across the highest standards of
            values, integrity and ethics in its people and work functions which
            is a benchmark across the industry. To process the application
            accurately, candidates will have to follow the following steps to
            apply online :
          </p>
          <div style={{ backgroundColor: "skyblue" }} class="card">
            <div class="card-body">
              <form onSubmit={careerFormHandler}>
                <div class="form-group">
                  <input type="radio" name="button" value={selectedPosition} onChange={e=>setSelectedPosition("Academic Positions")}/>
                  &nbsp; Academic Positions
                 &nbsp; <input type="radio" name="button" value={selectedPosition} onChange={e=>setSelectedPosition("Non-Academic Positions")}/>
                 &nbsp; Non-Academic Positions
                  &nbsp; <input type="radio" name="button" value={selectedPosition} onChange={e=>setSelectedPosition("Sports and Performing Arts")}/>
                  &nbsp; Sports and Performing Arts <br /> <br />
                  <label>First Name</label>
                  <input
                  value={enteredFirstName}
                  onChange={e=>setEnteredFirstName(e.target.value)}
                    type="text"
                    placeholder="First Name"
                    class="form-control"
                  />{" "}
                  <br />
                  <br />
                  <label>Last Name</label>
                  <input
                  value={enteredLastName}
                  onChange={e=>setEnteredLastName(e.target.value)}
                    type="text"
                    placeholder="Last Name"
                    class="form-control"
                  />{" "}
                  <br />
                  <br />
                  <label>Mobile Number</label>
                  <input
                    type="text"
                    value={enteredMobileNumber}
                  onChange={e=>setEnteredMobileNumber(e.target.value)}
                    placeholder="Mobile Number"
                    class="form-control"
                  />
                  <br />
                  <br />
                  <label>DOB</label>
                  <input 
                  value={enteredDOB}
                  onChange={e=>setEnteredDOB(e.target.value)}
                  type="date" placeholder="Date" class="form-control" />
                  <br />
                  <br />
                  <label>Preferred Location</label>
                  <input
                  value={enteredPreferredLocation}
                  onChange={e=>setEnteredPreferredLocation(e.target.value)}
                    type="text"
                    placeholder="Preferred Location"
                    class="form-control"
                  />
                  <br />
                  <br />
                  <label>Roles</label>
                  <input 
                  value={enteredRole}
                  onChange={e=>setEnteredRole(e.target.value)}
                  type="text" placeholder="Role" class="form-control" />
                  <br />
                  <br />
                  <label>Upload Resume</label>
                  <input 
                /*   value={file} */
                  /* value={enteredResume} */
                  onChange={handleChange}
                  type="file" class="form-control"
                  accept=""
                   />
                  <br />
                  <br />
                  <label>Gender</label>&nbsp;&nbsp;
                  <input id="gender"
                  value={selectedGender}

                  onChange={()=>setSelectedGender("Male")}
                  type="radio" name="radbutton"/>
                  &nbsp;   Male &nbsp;
                  <input 
                  value={selectedGender}
                  onChange={()=>setSelectedGender("Female")}
                  type="radio" name="radbutton"/>
                  &nbsp;  Female <br />
                  <br />
                  <br />
                  <label>Email</label>
                  <input 
                  value={enteredEmail}
                  onChange={e=>setEnteredEmail(e.target.value)}
                  type="text" placeholder="Email" class="form-control" />
                  <br />
                  <br />
                  <label>Current Location</label>
                  <input
                  value={enteredCurrentLocation}
                  onChange={e=>setEnteredCurrentLocation(e.target.value)}
                    type="text"
                    placeholder="Current Location"
                    class="form-control"
                  />
                  <br />
                  <br />
                  <label>Department</label>
                  <input
                  value={enteredDepartment}
                  onChange={e=>setEnteredDepartment(e.target.value)}
                    type="text"
                    placeholder="Department"
                    class="form-control"
                  />
                  <br />
                  <br />
                  <label>Previously Applied/employed</label> &nbsp;   
                  <input type="radio" 
                  name="previouslyApplied"
                  value={selectedPreviouslyApplied}
                  onChange={()=>setSelectedPreviouslyApplied("Yes")}/>
                  &nbsp;      Yes
                  &nbsp;    <input type="radio" 
                  name="previouslyApplied"
                  value={selectedPreviouslyApplied}
                  onChange={()=>setSelectedPreviouslyApplied("No")}/>   
                  &nbsp;      No <br />
                  <br />
                </div>
                <div className="text-center">
                <button disabled={!formIsValid} type="submit" class="btn btn-primary mb-2"> Submit </button><br />
                </div>
                <br />
              </form>
            </div> <ToastContainer />
          </div>
        </div>
      </div>
    </>
  );
};

export default CareerOpportunity;
