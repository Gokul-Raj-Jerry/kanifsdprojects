import ProudImage from "../../Resources/ProudC.jpg";

const ProudOxfordian = () => {
  return (
    <>
      {" "}
      <div style={{ margin: 100, marginTop: 20 }}>
        <div className="text-center text-primary display-4" id="ourTeam">
          I am a proud VIBGYORian
        </div>
        <hr />
        <div>
          <div className="row">
            <div className="container">
              <div className="col-md-12">
                <img style={{ height: 250, width: 1100 }} src={ProudImage} alt="about-us" />{" "}
              </div>
            </div>
          </div>
        </div>{" "}
      </div>
    </>
  );
};

export default ProudOxfordian;
