import * as Icon from "react-bootstrap-icons";

const CareerLinks = () => {
  return (
    <div className="p-2 bg-danger text-white text-center"> 
      <a
        style={{
          textDecoration: "none",
       /*    fontSize: 30, */
          color: "white",
          marginTop: 2,
        }}
        href="#are-you-the-one"
      >
        Are You The "One"?
      </a>
      <Icon.Dot />
      <a
        style={{
          textDecoration: "none",
      /*     fontSize: 30, */
          color: "white",
          marginTop: 2,
        }}
        href="#life-at-vibgyor"
      >
        Life @Vibgyor
      </a>
      <Icon.Dot />
      <a
        style={{
          textDecoration: "none",
      /*     fontSize: 30, */
          color: "white",
          marginTop: 2,
        }}
        href="#grow-at-vibgyor"
      >
        Grow @Vibgyor
      </a>
  {/*     <Icon.Dot /> */}<br/>
      <a
        style={{
          textDecoration: "none",
        /*   fontSize: 30, */
          color: "white",
          marginTop: 2,
        }}
        href="#proud-vibgyorian"
      >
        I am a proud VIBGYORian
      </a>
      <Icon.Dot />
      <a
        style={{
          textDecoration: "none",
  /*         fontSize: 30, */
          color: "white",
          marginTop: 2,
        }}
        href="#career-at-vibgyor"
      >
        Careers @Vibgyor
      </a>
    </div>
  );
};

export default CareerLinks;