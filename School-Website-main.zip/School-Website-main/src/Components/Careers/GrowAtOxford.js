import Grow1 from "../../Resources/Grow1.jpg";

const GrowAtOxford = () => {

  return (
    <>      <div style={{ margin: 100, marginTop: 20 }}>
    <div className="text-center text-primary display-4" id="ourTeam">
    Grow Vibgyor
    </div>
    <hr />
      <div>
        <p>
          Choose a career path that lets you be the Changemaker! At VIBGYOR
          Group of Schools, we allow you to join a community of teachers who not
          only impart classroom knowledge but also inspire and mentor future
          entrepreneurs, innovators, business leaders, policymakers and
          activists, and so on.
        </p>
        <p>Learning and Career Enhancement</p>
        <ul>
          <li>TNI: Talent Need Identification Sessions/Workshops</li>
          <li>Teacher Training</li>
          <li>Internal Job Promotions</li>
          <li>Be a part of illustrious clubs and programmes under V-EMBARK</li>
          <li>Participate in VIBGYOR Model United Nations</li>
          <li>
            Interact with eminent authors as a part of VIBGYOR Greader’s Club
          </li>
          <li>
            Participate in social causes and several social engagement
            activities through VSSRC
          </li>
          <li>Go on nature trails with VNC – VIBGYOR Nature Club</li>
        </ul>
        <div className="row">
          <div className="container">
            <div className="col-md-12 text-center">
              <img style={{ height: 500 }} src={Grow1} alt="about-us" />
            </div>
          </div>
        </div>
      </div> </div>
    </>
  );
};

export default GrowAtOxford;
