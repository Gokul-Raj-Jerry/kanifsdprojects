import AreYouTheOneImage from "../../Resources/AreYouTheOne.png";

const AreYouTheOne = () => {

  return (
    <>
          <div style={{ margin: 100, marginTop: 20 }}>
        <div className="text-center text-primary display-4" id="ourTeam">
        Are You The “One”?
        </div>
        <hr />
      <div>
        <p>
          Teachers are the torchbearers of change. They are the ones who remove
          the darkness of ignorance and help their students to achieve
          knowledge. Every day, they create an atmosphere where children can
          explore their capabilities and hone their talent. They create a whole
          new world with the wonders of Science and the majesty of Mathematics.
          They guide students to appreciate the beauty of Arts and Language
          along with the goodness of humanities. At VIBGYOR Group of Schools,
          our teachers help build a strong foundation, where students aspire to
          achieve greater heights. Our teachers make students believe in
          themselves and are constantly working towards imparting knowledge to
          students to make them more mature, talented individuals so that they
          can become citizens of the world. Our teachers are here to make a
          difference! Do you see yourself being a part of this dynamic world?
          Come, let’s talk!
        </p>
        <div className="row">
          <div className="container">
            <div className="col-md-12 text-center">
              <img
                style={{ height: 250, width: 500 }}
                src={AreYouTheOneImage}
                alt="about-us"
              />
            </div>
          </div>
        </div> <br/>
        <p>
          The services we provide under our Inclusive Education programme
          include:
        </p>
        <ul>
          <li>Educational assistance for students with special needs.</li>
          <li>Psycho-educational assessments.</li>
          <li>Therapeutic-counselling services and remediation programme.</li>
        </ul>
        <p>Curriculum based ‘life skills programme’.</p>
        <ul>
          <li>Vocational guidance programme.</li>
          <li>
            Workshops, awareness and training programmes for the school
            community.
          </li>
        </ul>
      </div>  </div>
    </>
  );
};


export default AreYouTheOne;