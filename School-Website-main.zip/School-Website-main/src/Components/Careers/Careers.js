import Footer from "../Footer/Footer";
import FooterLinks from "../Footer/FooterLinks";
import HeaderLinks from "../Header/HeaderLinks";
import Map from "../GoogleMap/Map";
import SocialFollow from "../SocialPlatform/SocialFollow";
import CareerLinks from "./CareerLinks";
import { useLocation } from "react-router-dom";
import AreYouTheOne from "./AreYouTheOne";
import LifeatOxford from "./LifeatOxford";
import CareerOpportunity from "./CareerOpportunity";
import ProudOxfordian from "./ProudOxfordian";
import GrowAtOxford from "./GrowAtOxford";

const Careers = () => {
  const currentUrl = useLocation();

  const location = {
    address: "1600 Amphitheatre Parkway, Mountain View, california.",
    lat: 37.42216,
    lng: -122.08427,
  };
  return (
    <>
      <div>
        <HeaderLinks />
        <div className="row">
          <div className="container">
            <div className="col-md-12">
              <img
                className="img-fluid w-100"
                style={{ height: 500 }}
                src="https://plus.unsplash.com/premium_photo-1663091656583-07083378132b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1yZWxhdGVkfDE2fHx8ZW58MHx8fHx8&w=1000&q=80"
                alt="about-us"
              />
              <div className="mb-100">
                <h1
                  class="carousel-caption"
                  style={{
                    color: "black",
                    fontFamily: "unset",
                    fontSize: 90,
                    top: 170,
                    bottom: "auto",
                    left: -325,
                    fontWeight: "bolder",
                  }}
                >
                  Careers @Vibgyor
                </h1>
              </div>
            </div>
          </div>
        </div>
        <CareerLinks />
        {/*  <AreYouTheOne/>  */}
        {currentUrl.hash === "" ? (
          <>
            <AreYouTheOne />
          </>
        ) : (
          <></>
        )}
        {currentUrl.hash === "#are-you-the-one" /* || "/careers" */ ? (
          <AreYouTheOne />
        ) : (
          <></>
        )}
        {currentUrl.hash === "#life-at-vibgyor" ? <LifeatOxford /> : <></>}
        {currentUrl.hash === "#grow-at-vibgyor" ? <GrowAtOxford /> : <></>}
        {currentUrl.hash === "#proud-vibgyorian" ? <ProudOxfordian /> : <></>}
        {currentUrl.hash === "#career-at-vibgyor" ? (
          <CareerOpportunity />
        ) : (
          <></>
        )}
      </div>
      <Map location={location} zoomLevel={17} />
      <FooterLinks />
      <SocialFollow />
      <Footer />
    </>
  );
};

export default Careers;
