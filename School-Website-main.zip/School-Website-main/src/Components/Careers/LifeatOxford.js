import LifeImage from "../../Resources/LifeatK.jpg";

const LifeatOxford = () => {

  return (
    <>
          <div style={{ margin: 100, marginTop: 20 }}>
        <div className="text-center text-primary display-4" id="ourTeam">
        Life @Vibgyor
        </div>
        <hr />
      <div>
        <p>
          Life at VIBGYOR Group of Schools is a mix of fun, learning and growth.
          With events like Viva, VIBGYORMUN, Arts and Sport Education,
          creativity and knowledge go hand-in-hand. On the whole, there is never
          a dull moment in VIBGYOR Group of Schools. We are sure you will only
          add to the colours @VIBGYOR Group of Schools.
        </p>
        <div className="row">
          <div className="container">
            <div className="col-md-12">
              <img
                style={{ height: 250, width: 1100 }}
                src={LifeImage}
                alt="about-us"
              />{" "}
            </div>
          </div>
        </div>
        </div>      </div>
    </>
  );
};

export default LifeatOxford;
