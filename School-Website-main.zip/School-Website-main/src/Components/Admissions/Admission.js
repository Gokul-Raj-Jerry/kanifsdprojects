import Footer from "../Footer/Footer";
import FooterLinks from "../Footer/FooterLinks";
import HeaderLinks from "../Header/HeaderLinks";
import Map from "../GoogleMap/Map";
import SocialFollow from "../SocialPlatform/SocialFollow";
import { useEffect, useState } from "react";
import Select from "react-select";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
const gradeOptions = [
  { value: "nursery", label: "Nursery" },
  { value: "lkg", label: "LKG" },
  { value: "ukg", label: "UKG" },
  { value: "i", label: "I" },
  { value: "ii", label: "II" },
  { value: "iii", label: "III" },
  { value: "iv", label: "IV" },
  { value: "v", label: "V" },
  { value: "vi", label: "VI" },
  { value: "vii", label: "VII" },
  { value: "viii", label: "VIII" },
  { value: "ix", label: "IX" },
  { value: "x", label: "X" },
];

const cityOptions = [
  { value: "bangalore", label: "Bangalore" },
  { value: "chennai", label: "Chennai" },
  { value: "mumbai", label: "Mumbai" },
];


const Admission = () => {
  const [selectedCity, setSelectedCity] = useState("");
  const [selectedGrade, setSelectedGrade] = useState("");
  const [enteredName, setEnteredName] = useState("");
  const [enteredEmail, setEnteredEmail] = useState("");
  const [formIsValid, setFormIsValid] = useState(false);
  const [enteredMobile, setEnteredMobile] = useState("");
  const [enteredMessage, setEnteredMessage] = useState("");
  const notify = () => toast("Your admission inquiry is  submitted successfully");

  const location = {
    address: "1600 Amphitheatre Parkway, Mountain View, california.",
    lat: 37.42216,
    lng: -122.08427,
  };

  useEffect(()=> {
    if(
      enteredEmail &&
      enteredMessage && 
      enteredMobile && 
      enteredName && 
      selectedCity &&
      selectedGrade
    ) {
      setFormIsValid(true)
    } else {
      setFormIsValid(false)
    }
  })

  const submitHandler = async (event) => {
    event.preventDefault();
    notify()

    const inquiryForm = {
      city: selectedCity,
      grade: selectedGrade,
      name: enteredName,
      email: enteredEmail,
      mobile: enteredMobile,
      inquiry: enteredMessage,
    };
    try {
      await fetch(
        "https://homepageform-default-rtdb.firebaseio.com/admissionInquiry.json",
        {
          method: "POST",
          body: JSON.stringify(inquiryForm),
        }
      );
    } catch (err) {
      if (err) throw new err();
    }
    setEnteredEmail("")
    setEnteredMessage("")
    setEnteredMobile("")
    setEnteredName("")
    setSelectedCity("")
    setSelectedGrade("")
  };
  return (
    <>
      <div>
        <HeaderLinks />
        <div style={{ margin: 100, marginTop: 20 }}>
          <div className="text-center text-primary display-4" id="ourTeam">
            To download the Admission Process please submit the following
            details
          </div>
          <hr />
          <p className="text-center">
            The step-by-step process involved in the admission process. VIBGYOR
            Group of Schools is one of India’s leading chain of schools. We
            understand your dilemma of going through a tedious online admission
            process and have designed a few simple steps to complete the school
            admission procedure. <br />
          </p>
          <b>Step 1:</b> Parents fill the Enquiry Form on our website, choosing
          the branch of preference. <br />
          <b>Step 2:</b> Upon submission of the Enquiry Form, the parents will
          receive communication regarding their location and contact details for
          the next steps. <br />
          <b>Step 3:</b> Our school counselor will connect with the parent over
          call and share information about the school, fee structure, virtual
          counseling or phone counseling, campus visit, etc.
          <br /> <br />
          <form onSubmit={submitHandler}>
            <div class="form-group"></div>
            <label for="school">Choose your school:</label>
            <Select
            options={cityOptions}
              value={selectedCity}
              onChange={(e) => setSelectedCity(e)}
              class="form-control"
              name="school"
              id="school"
            />
             
            <br />
            <label>Full Name</label>
            <input
              value={enteredName}
              onChange={(e) => setEnteredName(e.target.value)}
              class="form-control"
              type="text"
              placeholder="Full Name"
            />
            <br />
            <label>Email</label>
            <input
              value={enteredEmail}
              onChange={(e) => setEnteredEmail(e.target.value)}
              class="form-control"
              type="email"
              placeholder="Email"
            />
            <br />
            <label>Contact Number</label>
            <input
              value={enteredMobile}
              onChange={(e) => setEnteredMobile(e.target.value)}
              class="form-control"
              type="number"
              placeholder="Contact Number"
            />
            <br />
            <label for="school">Select Grade</label>
            <Select
            options={gradeOptions}
              value={selectedGrade}
              onChange={(event) => setSelectedGrade(event)}
              class="form-control"
             /*  name="school" */
              id="school"
            />
            <br />
            <label>Message</label>
            <textarea
              value={enteredMessage}
              onChange={(e) => setEnteredMessage(e.target.value)}
              class="form-control"
              placeholder="Enter admission query"
            >
              Message
            </textarea>
            <br />
            <div className="text-center">
            <button 
            disabled={!formIsValid}
            type="submit" class="btn btn-primary  text-center">
              Submit
            </button>
            </div>
          </form>
        </div> <ToastContainer />
      </div>
      <Map location={location} zoomLevel={17} />
      <FooterLinks />
      <SocialFollow />
      <Footer />
    </>
  );
};

export default Admission;