import React from "react";
import GoogleMapReact from "google-map-react";
import { Icon } from "@iconify/react";
import locationIcon from "@iconify/icons-mdi/map-marker";
import "./styles.css";

const LocationPin = ({ text }) => {
  return (
    <div className="pin">
      <Icon icon={locationIcon} className="pin-icon" />
      <p className="pin-text">{text}</p>
    </div>
  );
};

const Map = ({ location, zoomLevel }) => (
  <>
    <div className="map">
      <h3
        style={{ fontWeight: "bold" }}
        className="p-2 mb-0 mt-0 bg-secondary text-white text-left firstHeader"
      >
        Vibgyor Schools
      </h3>

      <div className="google-map">
        <GoogleMapReact
          bootstrapURLKeys={{ key: "AIzaSyDct12hToVRWMpbeXhjHzzFSlm95dAae0c" }}
          defaultCenter={location}
          defaultZoom={zoomLevel}
        >
        {/*   <LocationPin
            lat={location.lat}
            lng={location.lng}
            text={location.address}
          /> */}
        </GoogleMapReact>
      </div>
    </div>  <br/>   
  </>
);

export default Map;