import React from "react";
import { useNavigate } from "react-router-dom";
import * as Icon from "react-bootstrap-icons";
import logoImage from "../../Resources/Logo.png";
import AdmissionsOpen from "../../Resources/AdmissionsOpen.png";


const FirstHeader = () => {
  const navigate = useNavigate();
  const newsletterButtonHandler = () => {
    navigate("/newsLetter");
  };
  const month = ["January","February","March","April","May","June","July","August","September","October","November","December"];

  const d = new Date();
  let name = month[d.getMonth()];
  return (
    <React.Fragment>
      <div style={{ fontFamily : 'mvBoli '}} className="p-0 mb-0 mt-0 bg-warning text-black text-left firstHeader">
        <img
          style={{ fontFamily : 'mv-boli', width: 404, height: 100 }}
          src={logoImage}
          alt="Logo"
        />  &nbsp; &nbsp; #NewsletterAlert - Vibgyor Buzz {name} Released &nbsp;
        <button
          type="button"
          onClick={newsletterButtonHandler}
          className="btn btn-primary"
        >
          View Now <Icon.ArrowRight />
        </button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <img
          style={{ width: 466.5, height: 100 }}
          src={AdmissionsOpen}
          alt="Logo"
        />
        </div>
    </React.Fragment>
  );
};

export default FirstHeader;
