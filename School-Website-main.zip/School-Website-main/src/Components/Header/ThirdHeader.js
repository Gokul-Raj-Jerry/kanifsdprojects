import { Link, useNavigate } from "react-router-dom";
import * as Icon from "react-bootstrap-icons";

const ThirdHeader = () => {
  const navigate = useNavigate();
  const admissionHandler = () => {
    navigate("/admission");
  };
  return (
    <>
      <div className="p-2 bg-primary text-danger text-center">
        <Link
          style={{ fontFamily: "algerian",textDecoration: "none" }}
          className="link-light"
          to="/academics"
        >
          ACADEMICS
          <Icon.Dot />
        </Link>{" "}
        &nbsp;&nbsp;
        <Link
          style={{ fontFamily: "algerian",textDecoration: "none" }}
          className="link-light"
          to="/holisticDevelopment"
        >
          HOLISTIC DEVELOPMENT
          <Icon.Dot />
        </Link>
        &nbsp;&nbsp;
        <Link
          style={{ fontFamily: "algerian",textDecoration: "none" }}
          className="link-light"
          to="/newsLetter"
        >
          NEWS & EVENTS
          <Icon.Dot />
        </Link>
        &nbsp;&nbsp;
        <Link
          style={{ fontFamily: "algerian",textDecoration: "none" }}
          className="link-light"
          to="/admission"
        >
          ADMISSION ENQUIRY
        </Link>
        &nbsp;&nbsp;
        {/*    <Link className="link-light">INFRASTRUCTURE <Icon.Dot/></Link>&nbsp;&nbsp; */}
        {/*         <Link className="link-light">ALUMNI ASSOCIATION <Icon.Dot/></Link>&nbsp;&nbsp; */}
        <button style={{ fontFamily: "baskerville" ,textDecoration: "none" }} type="button" className="btn btn-light btn-sm" onClick={admissionHandler}>Admissions Open <Icon.RocketTakeoff/></button>
      </div>
    </>
  );
};

export default ThirdHeader;
