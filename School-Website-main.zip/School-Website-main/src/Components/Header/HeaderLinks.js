
import FirstHeader from "./FirstHeader";
import SecondHeader from "./SecondHeader";
import ThirdHeader from "./ThirdHeader";
const HeaderLinks = () => {
    return (
        <>
        <FirstHeader/>
        <SecondHeader/>
        <ThirdHeader/>
        </>
    )
}

export default HeaderLinks;