import { Link } from "react-router-dom";
import * as Icon from "react-bootstrap-icons";
const SecondHeader = () => {
  return (
    <>
      <div className="p-2 bg-danger text-danger text-center">
        <Link 
          className="link-light"
          style={{ fontFamily: "algerian", textDecoration: 'none' }}
          to="/home"
        >
          HOME
          <Icon.Dot />
        </Link>{" "}
        &nbsp;&nbsp;
        <Link style={{fontFamily: "algerian",textDecoration: 'none'}} className="link-light" to="/aboutUs">
          ABOUT US
          <Icon.Dot />
        </Link>
        &nbsp;&nbsp;
        <Link style={{fontFamily: "algerian",textDecoration: 'none'}} className="link-light" to="/why-vibgyor">
          WHY VIBGYOR?
          <Icon.Dot />
        </Link>
        &nbsp;&nbsp;
        {/*   <Link className="link-light">KANISHKA HIGH <Icon.Dot/></Link>&nbsp;&nbsp;
        <Link className="link-light">KANISHKA RISE <Icon.Dot/></Link>&nbsp;&nbsp;
        <Link className="link-light">RESULTS <Icon.Dot/></Link>&nbsp;&nbsp; */}
        <Link style={{fontFamily: "algerian",textDecoration: 'none'}} className="link-light" to="/careers">
          CAREERS
          <Icon.Dot />
        </Link>
        &nbsp;&nbsp;
        <Link style={{fontFamily: "algerian",textDecoration: 'none'}} className="link-light" to="/contactUs">
          CONTACT US
          <Icon.Dot />
        </Link>
        &nbsp;&nbsp;
        <Link style={{fontFamily: "algerian",textDecoration: 'none'}} className="link-light" to="/studentLogin">
          STUDENT LOGIN
          <Icon.Dot />
        </Link>
        &nbsp;&nbsp;
        <Link style={{fontFamily: "algerian",textDecoration: 'none'}} className="link-light" to="/staffLogin">
          STAFF LOGIN
          <Icon.Dot />
        </Link>
        &nbsp;&nbsp;
        <Link style={{fontFamily: "algerian",textDecoration: 'none'}} className="link-light" to="/parentLogin">
          PARENT LOGIN
          <Icon.Dot />
        </Link>
        &nbsp;&nbsp;
        <Link style={{fontFamily: "algerian",textDecoration: 'none'}} className="link-light" to="/signUp">
          SIGN UP
       
        </Link>
        &nbsp;&nbsp;
        <Link style={{fontFamily: "algerian", textDecoration: 'none'}} className="link-light" to="tel:8861972120">
          <Icon.Telephone/>&nbsp;
          Call Us Now
        </Link>
      </div>
    </>
  );
};

export default SecondHeader;
