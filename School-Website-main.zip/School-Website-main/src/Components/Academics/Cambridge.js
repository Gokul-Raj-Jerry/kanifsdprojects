import CambridgeImage from "../../Resources/Cambridge.png";

const Cambridge = () => {
  return (
    <>
      <div style={{ margin: 100, marginTop: 20 }}>
        <div className="text-center text-primary display-4" id="ourTeam">
          University of Cambridge Assessment International Education (Cambridge
          International)
        </div>
        <hr />
        <div className="text-center">
          <img src={CambridgeImage} alt="cbse" />
        </div>
        <br />
        <div
          data-bs-spy="scroll"
          data-bs-target="#navbar-example2"
          data-bs-offset="0"
          class="scrollspy-example"
          tabindex="0"
        >
          <div class="container">
            <div class="row">
              <div class="col">
                <p style={{ fontSize: 14, fontFamily: "italic" }}>
                  At OXFORD High we offer the Cambridge International curriculum
                  with a broad range of internationally recognised
                  qualifications. University of Cambridge Assessment
                  International Education (Cambridge International) is the
                  world's most popular international qualification taken in over
                  160 countries.
                  <br />
                  <br /> The Cambridge Assessment International Education for 19
                  year olds is divided into four stages:
                  <br />
                  <br />{" "}
                  <ul>
                    <li>Cambridge International Primary Programme (CIPP)</li>
                    <li>Secondary 1/ Checkpoint</li>
                    <li>Secondary 2/ IGCSE</li>
                    <li>Cambridge International A Levels</li>
                  </ul>{" "}
                  Our Cambridge International-certified facilitators/teachers
                  offering personalised guidance and mentoring to our students
                  enrich the Cambridge International curriculum at OXFORD High.
                  The facilitators at OXFORD undergo C.I.D.T.T. (Cambridge
                  International Diploma for Teachers and Trainers), face-to-face
                  and online training. Moreover, national and international
                  seminars and conferences enable our teachers to stay updated
                  on the marking schemes, examiners report etc.
                  <br />
                  <br /> At OXFORD High, our students get:
                  <br />
                  <br />
                  State-of-the-art facilities like the ICT Lab with supervised
                  Internet connectivity, science and math labs, classrooms that
                  are conducive to learning Well-equipped library facilitates
                  the international curriculum. Interactive whiteboards and
                  other audio-visual aids that further supplement classroom
                  teaching. At OXFORD, we advocate a teaching approach based on
                  positive achievement, which is brought out through a variety
                  of strategies like teacher-led class learning, group and
                  individual work, games and imaginative play, and practical
                  work.
                  <br />
                  <br /> These strategies address different learning styles, as
                  well as the development of thinking skills, independence,
                  risk-taking and creativity. The field trips and educational
                  visits, industrial exposure and the domestic and international
                  trips organised by the school further offer an experiential
                  learning opportunity to our young scholars.
                  <br />
                  <br /> <b>Cambridge International Primary Programme (CIPP)</b>
                  <br /> <br /> The CIPP curriculum of OXFORD High is based on
                  the ideas, theories and practices that are prevalent
                  internationally. It is a comprehensive provision for teaching,
                  learning and assessing in the core subjects for children aged
                  between 5 to 11 years. <br /> <br />
                  The Primary programme covers the core subjects of English,
                  Math and Science, developing essential skills in literacy,
                  numeracy and scientific enquiry. This programme also covers a
                  good knowledge base, giving students a larger platform for
                  growth and learning. <br /> <br />
                  As per CIPP, Science framework begins at Stage 3/Grade 3,
                  after the child achieves basic literacy and numeracy skills.
                  To cover subject areas for Social Science like Community
                  Living, Our Environment, and so on, we have developed a unique
                  curriculum called OXFORD Concepts or V Concepts. <br /> <br />
                  V Concepts is an effective curriculum, which develops
                  knowledge, skills and understanding in three key areas:{" "}
                </p>
              </div>
              <div className="col">
                <p style={{ fontSize: 14, fontFamily: "italic" }}>
                  <ul>
                    <li>Academics</li>
                    <li>Personal Development</li>
                    <li>International Understanding</li>
                  </ul>
                  The goal of V-concepts is to provide a holistic education and
                  develop the skills necessary to prepare our students for
                  academics and prepare them for the challenges of a dynamically
                  changing world. <br />
                  <br />
                  <b>Secondary 1/ Checkpoint:</b> <br /> <br />
                  The Secondary 1/Checkpoint curriculum at VIBGYOR High provides
                  natural progression from Cambridge Primary and develops our
                  students’ knowledge and skills in Math, English and Science.
                  Cambridge Lower Secondary Programme is part of the Cambridge
                  Secondary 1 stage. <br /> <br />
                  Cambridge Secondary 1 offers a curriculum framework for
                  educational success typically for learners in the age bracket
                  of 11-14 years. It also provides excellent preparation for our
                  learners embarking on Cambridge Secondary 2 (IGCSE). We offer
                  the core subjects - English, Math and Science - as per the
                  curriculum framework given by the Cambridge International. For
                  this, we refer to checkpoint textbooks recommended by
                  Cambridge International. Students’ language skills are further
                  enriched through training in national and foreign languages.
                  The subject of Social Studies lays emphasis on developing
                  students’ understanding of their environment and deepening
                  their reverence for the rich geographical wealth and the
                  glorious historical heritage of our country. Students are
                  further equipped with technical skills through the study of
                  Information and Communication Technology. <br /> <br />
                  Cambridge Checkpoint tests are taken at the end of Cambridge
                  Secondary 1. It is an innovative new diagnostic testing
                  service marked by Cambridge International. It provides schools
                  with an external international benchmark for student
                  performance. <br /> <br />
                  <b>Secondary 2/ IGCSE</b>
                  <br />
                  <br /> At VIBGYOR High we offer the Secondary 2/IGCSE
                  curriculum. The International General Certificate of Secondary
                  Education (IGCSE) is the world's most popular international
                  qualification for students in the age group of 14 to 16 years.
                  It develops students' skills in creative thinking, enquiry and
                  problem solving, and gives them excellent preparation for the
                  next stage in their education. <br />
                  <br />
                  We offer a combination of subjects catering to the Science and
                  Commerce streams. Each subject is certificated separately,
                  offering a variety of routes for learners of different
                  abilities. It is used as a preparation for:
                  <br />
                  <br />
                  <ul>
                    <li>A Level</li>
                    <li>AS</li>
                    <li>International Baccalaureate</li>
                    <li>US Advanced Placement courses</li>
                  </ul>
                </p>
              </div>
            </div>
          </div>
        </div>
        <img
          className="img-fluid w-100"
          style={{ height: 200 }}
          src="https://www.vibgyorhigh.com/images/philosophy.jpg"
          alt="about-us"
        />
      </div>
    </>
  );
};

export default Cambridge;
