import CISEImage from "../../Resources/CISE.png";

const CISE = () => {
  return (
    <>
      <div style={{ margin: 100, marginTop: 20 }}>
        <div className="text-center text-primary display-4" id="ourTeam">
        Council For The Indian School Certificate Examinations (CISCE)
        </div>
        <hr />
      <div className="text-center">
        <img src={CISEImage} alt="cbse" />
      </div>
      <br/>
      
      <div
              data-bs-spy="scroll"
              data-bs-target="#navbar-example2"
              data-bs-offset="0"
              class="scrollspy-example"
              tabindex="0"
            >
      <div class="container">
                <div class="row">
                  <div class="col">
                  <p style={{ fontSize: 14, fontFamily: "italic" }}>
        At VIBGYOR High, we offer the Council For The Indian School Certificate
        Examinations (CISCE) curriculum to our students. The unique part of this
        curriculum is that it is strategically moulded to include VIBGYOR
        philosophy and the learning objectives laid down by the CISCE board. <br/><br/>If
        you are looking at the best ICSE schools near me, definitely the OXFORD
        High school, which is nearby to your location should be considered. <br/><br/>Our
        curriculum framework is flexible and activity-based, which aids in
        strengthening the students’ essential understanding over the years.<br/><br/> The
        development of our curriculum is based on the application of four basic
        principles: <br/><ul><li>Defining appropriate learning objectives</li><li>Establishing useful
        learning experiences</li><li>Organising learning experiences to have a maximum
        cumulative effect</li><li>Evaluating the curriculum and revising certain aspects
        and concepts to suit the needs of the students.</li><li>The curriculum revision
        is an ongoing process to make it more effective.</li></ul><br/>The CISCE (Council For
        The Indian School Certificate Examinations) curriculum at VIBGYOR High
        caters to students in the age group of 6-15 years. It is primarily
        divided into 2 groups: <br/><br/><b>Primary Level -- Grade 1 to 4 - Secondary Level
        -- Grade 5 to 10 </b><br/><br/>Both the Primary and Secondary levels of our CISCE
        curriculum are based on the following approaches: <ul><li>Integrated Curriculum</li>
        <li>Experiential Learning</li><li>Research Work</li><li>Professional Talk</li></ul>
          <b>Integrated
        Curriculum</b>  <br/><br/>The Integrated Curriculum Approach is a vital part of our
        teaching. For instance, subjects like Social Science are integrated with
        Social Studies, Environmental Education and Science. Social Science
        would therefore have topics like the Physical Features of India, Food
        and the Digestive System, Simple Machines, Safety and First Aid, and
        Community Helpers. Life skills lessons also form a key part of the
        curriculum. </p></div>
         <div className="col"><p style={{ fontSize: 14, fontFamily: "italic" }}> 
       <b>Experiential Learning:</b><br/>  <br/> 
Experiential learning is emphasised through making models of kaleidoscopes, poster 
making on movement in plants, scrap booking on the role of chemistry in our lives, creating HTML documents, 
making PowerPoint presentations on a renowned author or preparing a picture glossary in geography.<br/> <br/> 
On a regular basis, VIBGYOR High organises field trips to the zoo, botanical/nature 
parks, museum/places of historical interest, and science centres. The objective of 
these trips is to give the students hands-on knowledge, understanding and experience.<br/> <br/> 
<b>Research Work:</b><br/> <br/> 
We also encourage research-based work, and guide students to prepare case studies, 
which helps them to get deeper understanding of the subject.<br/> <br/> 
<b>Professional Talk</b>
We organise professional talks by industry personnel to enhance the students’ 
understanding on various topics. This helps students to get a first-hand view 
of the subject and understand the intricacies behind it.<br/> <br/> 
<b>Home Notes:</b>
Keeping up with the VIBGYOR philosophy, home notes for Grades 5 to 7 have been 
designed for students’ needs, abilities and interest. This comes as a welcome 
alternative to the prescribed textbooks. All our home notes have been carefully 
crafted and graded in consonance with the objectives of CISCE curriculum.<br/> <br/> 
For Grades 8 to 10, we have chosen the best-recommended textbooks and study 
materials that align with the CISCE objectives. The implementation of various 
units is planned with the use of various strategies as well as teaching aids, making 
learning an overall rich experience.<br/> <br/> 
<b>Assessment:</b><br/> <br/> 
The assessment patterns come as a breath of fresh air. At VIBGYOR, we focus 
on stress-free tools of assessment for each term. These tests have been creatively 
designed to not only assess the cognitive skills of children, but also their values and 
creativity. All these systems and methods ensure a holistic approach to education and learning.
      </p>   </div></div></div></div> <img
                className="img-fluid w-100"
                style={{ height: 200 }}
                src="https://www.vibgyorhigh.com/images/philosophy.jpg"
                alt="about-us"
              /> </div>
    </>
  );
};

export default CISE;