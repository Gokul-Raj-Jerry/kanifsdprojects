import Footer from "../Footer/Footer";
import FooterLinks from "../Footer/FooterLinks";
import HeaderLinks from "../Header/HeaderLinks";
import Map from "../GoogleMap/Map";
import SocialFollow from "../SocialPlatform/SocialFollow";
import CBSEImage from "../../Resources/CBSE.png";
import { useLocation } from "react-router-dom";
import CISEImage from "../../Resources/CISE.png";
import CambridgeImage from "../../Resources/Cambridge.png";
import AcademicLinks from "./AcademicLinks";
import CBSE from "./CBSE";
import CISE from "./CISE";
import Cambridge from "./Cambridge";
import { useState, useEffect } from "react";

const Academics = () => {
/*   const {showContent, setShowContent} = useState(true); */
  const currentUrl = useLocation();

/*   useEffect(()=> {
    setShowContent(true)
  },[ ]);
 */
/* console.log(setShowContent) */
  const location = {
    address: "1600 Amphitheatre Parkway, Mountain View, california.",
    lat: 37.42216,
    lng: -122.08427,
  };
  return (
    <div>
      <HeaderLinks />
      <div className="row">
        <div className="container">
          <div className="col-md-12">
            <img
              className="img-fluid w-100"
              style={{ height: 500 }}
              src="https://blogs.iadb.org/ideas-matter/wp-content/uploads/sites/12/2018/06/shutterstock_1065259865-1.jpg"
              alt="about-us"
            />
            <div className="mb-100">
              <h1
                class="carousel-caption"
                style={{
                  color: "maroon",
                  fontFamily: "unset",
                  fontSize: 90,
                  bottom: "auto",
                  top: 200,
                  left: -600,
                  fontWeight: "bolder",
                }}
              >
                Academics
              </h1>
            </div>
          </div>
        </div>
      </div>
      <AcademicLinks />
      <br />
    {/*   <h1>{showContent}</h1> */}
 {/*    {!showContent &&  */}<div
    id="list"
        className="text-center"
        style={{ margin: 100, marginTop: 20, marginLeft: 180 }}
      >
        <div class="card"         
        style={{ width: 1000 }}>
          <ul class="list-group list-group-flush">
            <li class="list-group-item">
              <img style={{ height: 70 }} src={CBSEImage} alt="cbse" /> &nbsp;
              <a  onClick={()=>document.getElementById("list").remove()} href="#cbse"> Central Board of Secondary Education (CBSE)</a>
            </li>
            <li class="list-group-item">
              <img style={{ height: 70 }} src={CISEImage} alt="cise" />
              &nbsp;
              <a onClick={()=>document.getElementById("list").remove()} href="#cise">
                Council For The Indian School Certificate Examinations (CISCE)
              </a>
            </li>
            <li class="list-group-item">
              <img
                style={{ height: 70 }}
                src={CambridgeImage}
                alt="cambridge"
              />
              &nbsp;
              <a onClick={()=>document.getElementById("list").remove()} href="#cambridge">
                Cambridge Assessment International Education (Cambridge
                International)
              </a>
            </li>
          </ul>
        </div>
      </div>{/* }  */} 

      {currentUrl.hash === "#cbse" ? <CBSE id="cbse"/> : <></>}
      {currentUrl.hash === "#cise" ? <CISE /> : <></>}
      {currentUrl.hash === "#cambridge" ? <Cambridge /> : <></>}
      
      <Map location={location} zoomLevel={17} />
      <FooterLinks />
      <SocialFollow />
      <Footer />
    </div>
  );
};

export default Academics;
