import CBSEImage from "../../Resources/CBSE.png";

const CBSE = () => {
  return (
    <>
      <div style={{ margin: 100, marginTop: 20 }}>
        <div className="text-center text-primary display-4" id="ourTeam">
        Central Board of Secondary Education
        </div>
        <hr />
      <div className="text-center">
        <img src={CBSEImage} alt="cbse" />
      </div>
      <br/>
      <div
              data-bs-spy="scroll"
              data-bs-target="#navbar-example2"
              data-bs-offset="0"
              class="scrollspy-example"
              tabindex="0"
            >
      <div class="container">
                <div class="row">
                  <div class="col">
                  <p style={{ fontSize: 14, fontFamily: "italic" }}>
        VIBGYOR High offers nationally established CBSE (Central Board of
        Secondary Education) curriculum across its schools.<br/><br/> If you are looking
        at the best CBSE schools near me, definitely the OXFORD High school,
        which is nearby to your location should be considered. <br/><br/> The core
        curriculum in our primary and middle school includes the best of the
        board, thus giving a competitive edge to our young learners and the
        leaders of tomorrow. At VIBGYOR High, the learning objectives of the
        CBSE board are successfully combined with our philosophy of focusing on
        our students and their learning needs. The uniqueness of our course lies
        in its flexibility to upgrade with changes in the field of education.<br/> <br/>
        CBSE has regularly instituted reforms in examinations and evaluation
        practices – the most recent being the graded system of evaluation. As
        per Board guidelines, the prime focus of our curriculum is to innovate
        teaching-learning methodologies by developing paradigms that are
        conducive for students. Thus, the continuous and comprehensive
        assessment system at VIBGYOR ensures that our students are never
        over-burdened. For this, we emphasise on: <br/> <br/> Easy and stress-free
        assessment tools that value our students’ creativity and help teachers
        assess their cognitive skills. Integrating skill learning by adding
        job-oriented inputs in our curriculum. <br/><br/> Further, our teachers regularly
        update their pedagogical skills by attending service training programmes
        and workshops.<br/><br/>  The CBSE curriculum at VIBGYOR is divided into Primary
        Level (Grades 1 to 4) and Secondary Level (Grades 5 to 10). Both levels
        are based on: <br/> <br/> <ul><li>Integrated Curriculum</li><li> Interdisciplinary Approach</li>
        <li>Experimental Learning</li> <li>Research Work and Professional Talk.</li></ul></p></div>
         <div className="col"><p style={{ fontSize: 14, fontFamily: "italic" }}> At the primary and 
         secondary level, students are encouraged to 
         explore the relationship between practical and theoretical concepts of various subjects. 
         Thus, our students learn to analyse how the topic extends beyond the classroom and into the 
         outside world.<br/><br/>Interdisciplinary approach dissolves boundaries of subjects and encourages 
         learning across the curriculum. We have developed a plan where the theme encompasses all 
         curricular areas. This way, subjects like Math, English, Social Studies and Science are 
         integrated and taught together focusing on a specific issue. Here, we have eliminated the 
         age-old concept of teaching subjects in isolation. This cultivates higher-order thinking 
         abilities, encouraging our young geniuses to focus on their critical-thinking and 
         problem-solving skills.<br/><br/>
Further, VIBGYOR High has curated innovative curriculum to address the need of the hour and our
 students’ learning abilities. VIBGYOR High works with the concepts of Home notes and Synopsis 
 materials for Grades 1 to 7. The school has exclusively prepared this unique academic resource
  material for our children, taking into consideration the Board’s objectives, learning needs,
   abilities and interest. <br/><br/><b>Secondary School:</b><br/><br/>
For the Senior Secondary classes i.e. Grades 8 to 10, the school offers CBSE recommended school
 books and study materials for our students. Our students can avail supplementary books and
  sample question papers for greater success in examinations conducted by the Board. 
  The activity-based flexible curriculum and the various teaching aids used by our school 
  facilitate a wholesome learning experience for our young geniuses. <br/><br/>
At VIBGYOR, our constant endeavour is to make education relevant to this rapidly changing and 
evolving world, without compromising on the quality of education.  </p>
       </div> </div> </div>  </div>
       <img
                className="img-fluid w-100"
                style={{ height: 200 }}
                src="https://www.vibgyorhigh.com/images/philosophy.jpg"
                alt="about-us"
              />
        </div>   
    </> 
  );
};

export default CBSE;
