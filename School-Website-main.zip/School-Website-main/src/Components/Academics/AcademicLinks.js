import * as Icon from "react-bootstrap-icons";

const AcademicLinks = () => {
  return (
    <div>
      <div className="p-2 bg-danger text-white text-center">
        <a
          style={{
            textDecoration: "none",
         /*    fontSize: 30, */
            color: "white",
            marginTop: 2,
          }}
          href="#cbse"
        >
          CBSE
        </a>
        <Icon.Dot />
        <a
          style={{
            textDecoration: "none",
          /*   fontSize: 30, */
            color: "white",
            marginTop: 2,
          }}
          href="#cise"
        >
          CISE
        </a>
        <Icon.Dot />
        <a
          style={{
            textDecoration: "none",
          /*   fontSize: 30, */
            color: "white",
            marginTop: 2,
          }}
          href="#cambridge"
        >
          Cambridge International
        </a>
      </div>
    </div>
  );
};

export default AcademicLinks;
