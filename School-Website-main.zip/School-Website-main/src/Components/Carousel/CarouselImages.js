const images = [{
    id: 1,
    src: "https://study.com/cimages/multimages/16/08619177-0624-464b-8b67-b28cd61b913e_adobestock_118245338.png",
    alt: "Image 1"
},
{
    id: 2,
    src: "https://images.unsplash.com/photo-1571260899304-425eee4c7efc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8c3R1ZGVudHxlbnwwfHwwfHx8MA%3D%3D&w=1000&q=80",
    alt: "Image 2 "
},
{
    id: 3,
    src: "https://images.pexels.com/photos/5212653/pexels-photo-5212653.jpeg?cs=srgb&dl=pexels-max-fischer-5212653.jpg&fm=jpg",
    alt: "Image 3"
},
{
    id: 4,
    src: "https://images.pexels.com/photos/1462630/pexels-photo-1462630.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    alt: "Image 4"
}
];
export default images;