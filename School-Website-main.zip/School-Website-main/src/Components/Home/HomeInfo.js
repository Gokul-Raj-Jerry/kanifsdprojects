import AboutUs from "./AboutUs";
import Proud from "./Proud";
import Form from "./Form";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Statistics from "./Statistics";

const HomeInfo = () => {
  return (
    <>
      <h4 className="text-center text-primary display-4">
        Welcome To Best Chain of Schools in India -<br /> Vibgyor
      </h4>
      <br />
      <Container>
        <Row>
          <Col>
            <AboutUs />
          </Col>

          <Col>
            <Proud />
          </Col>
          <Col>
            <Form />
          </Col>
        </Row>
      </Container>
      <Statistics />  
    </>
  );
};

export default HomeInfo;
