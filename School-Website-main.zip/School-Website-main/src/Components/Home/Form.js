import Select from "react-select";
import { useState, useEffect } from "react";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const cityOptions = [
  { value: "bangalore", label: "Bangalore" },
  { value: "chennai", label: "Chennai" },
  { value: "mumbai", label: "Mumbai" },
];

const gradeOptions = [
  { value: "nursery", label: "Nursery" },
  { value: "lkg", label: "LKG" },
  { value: "ukg", label: "UKG" },
  { value: "i", label: "I" },
  { value: "ii", label: "II" },
  { value: "iii", label: "III" },
  { value: "iv", label: "IV" },
  { value: "v", label: "V" },
  { value: "vi", label: "VI" },
  { value: "vii", label: "VII" },
  { value: "viii", label: "VIII" },
  { value: "ix", label: "IX" },
  { value: "x", label: "X" },
];

const Form = (props) => {

  const [selectedCity, setSelectedCity] = useState(null);
  const [selectedGrade, setSelectedGrade] = useState(null);
  const [enteredName, setEnteredName] = useState("");
  const [enteredEmail, setEnteredEmail] = useState("");
  const [enteredContactNumber, setEnteredContactNumber] = useState("");
  const [enteredInquiry, setEnteredInquiry] = useState("");
  const [namePlaceholder, setNamePlaceholder] = useState("Person available on the contact number");
  const [emailPlaceholder, setEmailPlaceholder] = useState("Email");
  const [mobilePlaceholder, setMobilePlaceholder] = useState("Contact Number");
  const [inquiryPlaceholder, setInquiryPlaceholder] = useState("Remarks");
  const [formIsValid, setFormIsValid] = useState(false);

  const notify = () => toast("Inquiry Submitted Successfully🥳");

  useEffect(() => {
    if (
      enteredName &&
      enteredEmail &&
      enteredContactNumber &&
      enteredInquiry
    ) {
      setFormIsValid(true);

    } else {
      setFormIsValid(false);
    }
  }, [
    enteredName,
    enteredEmail,
    enteredContactNumber,
    enteredInquiry,
  ]);


  const submitHandler = async(event) => {
    event.preventDefault();
    notify()
    const admissionForm = {
      city: selectedCity,
      grade: selectedGrade,
      fullname: enteredName,
      email: enteredEmail,
      contact: enteredContactNumber,
      inquiry: enteredInquiry
    }
    try {
      await fetch("https://homepageform-default-rtdb.firebaseio.com/enquiry.json", { 
        method: 'POST',
        body: JSON.stringify(admissionForm)
      });
    } catch(err) {
      if(err) throw new err
    }
    setSelectedCity("")
    setSelectedGrade("")
    setEnteredName("")
    setEnteredEmail("")
    setEnteredContactNumber("")
    setEnteredInquiry("")
  };

  const fullNameHandler = (event) => {
     setEnteredName(event.target.value);
  };

  const fullNamePlaceholder = () => {
    setNamePlaceholder("Type your full name");
  };

  const emailHandler = (event) => {
    setEnteredEmail(event.target.value);
 };

 const emailIdPlaceholder = () => {
   setEmailPlaceholder("Type your email address");
 };

 const mobileHandler = (event) => {
  setEnteredContactNumber(event.target.value);
};

const mobileNumberPlaceholder = () => {
 setMobilePlaceholder("Type your contact number");
};

const inquiryHandler = (event) => {
  setEnteredInquiry(event.target.value)
};

const inquiryMessageHandler = () => {
  setInquiryPlaceholder("Type your inquiry message")
};


  return (
    <div style={{backgroundColor: 'violet'}} class="card">
  <div class="card-body">
    <form onSubmit={submitHandler}>
      <div class="form-group">
        <h4 style={{fontFamily:'cambria'}}  className="text-center">
          ADMISSION ENQUIRY
          <br />
          for year <input type="radio" /> 2023-2024
        </h4>{" "}
        <br />
        <label>Select City</label> <span className="text-danger">*</span>
        <Select
          placeholder="Select Nearest Branch"
          value={selectedCity}
          onChange={(event) => setSelectedCity(event)}
          options={cityOptions}
        />{" "}
        <br />
        <label>Select Grade</label> <span className="text-danger">*</span>
        <Select
          placeholder="Select Grade"
          value={selectedGrade}
          onChange={(event) => setSelectedGrade(event)}
          options={gradeOptions}
        />
        <br />
        <label>Full Name</label> <span className="text-danger">*</span>
        <input
          class="form-control"
          onChange={fullNameHandler}
          onClick={fullNamePlaceholder}
          type="text"
          value={enteredName}
          placeholder={namePlaceholder}
        />{" "}
        <br />
        <label>Email ID</label> <span className="text-danger">*</span>
        <input 
        onChange={emailHandler}
        onClick={emailIdPlaceholder}
        value={enteredEmail} class="form-control" type="email" placeholder={emailPlaceholder}/> <br />
        <label>Contact Number</label> <span className="text-danger">*</span>
        <input value={enteredContactNumber} onClick={mobileNumberPlaceholder} onChange={mobileHandler} class="form-control" type="text" placeholder={mobilePlaceholder} /> <br />
        <label>Inquire About</label> <span className="text-danger">*</span>
        <textarea value={enteredInquiry} onClick={inquiryMessageHandler} onChange={inquiryHandler} cols="15" rows="3" class="form-control" placeholder={inquiryPlaceholder}></textarea> <br />
        <div className="text-center">
        <button
          disabled={!formIsValid}
          type="submit"
          class="btn btn-warning"
        >
          Enquire Now
        </button> </div>
      </div>   
    </form>  <div>
        <ToastContainer />
      </div> </div>     </div>   
  );
};

export default Form;
