import { useNavigate } from "react-router-dom";
import * as Icon from "react-bootstrap-icons"

const AboutUs = () => {
    const navigate = useNavigate();
  return (
    <div>
      <h5>---------------About Us-----------------</h5> <br/> 
      <p>
        VIBGYOR High's journey towards education excellence began in 2004 with
        an ideal mix of academic and corporate professionals who felt the shared
        need to provide inclusive education.VIBGYOR High is one of the best CBSE
        Schools in India. At VIBGYOR High, we challenge our students with a
        unique educational experience which emphasises a seamless blend of
        academics, sports, performing arts, community and experiential learning
        programmes.
      </p>
      <button type="button" class="btn btn-warning" onClick={()=>{navigate("/aboutUs")}}>
       <Icon.Plus/> Continue Reading
      </button> 
    </div>
  );
};

export default AboutUs;
