import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";

const Statistics = () => {
  const myStyle = {
    backgroundImage:
      "url('https://i0.hippopx.com/photos/765/813/274/blur-door-factory-focus-preview.jpg')",
    height: "80vh",
    opacity: "0.8",
    marginTop: "-70px",
    fontSize: "50px",
    backgroundSize: "cover",
    backgroundRepeat: "no-repeat",
  };

  return (
    <>                 <br/>   <br/>   <br/>
      <div style={myStyle}>
        <h1>
          <Container className="text-center">
            <Row   >
              <Col style={{fontFamily: 'algerian', fontWeight: 'bold', marginTop: 225, backgroundColor: 'skyBlue'}}> 55000+ Students</Col>
              <Col style={{fontFamily: 'algerian', fontWeight: 'bold', marginTop: 225, backgroundColor: 'yellow'}}> 36 Schools</Col>
              <Col style={{fontFamily: 'algerian', fontWeight: 'bold', marginTop: 225, backgroundColor: 'pink'}}> 13 Cities</Col>
            </Row>
          </Container>
        </h1> 
      </div> 
    </>
  );
};

export default Statistics;
