import * as Icon from "react-bootstrap-icons";

const Proud = () => {
  return (
    <>
      <h5>------------We are proud Of------------</h5> <br/>
      <Icon.AwardFill/>&nbsp;&nbsp;Growing Network <br/> <br/> 
      <Icon.BagHeart/>&nbsp;&nbsp;Unmatched Safety Measures <br/><br/> 
      <Icon.AspectRatio/>&nbsp;&nbsp;Teacher Student Ratio <br/><br/> 
      <Icon.Book/>&nbsp;&nbsp;Global Curriculum <br/><br/> 
      <Icon.PaintBucket/>&nbsp;&nbsp;State of the art Infrastructure<br/><br/> 
      <Icon.Youtube/>&nbsp;&nbsp;Holistic Development <br/><br/> 
      <Icon.Box2HeartFill/>&nbsp;&nbsp;Choice of Education Boards <br/><br/> 
  </>
  );
};

export default Proud;
