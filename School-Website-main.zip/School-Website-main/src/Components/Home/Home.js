import React from "react";
import "../../Styles/styles.css";
import FooterLinks from "../Footer/FooterLinks";
import SocialFollow from "../SocialPlatform/SocialFollow";
import Footer from "../Footer/Footer";
import Map from "../GoogleMap/Map";
import HeaderLinks from "../Header/HeaderLinks";
import ImageSlider from "../Carousel/ImageSlider";
import images from "../Carousel/CarouselImages";
import HomeInfo from "./HomeInfo";
import YoutubeEmbed from "../About Us/YouTubeEmbed";

const Home = () => {
  const location = {
    address: '1600 Amphitheatre Parkway, Mountain View, california.',
    lat: 37.42216,
    lng: -122.08427,
  }
  localStorage.setItem("menu", "home");

  return (
    <React.Fragment>
        
      <HeaderLinks />
      <ImageSlider images={images} />
      <br/>
      <HomeInfo/>        <Map location={location} zoomLevel={17} />
      <YoutubeEmbed/>    <FooterLinks />   <SocialFollow />      <Footer />
  
   

    </React.Fragment>
  );
};

export default Home;