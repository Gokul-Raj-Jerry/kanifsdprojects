import React, { useState, useRef, useEffect } from "react";
import Dashboard from "../Dashboard";
import Map from "../GoogleMap/Map";
import FooterLinks from "../Footer/FooterLinks";
import SocialFollow from "../SocialPlatform/SocialFollow";
import Footer from "../Footer/Footer";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Contact = () => {
  const [enteredName, setEnteredName] = useState("");
  const [enteredEmail, setEnteredEmail] = useState("");
  const [enteredPhone, setEnteredPhone] = useState("");
  const [enteredQuery, setEnteredQuery] = useState("");
  const [formIsValid, setFormIsValid] = useState(false);
  const [enteredNameIsTouched, setEnteredNameIsTouched] = useState(false);
  const [enteredEmailIsTouched, setEnteredEmailIsTouched] = useState(false);
  const [enteredPhoneIsTouched, setEnteredPhoneIsTouched] = useState(false);
  const [enteredQueryIsTouched, setEnteredQueryIsTouched] = useState(false);
  const notify = () => toast("Your query is  submitted successfully");
  const nameInputRef = useRef();
  const emailInputRef = useRef();
  const phoneInputRef = useRef();
  const queryInputRef = useRef();

  const enteredNameIsValid = enteredName.trim() !== "";
  const enteredEmailIsValid = enteredEmail.trim() !== "";
  const enteredPhoneIsValid = enteredPhone.trim() !== "";
  const enteredQueryIsValid = enteredQuery.trim() !== "";

  const nameInputIsInvalid = !enteredNameIsValid && enteredNameIsTouched;
  const emailInputIsInvalid = !enteredEmailIsValid && enteredEmailIsTouched;
  const phoneInputIsInvalid = !enteredPhoneIsValid && enteredPhoneIsTouched;
  const queryInputIsInvalid = !enteredQueryIsValid && enteredQueryIsTouched;

  const location = {
    address: '1600 Amphitheatre Parkway, Mountain View, california.',
    lat: 37.42216,
    lng: -122.08427,
  }

  useEffect(() => {
    if (
      enteredNameIsValid &&
      enteredEmailIsValid &&
      enteredPhoneIsValid &&
      enteredQueryIsValid
    ) {
      setFormIsValid(true);

    } else {
      setFormIsValid(false);
    }
  }, [
    enteredNameIsValid,
    enteredEmailIsValid,
    enteredPhoneIsValid,
    enteredQueryIsValid,
  ]);



  const submitHandler = async (event) => {
    event.preventDefault();
    notify()
    setEnteredNameIsTouched(true);
    if (!enteredNameIsValid) return;
    setEnteredEmailIsTouched(true);
    if (!enteredEmailIsValid) return;
    setEnteredPhoneIsTouched(true);
    if (!enteredPhoneIsValid) return;
    setEnteredQueryIsTouched(true);
    if (!enteredQueryIsValid) return;
    console.log(enteredName);
    setEnteredName("");
    setEnteredEmail("");
    setEnteredPhone("");
    setEnteredQuery("");
    setEnteredNameIsTouched(false);
    setEnteredEmailIsTouched(false);
    setEnteredPhoneIsTouched(false);
    setEnteredQueryIsTouched(false);
    await fetch("https://homepageform-default-rtdb.firebaseio.com/contactUs.json", {
      method: 'POST',
      body: JSON.stringify(formData),
      headers: {
        'Content-Type' : 'application/json'
      }
    })
  };

  const formData = {
    name: enteredName,
    email: enteredEmail,
    phone: enteredPhone,
    query: enteredQuery
  }

  console.log(formData)

  const nameInputChangeHandler = (event) => {
    setEnteredName(event.target.value);
  };

  const emailInputChangeHandler = (event) => {
    setEnteredEmail(event.target.value);
  };

  const phoneInputChangeHandler = (event) => {
    setEnteredPhone(event.target.value);
  };

  const queryInputChangeHandler = (event) => {
    setEnteredQuery(event.target.value);
  };

  const nameInputBlurHandler = () => {
    setEnteredNameIsTouched(true);
  };

  const emailInputBlurHandler = () => {
    setEnteredEmailIsTouched(true);
  };

  const phoneInputBlurHandler = () => {
    setEnteredPhoneIsTouched(true);
  };

  const queryInputBlurHandler = () => {
    setEnteredQueryIsTouched(true);
  };

  localStorage.setItem("menu","contact");

  return (
    <React.Fragment>
      <Dashboard />
      <div className="row">
        <div className="mx-auto col-10 col-md-8 col-lg-6">
          <h2 className="contactUsText mx-auto">
            Ask your queries below!
          </h2>
          <br />
          <form onSubmit={submitHandler}>
            <div className="form-group">
              <input
                onBlur={nameInputBlurHandler}
                value={enteredName}
                className="form-control"
                onChange={nameInputChangeHandler}
                required
                ref={nameInputRef}
                type="text"
                placeholder="Name*"
              />
            
              {nameInputIsInvalid && <p className="text-danger">Name must not be empty</p>}
              <br />
            </div>
            <div className="form-group">
              <input
                onBlur={emailInputBlurHandler}
                value={enteredEmail}
                className="form-control"
                onChange={emailInputChangeHandler}
                required
                ref={emailInputRef}
                type="email"
                placeholder="Email address*"
              />
              {emailInputIsInvalid && <p className="text-danger">Email must not be empty</p>}
              <br />
            </div>
            <div className="form-group">
              <input
                onBlur={phoneInputBlurHandler}
                value={enteredPhone}
                className="form-control"
                onChange={phoneInputChangeHandler}
                required
                ref={phoneInputRef}
                type="number"
                placeholder="Contact Number*"
              />
              {phoneInputIsInvalid && <p className="text-danger">Phone must not be empty</p>}
              <br />
            </div>
            <div className="form-group">
              <textarea
                required
                className="form-control"
                onBlur={queryInputBlurHandler}
                value={enteredQuery}
                ref={queryInputRef}
                onChange={queryInputChangeHandler}
                rows="6"
                cols="88"
                placeholder="Ask us your queries"
              />
              {queryInputIsInvalid && <p className="text-danger">Please input your query. We would be happy to assist you!</p>}
            </div>
            <div className="container">
              <div className="col-md-12 text-center">
                <button
                  disabled={!formIsValid}
                  type="submit"
                  className="btn btn-primary text-center btn-customized mt-4"
                  onClick={submitHandler}
                >
                  Submit
                </button>
              </div>
            </div>
          </form>
        </div><ToastContainer />
      </div>
      <br/>
      <Map location={location} zoomLevel={17} />
      <FooterLinks/>
      <SocialFollow/>
      <Footer/>
    </React.Fragment>
  );
};

export default Contact;
