import React, { useState, useEffect } from "react";
import { registerWithEmailAndPassword, signInWithGoogle } from "../../firebase";
import { Link, useNavigate } from "react-router-dom";
import { auth } from "../../firebase";
import { useAuthState } from "react-firebase-hooks/auth";
import showPwdImg from "../../Resources/hide-password.svg";
import hidePwdImg from "../../Resources/show-password.svg";
import "../../Styles/styles.css";
import Map from "../GoogleMap/Map";
import FooterLinks from "../Footer/FooterLinks";
import SocialFollow from "../SocialPlatform/SocialFollow";
import Footer from "../Footer/Footer";
   
import HeaderLinks from "../Header/HeaderLinks";

const ParentLogin = () => {
  const location = {
    address: '1600 Amphitheatre Parkway, Mountain View, california.',
    lat: 37.42216,
    lng: -122.08427,
  }
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [user, loading] = useAuthState(auth);
  const [isRevealPwd, setIsRevealPwd] = useState(false);

  useEffect(() => {
    if (loading) {
      // maybe trigger a loading screen
      return;
    }
    if (user) navigate("/home");
  }, [user, loading, navigate]);

  localStorage.setItem("menu", "staffLogin");

  const register = () => {
    if (!email) alert("Please enter username");
    registerWithEmailAndPassword(email, password);
  };

  /*   useEffect(() => {
    if (isAndroid) {
      window.location.href =
        "https://play.google.com/store/apps/details?id=com.tetraz.capsigo";
    }else if(isIOS) {
      window.location.href =
        "https://apps.apple.com/app/capsigo/id1547746310";
    } else{
      window.location.href =
        "https://capsigo.com"; 
        "https://play.google.com/store/apps/details?id=com.tetraz.capsigo";
    }
  }, []); */

  return (
    <React.Fragment>
        
      <HeaderLinks />

      <div className="row">
        <div className="mx-auto col-10 col-md-8 col-lg-6">
          <div>
            <h2 className="homeText">Welcome Back Our Beloved Parents!</h2>
            <br />
            <form>
              <div className="form-group text-center">
                <input
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  className="form-control"
                  type="text"
                  placeholder="Enter Email Id"
                />
              </div>
              <br />
              <div className="form-group text-center pwd-container">
                <input
                  className="form-control"
                  type={isRevealPwd ? "text" : "password"}
                  placeholder="Enter password"
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                />
                <img
                  title={isRevealPwd ? "Hide password" : "Show password"}
                  src={isRevealPwd ? hidePwdImg : showPwdImg}
                  onClick={() => setIsRevealPwd((prevState) => !prevState)}
                  alt="Show Password Icon"
                />
              </div>
              <div className="container">
                <div className="col-md-12 text-center">
                  <button
                    /*   disabled={!formIsValid} */
                    className="btn btn-primary mt-4 register__btn register__google"
                    onClick={register}
                    type="submit"
                  >
                    Sign Up
                  </button>{" "}
                  &nbsp; &nbsp;
                  <button
                    className="btn btn-success mt-4 register__btn register__google"
                    onClick={signInWithGoogle}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      className="bi bi-google"
                      viewBox="0 0 16 16"
                    >
                      <path d="M15.545 6.558a9.42 9.42 0 0 1 .139 1.626c0 2.434-.87 4.492-2.384 5.885h.002C11.978 15.292 10.158 16 8 16A8 8 0 1 1 8 0a7.689 7.689 0 0 1 5.352 2.082l-2.284 2.284A4.347 4.347 0 0 0 8 3.166c-2.087 0-3.86 1.408-4.492 3.304a4.792 4.792 0 0 0 0 3.063h.003c.635 1.893 2.405 3.301 4.492 3.301 1.078 0 2.004-.276 2.722-.764h-.003a3.702 3.702 0 0 0 1.599-2.431H8v-3.08h7.545z" />
                    </svg>{" "}
                    <i className="bi bi-google"> Register with Google</i>
                  </button>
                </div>
              </div> <br/>
              <p className="text-center"> Have you <Link to="/resetPassword">forgotten the password?</Link>
        </p>
              <div className="form-group">
                <p className="homeText">
                  Not a member? <Link to="/signup"> Signup</Link>
                </p>
              </div>
            </form>
          </div>
        </div>
      </div>
      <Map location={location} zoomLevel={17} />
      <FooterLinks />
      <SocialFollow />
      <Footer />
    </React.Fragment>
  );
};

export default ParentLogin;
