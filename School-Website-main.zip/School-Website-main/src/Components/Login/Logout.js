import React from "react";
import { Link } from "react-router-dom";
import LogoutImage from "../../Resources/LogoutPage.jpg"

const Logout = () => {
  localStorage.setItem("menu", "logoutPage");

  return (
    <React.Fragment>

      <h2 className="homeText">You are logged out successfully</h2>
      <div className="homeText">
        Thanks for visiting our page. If you have any queries, feel free to
        write to us through our <Link to="/contactUs">contact page</Link> or call us at 888-945-7625
      </div>
      <div className="text-center">
        <img className="img-thumbnail" src={LogoutImage} alt="core_image" /> </div>
    </React.Fragment>
  );
};

export default Logout;