import React, { useState, useRef, useEffect } from "react";
import Dashboard from "../Dashboard";
import { useAuthState } from "react-firebase-hooks/auth";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut  } from "firebase/auth";
import { Link, useNavigate } from "react-router-dom";
import {
  auth,
  generateUserDocument,
  registerWithEmailAndPassword,
  signInWithGoogle,
} from "../../firebase";
import showPwdImg from "../../Resources/hide-password.svg";
import hidePwdImg from "../../Resources/show-password.svg";
import "../../Styles/styles.css";
import Map from "../GoogleMap/Map";
import FooterLinks from "../Footer/FooterLinks";
import SocialFollow from "../SocialPlatform/SocialFollow";
import Footer from "../Footer/Footer";

const Signup = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const [enteredUserName, setEnteredUserName] = useState("");
  const [enteredEmail, setEnteredEmail] = useState("");
  const [isRevealPwd, setIsRevealPwd] = useState(false);
  const [enteredPassword, setEnteredPassword] = useState("");
  const [enteredConfirmPassword, setEnteredConfirmPassword] = useState("");
  const [enteredPhone, setEnteredPhone] = useState("");
  const [user, loading ] = useAuthState(auth);
  const [formIsValid, setFormIsValid] = useState(false);
  const [enteredUserNameIsTouched, setEnteredUserNameIsTouched] =
    useState(false);
  const [enteredEmailIsTouched, setEnteredEmailIsTouched] = useState(false);
  const [enteredPasswordIsTouched, setEnteredPasswordIsTouched] =
    useState(false);
  const [enteredConfirmPasswordIsTouched, setEnteredConfirmPasswordIsTouched] =
    useState(false);
  const [enteredPhoneIsTouched, setEnteredPhoneIsTouched] = useState(false);
  const userNameInputRef = useRef();
  const emailInputRef = useRef();
  const passwordInputRef = useRef();
  const confirmPasswordInputRef = useRef();
  const phoneInputRef = useRef();

  const enteredUserNameIsValid = enteredUserName.trim() !== "";
  const enteredEmailIsValid = enteredEmail.trim() !== "";
  const enteredPasswordIsValid = enteredPassword.trim() !== "";
  const enteredConfirmPasswordIsValid = enteredConfirmPassword.trim() !== "";
  const enteredPhoneIsValid = enteredPhone.trim() !== "";

  const userNameInputIsInvalid =
    !enteredUserNameIsValid && enteredUserNameIsTouched;
  const emailInputIsInvalid = !enteredEmailIsValid && enteredEmailIsTouched;
  const passwordInputIsInvalid =
    !enteredPasswordIsValid && enteredPasswordIsTouched;
  const confirmPasswordInputIsInvalid =
    !enteredConfirmPasswordIsValid && enteredConfirmPasswordIsTouched;
  const phoneInputIsInvalid = !enteredPhoneIsValid && enteredPhoneIsTouched;

  const register = () => {
    if (!enteredUserName) alert("Please enter username");
    if (!enteredEmail) alert("Please enter email Id");
    if (!enteredPassword) alert("Please enter password");
    if (!enteredConfirmPassword) alert("Please confirm password");
    if (!enteredPhone) alert("Please enter phone");
    registerWithEmailAndPassword(
      enteredUserName,
      enteredEmail,
      enteredPassword,
      enteredConfirmPassword,
      enteredPhone
    );
  };

  useEffect(() => {
    if (loading) return;
    if (user) navigate("/home");
  }, [user, loading, navigate]);

  useEffect(() => {
    if (
      enteredUserNameIsValid &&
      enteredEmailIsValid &&
      enteredPasswordIsValid &&
      enteredConfirmPasswordIsValid &&
      enteredPhoneIsValid
    ) {
      setFormIsValid(true);
    } else {
      setFormIsValid(false);
    }
  }, [
    enteredUserNameIsValid,
    enteredEmailIsValid,
    enteredPasswordIsValid,
    enteredConfirmPasswordIsValid,
    enteredPhoneIsValid,
  ]);

 

  const signupHandler = async (event) => {
    event.preventDefault();
    setEnteredUserNameIsTouched(true);
    if (!enteredUserNameIsValid) return;
    setEnteredEmailIsTouched(true);
    if (!enteredEmailIsValid) return;
    setEnteredPasswordIsTouched(true);
    if (!enteredPasswordIsValid) return;
    setEnteredConfirmPasswordIsTouched(true);
    if (!enteredConfirmPasswordIsValid) return;
    setEnteredPhoneIsTouched(true);
    if (!enteredPhoneIsValid) return;
    setEnteredUserName("");
    setEnteredEmail("");
    setEnteredPhone("");
    setEnteredPassword("");
    setEnteredEmailIsTouched(true);
    if (!enteredEmailIsValid) return;
    setEnteredConfirmPassword("");
    setEnteredUserNameIsTouched(false);
    setEnteredEmailIsTouched(false);
    setEnteredPhoneIsTouched(false);
    setEnteredPasswordIsTouched(false);
    setEnteredConfirmPasswordIsTouched(false);
    console.log("Member is created successfully");

    const response = await fetch(
      "https://signup-2eabf-default-rtdb.firebaseio.com/signup.json",
      {
        method: "POST",
        body: JSON.stringify(signupData),
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    const data = await response.json();
    console.log(data);
    setEnteredUserName("");
    setEnteredEmail("");
    setEnteredPassword("");
    setEnteredConfirmPassword("");
    setEnteredPhone("");
  };

  const signupData = {
    name: enteredUserName,
    email: enteredEmail,
    password: enteredPassword,
    confirmPassword: enteredConfirmPassword,
    phone: enteredPhone,
  };

  console.log(signupData);

  const location = {
    address: '1600 Amphitheatre Parkway, Mountain View, california.',
    lat: 37.42216,
    lng: -122.08427,
  }

  const nameInputBlurHandler = () => {
    setEnteredUserNameIsTouched(true);
  };

  const emailInputBlurHandler = () => {
    setEnteredEmailIsTouched(true);
  };

  const passwordInputBlurHandler = () => {
    setEnteredPasswordIsTouched(true);
  };

  const confirmPasswordInputBlurHandler = () => {
    setEnteredConfirmPasswordIsTouched(true);
  };

  const phoneInputBlurHandler = () => {
    setEnteredPhoneIsTouched(true);
  };

  const userNameInputChangeHandler = (event) => {
    setEnteredUserName(event.target.value);
  };

  const emailInputChangeHandler = (event) => {
    setEnteredEmail(event.target.value);
  };

  const passwordInputChangeHandler = (event) => {
    setEnteredPassword(event.target.value);
  };

  const confirmPasswordInputChangeHandler = (event) => {
    setEnteredConfirmPassword(event.target.value);
  };

  const phoneInputChangeHandler = (event) => {
    setEnteredPhone(event.target.value);
  };

  localStorage.setItem("menu", "signUp");

  const createUserWithEmailAndPasswordHandler = async (event, email, password) => {
    event.preventDefault();
    try{
      const {user} = await auth.createUserWithEmailAndPassword(email, password);
      generateUserDocument(user, {displayName});
    }
    catch(error){
      setError('Error Signing up with email and password');
    }
      
    setEmail("");
    setPassword("");
    setDisplayName("");
  };

  const onChangeHandler = event => {
    const { name, value } = event.currentTarget;

    if (name === "userEmail") {
      setEmail(value);
    } else if (name === "userPassword") {
      setPassword(value);
    } else if (name === "displayName") {
      setDisplayName(value);
    }
  };

  return (
    <React.Fragment>
      <Dashboard />
      <div className="row">
        <div className="mx-auto col-10 col-md-8 col-lg-6">
          <div>
            <h2 className="homeText">Welcome to creating your new account</h2>
            <br />
            <form onSubmit={signupHandler}>
              <div className="form-group text-center">
                <input
                  onBlur={nameInputBlurHandler}
                  value={enteredUserName}
                  onChange={userNameInputChangeHandler}
                  ref={userNameInputRef}
                  className="form-control"
                  type="text"
                  placeholder="Enter Username"
                />
              </div>
              {userNameInputIsInvalid && <p>Name must not be empty</p>}
              <br />
              <div className="form-group text-center">
                <input
                  onBlur={emailInputBlurHandler}
                  value={enteredEmail}
                  onChange={emailInputChangeHandler}
                  ref={emailInputRef}
                  className="form-control"
                  type="text"
                  placeholder="Enter Email Id"
                />
              </div>
              {emailInputIsInvalid && <p>Email must not be empty</p>}
              <br />
              <div className="form-group text-center pwd-container">
                <input
                  name="pwd"
                  onBlur={passwordInputBlurHandler}
                  value={enteredPassword}
                  onChange={passwordInputChangeHandler}
                  ref={passwordInputRef}
                  className="form-control"
                  type={isRevealPwd ? "text" : "password"}
                  placeholder="Enter Password"
                />
                <img
                  title={isRevealPwd ? "Hide password" : "Show password"}
                  src={isRevealPwd ? hidePwdImg : showPwdImg}
                  onClick={() => setIsRevealPwd((prevState) => !prevState)}
                  alt="Show Password Icon"
                />
              </div>
              {passwordInputIsInvalid && <p>Password must not be empty</p>}
              <br />
              <div className="form-group text-center pwd-container">
                <input
                  onBlur={confirmPasswordInputBlurHandler}
                  value={enteredConfirmPassword}
                  onChange={confirmPasswordInputChangeHandler}
                  ref={confirmPasswordInputRef}
                  className="form-control"
                  type={isRevealPwd ? "text" : "password"}
                  placeholder="Confirm Password"
                />
                <img
                  title={isRevealPwd ? "Hide password" : "Show password"}
                  src={isRevealPwd ? hidePwdImg : showPwdImg}
                  onClick={() => setIsRevealPwd((prevState) => !prevState)}
                  alt="Show Password Icon"
                />
              </div>
              {confirmPasswordInputIsInvalid && (
                <p>Password must not be empty</p>
              )}
              <br />
              <div className="form-group text-center">
                <input
                  onBlur={phoneInputBlurHandler}
                  value={enteredPhone}
                  onChange={phoneInputChangeHandler}
                  ref={phoneInputRef}
                  className="form-control"
                  type="number"
                  placeholder="Enter Contact Number"
                />
              </div>
              {phoneInputIsInvalid && <p>Phone must not be empty</p>}
              <div className="container">
                <div className="col-md-12 text-center">
                  <button
                    disabled={!formIsValid}
                    className="btn btn-primary mt-4 register__btn register__google"
                    onClick={register}
                    type="submit"
                  >
                    Sign Up
                  </button>{" "}
                  &nbsp; &nbsp;
                  <button
                    className="btn btn-success mt-4 register__btn register__google"
                    onClick={signInWithGoogle}
                  ><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-google" viewBox="0 0 16 16">
                  <path d="M15.545 6.558a9.42 9.42 0 0 1 .139 1.626c0 2.434-.87 4.492-2.384 5.885h.002C11.978 15.292 10.158 16 8 16A8 8 0 1 1 8 0a7.689 7.689 0 0 1 5.352 2.082l-2.284 2.284A4.347 4.347 0 0 0 8 3.166c-2.087 0-3.86 1.408-4.492 3.304a4.792 4.792 0 0 0 0 3.063h.003c.635 1.893 2.405 3.301 4.492 3.301 1.078 0 2.004-.276 2.722-.764h-.003a3.702 3.702 0 0 0 1.599-2.431H8v-3.08h7.545z"/>
                </svg> <i className="bi bi-google"> Register with Google</i>
                  </button>
                </div>
              </div>
              <div className="form-group">
                <p className="homeText">
                  Already a member?
                  <Link to="/studentLogin"> Student Login</Link> or{" "}
                  <Link to="/staffLogin"> Staff Login</Link> or 
                  <Link to="/parentLogin"> Parent Login</Link>
                </p>
              </div>
            </form>
          </div>
        </div>
      </div>
      <Map location={location} zoomLevel={17} />
      <FooterLinks/>
      <SocialFollow/>
      <Footer/>
    </React.Fragment>
  );
};

export default Signup;
