import React, { useEffect, useState } from "react";
import { useAuthState } from "react-firebase-hooks/auth";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { auth, sendPasswordReset } from "../../firebase";
import Dashboard from "../Dashboard";

function Reset() {
  const [email, setEmail] = useState("");
  const [user, loading] = useAuthState(auth);
  const navigate = useNavigate();

  useEffect(() => {
    if (loading) return;
    if (user) navigate("/signup");
  }, [user, loading, navigate]);

  return (
    <>
      <Dashboard />
      <form>
        <div className="form-group text-center">
          <div className="reset">
            <div className="reset__container">
              <br />
              <h1>Reset your account password</h1> <br />
              <div class="mb-5 row text-center">
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;{" "}
            {/*     <label for="inputPassword" class="col-sm-2 col-form-label">
                  Email
                </label> */}
                <div class="col-sm-5">
                  <input
                    type="email"
                    className="reset__textBox form-control"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email to send the reset link"
                  />
             {/*      <br /> */}
                </div>
              </div>
              <button
                className="reset__btn btn btn-primary"
                onClick={() => sendPasswordReset(email)}
              >
                Send password reset email
              </button>
              <br /> <br />
              <div>
                Don't have an account? <Link to="/signup">Sign Up</Link> now.
              </div>
            </div>
          </div>{" "}
        </div>
      </form>
    </>
  );
}

export default Reset;
