import NewsletterImage from "../../Resources/NewsLetter.jpg";
import Footer from "../Footer/Footer";
import FooterLinks from "../Footer/FooterLinks";
import Map from "../GoogleMap/Map";
import HeaderLinks from "../Header/HeaderLinks";
import SocialFollow from "../SocialPlatform/SocialFollow";

const Newsletter = () => {
  const location = {
    address: '1600 Amphitheatre Parkway, Mountain View, california.',
    lat: 37.42216,
    lng: -122.08427,
  }
  const month = ["January","February","March","April","May","June","July","August","September","October","November","December"];

const d = new Date();
let name = month[d.getMonth()];
  return (
    <>
    <HeaderLinks/>
    <div style={{ margin: 100, marginTop: 20 }}>
        <div className="text-center text-primary display-4" id="ourTeam">
        Welcome to {name}'s NewsLetter
        </div>
        <hr />

    <div className="text-center">
      <img src={NewsletterImage} alt="newsletter"></img></div>   </div>
      <Map location={location} zoomLevel={17} />  
      <FooterLinks/>
      <SocialFollow/>
      <Footer/>   
    </>
  );
};

export default Newsletter;
