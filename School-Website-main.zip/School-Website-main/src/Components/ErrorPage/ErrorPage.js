import React from "react";
import "../../Styles/styles.css";
import Map from "../GoogleMap/Map";
import FooterLinks from "../Footer/FooterLinks";
import SocialFollow from "../SocialPlatform/SocialFollow";
import Footer from "../Footer/Footer";
   
import HeaderLinks from "../Header/HeaderLinks";


const ErrorPage = ( ) => {
    localStorage.setItem("menu","errorPage");

    return (
        <React.Fragment>
            <HeaderLinks/>

        <div>
            <h1 className="homeText">Something went wrong!</h1>
        </div>
        <br/>
        <br/>
        <br/>
        <br/>
        <Map/>
        <FooterLinks/>
        <SocialFollow/>
        <Footer/>
        </React.Fragment>
    )
}

export default ErrorPage;