import React, { /* useState */ } from "react";
import { useAuthState } from "react-firebase-hooks/auth";
/* import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom"; */
import { auth, /* db */ } from "../firebase";
/* import { query, collection, getDocs, where } from "firebase/firestore"; */
import "../Styles/styles.css";
/* import { useSelector } from "react-redux"; */
import HeaderLinks from "./Header/HeaderLinks";

const Dashboard = () => {
  const [user] = useAuthState(auth);
/*   const [ , setName] = useState(""); */
/*   const navigate = useNavigate(); */
  /* 
  const fetchUserName = async () => {
    try {
      const q = query(collection(db, "users"), where("uid", "==", user?.uid));
      const doc = await getDocs(q);
      const data = doc.docs[0].data();

      setName(data.name);
    } catch (err) {
      console.error(err);
      alert("An error occured while fetching user data");
    }
  };

   useEffect(() => {
    if (loading) return;
    if (!user) return navigate("/home");
    fetchUserName();
  }, [user, loading]);  
 */
  console.log(user?.email.length)
     localStorage.setItem("authStatus", `${(user?.email.length === undefined) ? "NotloggedIn" : "LoggedIn"}`);
/*      let logStatus = localStorage.getItem("authStatus")
   let LoggedInUrl = <div className="logStatus">Logged in as <Link>{user?.email}</Link>
   </div>; */
   
 /*   const admissionHandler = () => {
    navigate("/contactUs")
   } */

/*    let currentPage = localStorage.getItem("menu"); */
  return (
    <React.Fragment>
<HeaderLinks/>
  
{/*       <ul className="dashboard homeText">
        {<Link to="/home">Home</Link>}
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        {<Link to="/aboutUs">About Us</Link>} &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        {<Link to="/vision-mission">Vision & Mission</Link>}
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        {<Link to="/why-our-academy">Why our academy</Link>}
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        {<Link to="/services">Services</Link>} &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        {<Link to="/studyMaterials">Study Materials</Link>}
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        {<Link to="/careers">Careers</Link>} &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        {user?.email.length === undefined ? (
          <Link to="/studentLogin">Student Login</Link>
        ) : (
          <></>
        )}
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        {user?.email.length === undefined ? (
          <Link to="/staffLogin">Staff Login</Link>
        ) : (
          <></>
        )}   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        {user?.email.length === undefined ? (
          <Link to="/parentLogin">Parent Login</Link>
        ) : (
          <></>
        )}
      
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        {user?.email.length === undefined ? (
          <Link to="/signup">Sign Up</Link>
        ) : (
          <></>
        )}
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        {<Link to="/contactUs">Help/Queries</Link>}{" "}
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        { logStatus === "LoggedIn" ? 
          <Link to="/logout" onClick={logout}>
            Logout
          </Link> : <></>
        }
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      </ul> */}
  {/*     {logStatus === "LoggedIn" ? LoggedInUrl : <></>} */}

    </React.Fragment>
  );
};

export default Dashboard;
