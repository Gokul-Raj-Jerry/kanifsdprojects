import React from "react";
import "../../Styles/styles.css";
import About from "../../Resources/About.jpg";
import * as Icon from "react-bootstrap-icons";
import Map from "../GoogleMap/Map";
import FooterLinks from "../Footer/FooterLinks";
import Footer from "../Footer/Footer";
import HeaderLinks from "../Header/HeaderLinks";
import SocialFollow from "../SocialPlatform/SocialFollow";
import { Link, useLocation } from "react-router-dom";

const AboutUs = () => {
  let currentUrl = useLocation();
  const location = {
    address: "1600 Amphitheatre Parkway, Mountain View, california.",
    lat: 37.42216,
    lng: -122.08427,
  };
  localStorage.setItem("menu", "aboutUs");
  return (
    <React.Fragment>
      <div>
        <HeaderLinks />
        <div className="row">
          <div className="container">
            <div className="col-md-12">
              <img
                className="img-fluid w-100"
                style={{ height: 500 }}
                src={About}
                alt="about-us"
              />
              <div className="mb-100">
                <h1
                  class="carousel-caption"
                  style={{
                    fontFamily: "unset",
                    fontSize: 90,
                    top: 200,
                    bottom: "auto",
                    left: -600,
                    fontWeight: "bolder",
                  }}
                >
                  About Us
                </h1>
              </div>{" "}
            </div>
          </div>
        </div>
        <div
          style={{ fontFamily: "verdana" }}
          className="p-2 bg-danger text-white text-center"
        >
          <Link
            style={{ textDecoration: "none", color: "white", marginTop: 2 }}
            href="#overview"
          >
            Overview
          </Link>
          <Icon.Dot />
          <a style={{ textDecoration: "none", color: "white" }} href="#ourTeam">
            Our Team
          </a>
          <Icon.Dot />
          <a
            style={{ textDecoration: "none", color: "white" }}
        href="#visionMission" 
          >
            Vision & Mission
          </a>
        </div>{" "}
        <br />
        {currentUrl.hash === "" ? (
          <>
            {" "}
            <div className="text-center text-primary display-4" id="overview">
              Overview
            </div>
            <hr />
            <div
              data-bs-spy="scroll"
              data-bs-target="#navbar-example2"
              data-bs-offset="0"
              class="scrollspy-example"
              tabindex="0"
            >
              <div class="container">
                <div class="row">
                  <div class="col">
                    <p
                      style={{ fontSize: 14, fontFamily: "italic" }}
                      id="overview"
                    >
                      {" "}
                      OXFORD is an institution which was envisaged to provide
                      young students with a healthy environment to nurture
                      themselves cognitively, intellectually, artistically and
                      athletically; along with also imbibing our moral and
                      cultural values, which will enable them to become
                      responsible global citizens of tomorrow. <br />
                      <br />
                      Our core teaching methodologies focus on a colourful blend
                      of traditional classroom learning combined with extensive
                      sports facilities, wide range of extra-curricular
                      activities, numerous social and cultural events and
                      similar special occasions, which ensure a holistic
                      approach to our students’ overall growth and progress.{" "}
                      <br /> <br />
                      Our caring teachers devote themselves to our students and
                      their needs every day; while also being their guardian,
                      mentor and friend. <br />
                      <br /> At OXFORD, our curriculum is designed with the
                      objective to constructively ignite our young students’
                      minds and positively navigate their vibrant energy towards
                      building a better and brighter future for India and the
                      World. <br />
                      <br /> We also firmly believe in creating an atmosphere
                      for collaborative learning; wherein our students grow with
                      experiences from the outside world - their surroundings,
                      their families, their peers and through their deep bonds
                      of friendship.
                    </p>
                  </div>
                  <div class="col">
                    <p style={{ fontSize: 14, fontFamily: "italic" }}>
                      The three strong <i>‘pillars’</i> below define us for who
                      we are: <br />
                      <b>Enthuse: </b>With our well-researched curriculum,
                      modern teaching methodologies and wide range of
                      extra-curricular activities and facilities, we, at OXFORD
                      constantly strive to enthuse our students with fascinating
                      learning experiences every single day.
                      <br />
                      <br /> We work tirelessly towards creating future leaders,
                      thinkers, change makers and givers, who would make a real
                      difference in tomorrow’s world while also upholding our
                      cultural traditions. <br />
                      <br />
                      <b>Enlighten:</b> At OXFORD, we aspire to provide our
                      students with holistic education across the learning
                      spectrum. We guide our students to nurture their own
                      interests and then channelise their fresh energy towards
                      harnessing their special talents and abilities; whether
                      academic or otherwise. As a result of this organic
                      process, our students also get an insight into their own
                      strengths and weaknesses, their likes and dislikes, their
                      passion and motivation. As the old saying goes, “Knowing
                      others is wisdom, knowing thyself is enlightenment.”
                      <br />
                      <br /> <b>Empower:</b> Empowering students for a better
                      tomorrow is at the heart of the OXFORD world. <br />
                      <br />
                      It is our belief, our mantra and our inspiration.
                    </p>
                  </div>
                </div>{" "}
              </div>
            </div>{" "}
          </>
        ) : (
          <></>
        )}
        {currentUrl.hash === "#ourTeam" ? (
          <>
            <div className="text-center text-primary display-4" id="ourTeam">
              Our Team{" "}
            </div>
            <hr />
            <div>
              <p className="text-center">
                Our team consists of experienced and dynamic individuals, who
                drive the institution with a passion to impart quality education
                and are committed to the overall development of the students at
                OXFORD.
              </p>
              <div class="row row-cols-1 row-cols-md-2 g-4">
                <div class="col">
                  <div class="card">
                    <img
                      src="https://wallpaperaccess.com/full/4225690.jpg"
                      class="card-img-top"
                      alt="Hollywood Sign on The Hill"
                    />
                    <div class="card-body">
                      <h5 class="card-title text-center">Rustom Kerawalla</h5>
                      <p class="card-text text-center">Founder Chairman</p>
                    </div>
                  </div>
                </div>
                <div class="col">
                  <div class="card">
                    <img
                      src="https://w.forfun.com/fetch/2e/2e15ba7a8cf746b2fe8d149066eec0a4.jpeg"
                      class="card-img-top"
                      alt="Palm Springs Road"
                    />
                    <div class="card-body">
                      <h5 class="card-title text-center">
                        Kavita Sahay Kerawalla
                      </h5>
                      <p class="card-text text-center">Vice-chairperson</p>
                    </div>
                  </div>
                </div>
                <div class="col">
                  <div class="card">
                    <img
                      src="https://wallpaperaccess.com/full/2058400.jpg"
                      class="card-img-top"
                      alt="Los Angeles Skyscrapers"
                    />
                    <div class="card-body">
                      <h5 class="card-title text-center">Dr. Reeta Sonawat</h5>
                      <p class="card-text text-center">
                        Director – Early Childhood Education
                      </p>
                    </div>
                  </div>
                </div>
                <div class="col">
                  <div class="card">
                    <img
                      src="https://w.forfun.com/fetch/1d/1dc52e508856433a92f9040ee170b700.jpeg"
                      class="card-img-top"
                      alt="Skyscrapers"
                    />
                    <div class="card-body">
                      <h5 class="card-title text-center">Anne Dias</h5>
                      <p class="card-text text-center">
                        Director – Special Projects, Academics, Continuous
                        Professional Development
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>{" "}
          </>
        ) : (
          <></>
        )}
        {currentUrl.hash === "#visionMission" ? (
          <>
            {" "}
            <div
              className="text-center text-primary display-4"
              id="visionMission"
            >
              Vision & Mission{" "}
            </div>
            <hr />
            <div>
              <h3 className="text-center">Vision</h3> <br />
              <p className="text-center">
                Transforming lives globally by redefining knowledge ecosystems
                through passion and innovation.
              </p>{" "}
              <br />
              <h3 className="text-center">Mission</h3>
              <br />
              <p className="text-center">
                To provide the highest quality of education in a safe, secure
                and nurturing environment; to help our students develop into
                progressive thinkers and lifelong bearers of skills that will
                prepare them for the challenges of a dynamically changing world.
              </p>
            </div>
          </>
        ) : (
          <></>
        )}
        <Map location={location} zoomLevel={17} />
        <FooterLinks />
        <SocialFollow />
        <Footer />{" "}
      </div>
    </React.Fragment>
  );
};

export default AboutUs;