import React from "react";
import Dashboard from "../Dashboard";
import KarateImage from "../../Resources/Karate.jpg"

import "../../Styles/styles.css";
import ServicesDropdown from "./ServicesDropdown";



const Karate = ( ) => {
    return ( 
        <React.Fragment>
         <Dashboard />
        <ServicesDropdown />
          <h1 className="mx-auto" style={{ width: "200px", marginTop: '15px' }}>
            KARATE
          </h1> 
            <p className="homeText">
            Karate (空手) (/kəˈrɑːti/; Japanese pronunciation: [kaɾate] (listen); Okinawan pronunciation: [kaɽati]), also Karate-do (空手道, Karate-dō) is a martial art developed in the Ryukyu Kingdom. It developed from the indigenous Ryukyuan martial arts (called te (手), "hand"; tii in Okinawan) under the influence of Chinese martial arts, particularly Fujian White Crane.[1][2] Karate is now predominantly a striking art using punching, kicking, knee strikes, elbow strikes, and open-hand techniques such as knife-hands, spear-hands, and palm-heel strikes. Historically, and in some modern styles, grappling, throws, joint locks, restraints, and vital-point strikes are also taught.[3] A karate practitioner is called a karate-ka
            </p>
            <div className="text-center">
        <img className="img-thumbnail" src={KarateImage} alt="karate_image" /> </div>
        </React.Fragment>
    )
}


export default Karate;