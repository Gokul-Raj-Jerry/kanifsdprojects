import React from "react";
import Dashboard from "../Dashboard";
import ServicesDropdown from "./ServicesDropdown";
import ZumbaImage from "../../Resources/Zumba.jpg"

import "../../Styles/styles.css";

const Zumba = () => {
  return (
    <React.Fragment>
         <Dashboard />
        <ServicesDropdown />
          <h1 className="mx-auto" style={{ width: "200px", marginTop: '15px' }}>
            ZUMBA
          </h1>
        <p className="homeText">
        Zumba is a fitness program that involves cardio and Latin-inspired dance. It was founded by Colombian dancer and choreographer Beto Pérez in 2001,[1] It currently has 200,000 locations, with 15 million people taking classes weekly, and is located in 180 countries.[2] [3]Zumba is a trademark owned by Zumba Fitness, LLC.
        </p>
        <div className="text-center">
        <img className="img-thumbnail" src={ZumbaImage} alt="zumba_image" /> </div>
    </React.Fragment>
  );
};

export default Zumba;
