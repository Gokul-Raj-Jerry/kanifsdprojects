import React from "react";
import Dashboard from "../Dashboard";
import LanguageImage from "../../Resources/Language.jpg";
import ServicesDropdown from "./ServicesDropdown";

import "../../Styles/styles.css";

const Language = () => {
  return (
    <React.Fragment>
          <Dashboard />
        <ServicesDropdown />
          <h1 className="mx-auto" style={{ width: "200px", marginTop: '15px' }}>
            LANGUAGE SUBJECTS
          </h1>
        <p className="homeText">
          There are different ways to categorize education: for example, by age
          or subject. One way is to divide it into formal education, non-formal
          education, and informal education.
        </p>
 
      <div className="text-center">
        <img
          className="img-thumbnail"
          src={LanguageImage}
          alt="language_image"
        />{" "}
      </div>
    </React.Fragment>
  );
};

export default Language;
