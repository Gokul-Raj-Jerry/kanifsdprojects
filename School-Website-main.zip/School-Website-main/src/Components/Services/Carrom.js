import React from "react";
import Dashboard from "../Dashboard";
import CarromImage from "../../Resources/Carrom.jpg"
import ServicesDropdown from "./ServicesDropdown";
import "../../Styles/styles.css";


const Carrom = ( ) => {
    return ( 
        <React.Fragment>
     <Dashboard />
        <ServicesDropdown />

          <h1 className="mx-auto" style={{ width: "200px", marginTop: '15px' }}>
            CARROM
          </h1>   
            <p className="homeText">
            Carrom is a tabletop game of Indian origin in which players flick discs, attempting to knock them to the corners of the board. The game is very popular in the Indian subcontinent, and is known by various names in different languages. In South Asia, many clubs and cafés hold regular tournaments. Carrom is very commonly played by families, including children, and at social functions. Different standards and rules exist in different areas. It became very popular in the United Kingdom and the Commonwealth during the early 20th century.
            </p>

        <div className="text-center">
        <img className="img-thumbnail" src={CarromImage} alt="carrom_image" />
      </div>
        </React.Fragment>
    )
}


export default Carrom;