import React from "react";
import Dashboard from "../Dashboard";
import ServicesDropdown from "./ServicesDropdown";
import WesternDanceImage from "../../Resources/Western.jpg"

import "../../Styles/styles.css";



const Western = ( ) => {
    return ( 
        <React.Fragment>
        <Dashboard />
        <ServicesDropdown />
          <h1 className="mx-auto" style={{ width: "200px", marginTop: '15px' }}>
            WESTERN
          </h1>
            <p className="homeText">
            Dance is an art form consisting of sequences of body movements with aesthetic and often symbolic value, either improvised or purposefully selected.[nb 1] Dance can be categorized and described by its choreography, by its repertoire of movements, done simultaneously with music or with instruments; or by its historical period or place of origin.
            </p>
            <div className="text-center">
        <img className="img-thumbnail" src={WesternDanceImage} alt="western_dance_image" /> </div>
        </React.Fragment>
    )
}


export default Western;