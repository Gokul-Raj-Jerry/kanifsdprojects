import React from "react";
import Dashboard from "../Dashboard";
import ServicesDropdown from "./ServicesDropdown";
import GuitarImage from "../../Resources/Guitar.jpg"

import "../../Styles/styles.css";

const Guitar = ( ) => {
    localStorage.setItem("serviceMenu","guitar")
    return ( 
        <React.Fragment>
         <Dashboard />
        <ServicesDropdown />
          <h1 className="mx-auto" style={{ width: "200px", marginTop: '15px' }}>
            GUITAR
          </h1>  
            <p className="homeText">
            The guitar is a fretted musical instrument that typically has six strings. It is usually held flat against the player's body and played by strumming or plucking the strings with the dominant hand, while simultaneously pressing selected strings against frets with the fingers of the opposite hand. A plectrum or individual finger picks may also be used to strike the strings. The sound of the guitar is projected either acoustically, by means of a resonant chamber on the instrument, or amplified by an electronic pickup and an amplifier.
            </p>
            <div className="text-center">
        <img className="img-thumbnail" src={GuitarImage} alt="guitar_image" /> </div>
        </React.Fragment>
    )
}


export default Guitar;