import React from "react";
import Dashboard from "../Dashboard";
import ServicesDropdown from "./ServicesDropdown";
import YogaImage from "../../Resources/Yoga.jpg"

import "../../Styles/styles.css";



const Yoga = ( ) => {
    return ( 
        <React.Fragment>
            <Dashboard />
        <ServicesDropdown />
          <h1 className="mx-auto" style={{ width: "200px", marginTop: '15px' }}>
            YOGA
          </h1>
            <p className="homeText">
            Yoga (/ˈjoʊɡə/ (listen);[1] Sanskrit: योग, lit. 'yoke' or 'union' pronounced [joːɡɐ]) is a group of physical, mental, and spiritual practices or disciplines which originated in ancient India and aim to control (yoke) and still the mind, recognizing a detached witness-consciousness untouched by the mind (Chitta) and mundane suffering (Duḥkha). There is a wide variety of schools of yoga, practices, and goals[2] in Hinduism, Buddhism, and Jainism,[3][4][5] and traditional and modern yoga is practiced worldwide
            </p>
            <div className="text-center">
        <img className="img-thumbnail" src={YogaImage} alt="yoga_image" /> </div>
        </React.Fragment>
    )
}


export default Yoga;