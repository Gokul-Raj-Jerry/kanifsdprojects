import React from "react";
import Dashboard from "../Dashboard";
import ChessImage from "../../Resources/Chess.jpg";
import "../../Styles/styles.css";
import ServicesDropdown from "./ServicesDropdown";

const Chess = () => {
  return (
    <React.Fragment>
     <Dashboard />
        <ServicesDropdown />

          <h1 className="mx-auto" style={{ width: "200px", marginTop: '15px' }}>
            CHESS
          </h1>   
        <p className="homeText">
          Chess is a board game for two players, called White and Black, each
          controlling an army of chess pieces in their color, with the objective
          to checkmate the opponent's king. It is sometimes called international
          chess or Western chess to distinguish it from related games, such as
          xiangqi (Chinese chess) and shogi (Japanese chess). The recorded
          history of chess goes back at least to the emergence of a similar
          game, chaturanga, in seventh-century India. The rules of chess as we
          know them today emerged in Europe at the end of the 15th century, with
          standardization and universal acceptance by the end of the 19th
          century. Today, chess is one of the world's most popular games, played
          by millions of people worldwide.
        </p>

      <div className="text-center">
        <img className="img-thumbnail" src={ChessImage} alt="tuition_image" />
      </div>
    </React.Fragment>
  );
};

export default Chess;
