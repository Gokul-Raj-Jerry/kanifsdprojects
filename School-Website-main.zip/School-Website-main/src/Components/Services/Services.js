import { Link } from "react-router-dom";
import React from "react";
import Dashboard from "../Dashboard";
import ServicesDropdown from "./ServicesDropdown";

const Services = () => {
  localStorage.setItem("menu","services");

  const storedItem =  `${localStorage.getItem("menu")}`;

  return (
    <React.Fragment>
          <Dashboard />
        <ServicesDropdown />
          <h1 className="mx-auto" style={{ width: "200px", marginTop: '15px' }}>
            SERVICES
          </h1>
      <div className="homeText">
        <h2>
          We offer world class coaching facilities for all the below mentioned
          skills
        </h2>
        <ul className="list-group list-group-flush">
       <li className=" list-group-item bg-light text-white link-secondary"> <Link to={`/${storedItem}/academics`}>Academic tutions</Link></li>
          <li className=" list-group-item bg-light textWhite"><Link to={`/${storedItem}/core`}>Core Subject Tuitions</Link></li>
          <li className="list-group-item bg-light textWhite"><Link to={`/${storedItem}/language`}>Language Tuitions</Link></li>
          <li className=" list-group-item bg-light textWhite"><Link to={`/${storedItem}/dance`}>Dance</Link></li>
          <li className=" list-group-item bg-light textWhite"><Link to={`/${storedItem}/music`}>Music</Link></li>
          <li className=" list-group-item bg-light textWhite"><Link to={`/${storedItem}/karate`}>Karate</Link></li>
          <li className=" list-group-item bg-light textWhite"><Link to={`/${storedItem}/guitar`}>Guitar</Link></li>
          <li className=" list-group-item bg-light textWhite"><Link to={`/${storedItem}/yoga`}>Yoga</Link></li>
          <li className=" list-group-item bg-light textWhite"><Link to={`/${storedItem}/zumba`}>Zumba</Link></li>
          <li className=" list-group-item bg-light textWhite"><Link to={`/${storedItem}/western`}>Western</Link></li>
          <li className="list-group-item bg-light textWhite"><Link to={`/${storedItem}/chess`}>Chess</Link></li>
          <li className=" list-group-item bg-light textWhite"><Link to={`/${storedItem}/carrom`}>Carrom Board</Link></li>
        </ul>
      </div>
    </React.Fragment>
  );
};

export default Services;
