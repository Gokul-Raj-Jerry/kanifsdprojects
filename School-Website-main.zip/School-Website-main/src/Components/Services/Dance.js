import React from "react";
import Dashboard from "../Dashboard";
import ServicesDropdown from "./ServicesDropdown";
import DanceImage from "../../Resources/Dance.jpg"

import "../../Styles/styles.css";



const Dance = ( ) => {
    return ( 
        <React.Fragment>
   <Dashboard />
        <ServicesDropdown />
          <h1 className="mx-auto" style={{ width: "200px", marginTop: '15px' }}>
            DANCE
          </h1>  
            <p className="homeText">
            Bharatanatyam (Tamil: பரதநாட்டியம்) is an Indian classical dance form that originated in Tamil Nadu. It is one of eight Indian classical dance forms recognized by the Sangeet Natak Akademi, and expresses South Indian religious themes and spiritual ideas, particularly of Shaivism and in general of Hinduism.
            </p>
            <div className="text-center">
        <img className="img-thumbnail" src={DanceImage} alt="dance_image" /> </div>
        </React.Fragment>
    )
}


export default Dance;