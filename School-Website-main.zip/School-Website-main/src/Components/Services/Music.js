import React from "react";
import Dashboard from "../Dashboard";
import ServicesDropdown from "./ServicesDropdown";
import MusicImage from "../../Resources/Music.jpg"

import "../../Styles/styles.css";



const Music = ( ) => {
    return ( 
        <React.Fragment>
            <Dashboard />
        <ServicesDropdown />
          <h1 className="mx-auto" style={{ width: "200px", marginTop: '15px' }}>
            MUSIC
          </h1>
            <p className="homeText">
            Carnatic music, known as Karnāṭaka saṃgīta or Karnāṭaka saṅgītam in the South Indian languages, is a system of music commonly associated with South India, including the modern Indian states of Karnataka, Andhra Pradesh, Telangana, Kerala and Tamil Nadu, and Sri Lanka.[1][2] It is one of two main subgenres of Indian classical music that evolved from ancient Hindu texts and traditions, particularly the Samaveda.[3] The other subgenre being Hindustani music, which emerged as a distinct form because of Persian or Islamic influences from Northern India. The main emphasis in Carnatic music is on vocal music; most compositions are written to be sung, and even when played on instruments, they are meant to be performed in gāyaki (singing) style.
            </p>
            <div className="text-center">
        <img className="img-thumbnail" src={MusicImage} alt="music_image" /> </div>
        </React.Fragment>
    )
}


export default Music;