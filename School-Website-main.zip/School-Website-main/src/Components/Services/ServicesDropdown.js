import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Select from "react-select";

const servicesDropdownOption = [
  { value: "academics", label: "Academics" },
  { value: "carrom", label: "Carrom" },
  { value: "chess", label: "Chess" },
  { value: "core", label: "Core" },
  { value: "dance", label: "Dance" },
  { value: "guitar", label: "Guitar" },
  { value: "karate", label: "Karate" },
  { value: "language", label: "Language" },
  { value: "music", label: "Music" },
  { value: "western", label: "Western" },
  { value: "yoga", label: "Yoga" },
  { value: "zumba", label: "Zumba" },
];

const ServicesDropdown = () => {
  const navigate = useNavigate();
  const [selectedOption, setSelectedOption] = useState(null);
  const handleSelectChange = (event) => {
    if (event.value === "academics") navigate("/services/academics");
    else if (event.value === "carrom") navigate("/services/carrom");
    else if (event.value === "chess") navigate("/services/chess");
    else if (event.value === "core") navigate("/services/core");
    else if (event.value === "dance") navigate("/services/dance");
    else if (event.value === "guitar") navigate("/services/guitar");
    else if (event.value === "karate") navigate("/services/karate");
    else if (event.value === "language") navigate("/services/language");
    else if (event.value === "music") navigate("/services/music");
    else if (event.value === "western") navigate("/services/western");
    else if (event.value === "yoga") navigate("/services/yoga");
    else if (event.value === "zumba") navigate("/services/zumba");
    setSelectedOption(event);
  };

  return (
    <div
      style={{
        marginLeft: 500,
        width: "300px",
        textAlign: "center",
        position: "relative",
      }}
    >
      <Select
        onChange={handleSelectChange}
        autosize={true}
        maxMenuHeight={220}
        placeholder="Select the service you need"
        defaultValue={selectedOption}
        options={servicesDropdownOption}
      />
    </div>
  );
};

export default ServicesDropdown;
