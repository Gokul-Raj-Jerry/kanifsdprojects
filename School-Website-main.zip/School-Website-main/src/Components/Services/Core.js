import React from "react";
import Dashboard from "../Dashboard";
import CoreImage from "../../Resources/Core.jpg"
import ServicesDropdown from "./ServicesDropdown";

import "../../Styles/styles.css";

const Core = () => {
  return (
    <React.Fragment>
   <Dashboard />
        <ServicesDropdown />

          <h1 className="mx-auto" style={{ width: "200px", marginTop: '15px' }}>
            CORE
          </h1>  
        <p className="homeText">
          Education studies encompasses various subfields like philosophy of
          education, pedagogy, psychology of education, sociology of education,
          economics of education, comparative education, and history of
          education.[186][187] The philosophy of education is the branch of
          applied philosophy that examines many of the basic assumptions
          underlying the theory and practice of education. It studies education
          both as a process and as a discipline while trying to provide exact
          definitions of its nature and how it differs from other phenomena. It
          further studies the purpose of education and its types as well as how
          to conceptualize teachers, students, and their relationship.[188] It
          includes educational ethics, which examines various moral issues in
          relation to education, for example, what ethical principles underlie
          it and how teachers should apply them to specific cases. The
          philosophy of education has a long history and was already discussed
          in ancient Greek philosophy.
        </p>
      <div className="text-center">
        <img className="img-thumbnail" src={CoreImage} alt="core_image" /> </div>
    </React.Fragment>
  );
};

export default Core;
