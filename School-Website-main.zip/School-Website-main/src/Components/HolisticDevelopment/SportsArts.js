

const SportsArts = () => {
  return (
    <>
          <div style={{ margin: 100, marginTop: 20 }}>
        <div className="text-center text-primary display-4" id="ourTeam">
        Sports and Performing Arts
        </div>
        <hr />
      <div className="col-md-6">
        <h2>Sports</h2>
        <p>
          Detailed attention is given to each sporting activity with respect to:
        </p>
        <ul>
          <li>On-field practice</li>
          <li>Visits to stadiums; Inter-School tournaments</li>
          <li>
            AV exposure to Animated and Live Matches and Coaching Techniques
          </li>
          <li>Access to Sports related books in the Library</li>
          <li>Tips on Sports Injuries and Diet</li>
          <li>Interaction with players of repute</li>
          <li>
            Inculcating team spirit, positive competitive spirit and leadership
            skills that lead to character building
          </li>
        </ul>
      {/*   <button classname="btn btn-primary">View Photo Gallery</button> */}
      </div>
      <div className="col-md-6">
        <h2>Performing Arts</h2>
        <p>
          We create a difference by integrating SPA (Sports & the Performing
          Arts) curriculum with in-classroom learning. At the primary level,
          this programme helps in developing physical fitness. These
          fundamentals are further developed through the secondary level, where
          students gear up to learn diverse activities which stand them in good
          stead for the future.
        </p>
       {/*  <button classname="btn btn-primary">View Photo Gallery</button> */}
      </div>
      <p>The essence of the programme is to: </p>
      <ul>
        <li>
          Introduce the child to education beyond the classroom through indoor
          sports, outdoor sports and performing art activities
        </li>
        <li>
          Expose the child to various sports; facilitating the development of
          kinesthetic and spatial skills
        </li>
        <li>
          Identify the inherent capability of the child in selected sports and
          provide specialised training in those areas
        </li>
        <li>
          Provide a platform for the child to excel in a sport/performing art
          and represent the school in inter-school and state level competitions
        </li>
      </ul>
      <p>
        VIBGYOR High is recognised as one of the few schools in the country to
        have a structured curriculum for Sports & the Performing Arts, which
        includes both inside and outside class experiences.
      </p>  </div>
    </> 
  );
};

export default SportsArts;
