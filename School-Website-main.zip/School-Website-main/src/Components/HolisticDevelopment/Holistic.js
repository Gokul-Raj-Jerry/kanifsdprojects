import Footer from "../Footer/Footer";
import FooterLinks from "../Footer/FooterLinks";
import HeaderLinks from "../Header/HeaderLinks";
import { useLocation } from "react-router-dom";
import Map from "../GoogleMap/Map";
import SocialFollow from "../SocialPlatform/SocialFollow";
import SportsArts from "./SportsArts";
import Exposure from "./Exposure";
import HolisticLinks from "./HolisticLinks";
import About from "../../Resources/About.jpg";

const Holistic = () => {
  const currentUrl = useLocation();

  const location = {
    address: '1600 Amphitheatre Parkway, Mountain View, california.',
    lat: 37.42216,
    lng: -122.08427,
  }
  return (
    <>
        
      <HeaderLinks />

      <div className="row">
        <div className="container">
          <div className="col-md-12">
            <img
              className="img-fluid w-100"
              style={{ height: 500 }}
              src="https://plus.unsplash.com/premium_photo-1661638205729-af31b3c87e6f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8Y29vcGVyYXRlfGVufDB8fDB8fHww&w=1000&q=80"
              alt="about-us"
            />
            <div className="mb-100">
              <h1
                class="carousel-caption"
                style={{
                    color: 'black',
                    fontFamily: "unset",
                    fontSize: 90,
                    top: 160,
                    bottom: "auto",
                    left: -200,
                    fontWeight: "bolder",
                }}
              >
                Holistic Development
              </h1>
            </div>
          </div>
        </div>    </div>       <HolisticLinks />
        {currentUrl.hash === "#sports" ? <SportsArts/> : <></>} 
{currentUrl.hash === "#exposure" ? <Exposure/> : <></>}

      <Map location={location} zoomLevel={17} />
      <FooterLinks />
      <SocialFollow />
      <Footer />
    </>
  );
};

export default Holistic;
