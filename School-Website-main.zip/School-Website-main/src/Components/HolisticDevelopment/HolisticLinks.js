import { Link } from "react-router-dom";
import * as Icon from "react-bootstrap-icons";
import { useLocation } from "react-router-dom";
import SportsArts from "./SportsArts"
import Exposure from "./Exposure"


const HolisticLinks = () => {
  const currentUrl = useLocation();

  return (
    <div>
      <div className="p-2 bg-danger text-white text-center">
        <a
          style={{
            textDecoration: "none",
           /*  fontSize: 30, */
            color: "white",
            marginTop: 2,
          }}
          href="#sports"
        >
          Sports and Performing Arts
        </a>
        <Icon.Dot />
        <a
          style={{
            textDecoration: "none",
        /*     fontSize: 30, */
            color: "white",
            marginTop: 2,
          }}
          href="#exposure"
        >
          Exposure
        </a>
       
      </div>
      {currentUrl.hash === "" ? (
          <>
            <SportsArts />
          </>
        ) : (
          <></>
        )}
    </div>
  );
};

export default HolisticLinks;
