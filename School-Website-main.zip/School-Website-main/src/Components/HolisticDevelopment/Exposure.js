

const Holistic = () => {

  return (
    <>
          <div style={{ margin: 100, marginTop: 20 }}>
        <div className="text-center text-primary display-4" id="ourTeam">
        Exposure
        </div>
        <hr />
      <div>
        <h2>Exposure</h2>
        <p>
          VIBGYOR High is a firm believer of experiential learning. Field trips
          and educational visits are organized at regular intervals for our
          young scholars. These are an extension to the concepts taught in
          class. It gives the students an opportunity to gain active and
          experiential learning and understanding of the topic. Students are
          given industrial exposure through direct interactive sessions with
          industry personnel and enriching interventions through participation
          in various events. Various Domestic and International trips are
          organised to supplement their classroom learning. Students at VIBGYOR
          High have participated in various International events like:
        </p>
        <ul>
          <li>NASA, Space Camp - Alabama, USA</li>
          <li>IYC - International Youth Conference, Mumbai</li>
          <li>MUN – Model United Nations, USA</li>
          <li>CIE World Conference - Renaissance Hotel, Mumbai</li>
          <li>Online Debate – Conducted by British Council, UK</li>
          <li>Presidential Classroom, USA</li>
        </ul>
        <p>
          The Indian and International Educational Trips to Goa, Kerala,
          Hyderabad, Malaysia and Egypt help in developing global awareness
          amongst our young learners. Our students are encouraged to use
          valuable research, problem-solving, and decision-making skills on such
          trips. Through such international exposures, they are given a platform
          to explore and develop skills to adapt to the dynamically changing
          world of today. Such exposures aim at breaking all geographical
          boundaries and provide a holistic education to our future Global
          Citizens.
        </p>
      </div>       </div>
    </>
  );
};

export default Holistic;
