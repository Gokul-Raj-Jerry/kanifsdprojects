import ScrollToTop from "react-scroll-to-top";

const Footer = () => {
  const d = new Date();
  return (
    <div  style={{marginTop:'auto'}}  className="p-2 bg-danger text-white text-center">
  <footer className="footer text-center mb-0">
      <div className="footer-content mb-0">
       A Vibgyor's Innovative Project   &copy;{d.getFullYear()} Copyrighted by Vibgyor
      </div> 
      <ScrollToTop smooth /> 
    </footer>
       </div>
  );
};

export default Footer;
