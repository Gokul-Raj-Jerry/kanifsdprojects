import "../../Styles/styles.css";
import { Link } from "react-router-dom";

const FooterLinks = () => {
  return (
    <div className="p-3 mb-2 bg-dark text-white text-center">
      <Link to="/academics">Academics</Link> &nbsp; &nbsp; &nbsp; &nbsp;
      <Link to="/holisticDevelopment">Holistic Development</Link> &nbsp; &nbsp; &nbsp; &nbsp;
      <Link to="/newsLetter">News & Events</Link> &nbsp; &nbsp; &nbsp; &nbsp;
      <Link to="/admission">Admissions</Link> &nbsp; &nbsp; &nbsp; &nbsp;
   {/*    <Link>Infrastructure</Link> &nbsp; &nbsp; &nbsp; &nbsp; */}
      <Link to="/aboutUs">About Us</Link> &nbsp; &nbsp; &nbsp; &nbsp; <br/>  <br />
      <Link to="/why-kanishka?">Why Vibgyor?</Link> &nbsp; &nbsp; &nbsp; &nbsp;
      <Link to="/testimonials">Testimonials</Link> &nbsp; &nbsp; &nbsp; &nbsp;
      <Link to="/careers">Careers</Link> &nbsp; &nbsp; &nbsp; &nbsp;
      <Link to="/contactUs">Contact Us</Link> &nbsp; &nbsp; &nbsp; &nbsp;
      <Link to="/parentLogin">Parent Login</Link> &nbsp; &nbsp; &nbsp; &nbsp;
      <Link to="/privacy-policy">Privacy Policy</Link> &nbsp; &nbsp; &nbsp; &nbsp;<br /> <br />
      Contact Us On : 888-645-9510
    </div>
  );
};

export default FooterLinks;
