const TTProgram = () => {
  return (
    <>
      <div style={{ margin: 100, marginTop: 20 }}>
        <div className="text-center text-primary display-4" id="ourTeam">
          Teacher Training Programme
        </div>
        <hr />
        <div>
          <p>
            At VIBGYOR High, we believe a student grows as much as his teacher.
            We, therefore, ensure that our teachers constantly evolve, keep
            abreast with the changes in the education system. At regular
            intervals, we conduct the following training for our teachers across
            all the schools:
          </p>
          <p style={{ fontWeight: "bolder" }}>CISCE Council Training:</p>
          <ul>
            <li>
              Secondary section teachers participate in this training every year
              for various subjects, conducted at the regional office of the
              CISCE Council in Kolkata.
            </li>
          </ul>
          <p style={{ fontWeight: "bolder" }}>CIE Training</p>
          <ul>
            <li>
              Face to Face training, which is held in different cities of India
              where there is a sizeable concentration of CIE schools.
            </li>
            <li>Online training.</li>
          </ul>
          <p style={{ fontWeight: "bolder" }}>
            Counsellors & Special Educators
          </p>
          <ul>
            <li>
              We have Special Education/skills training for our teachers. This
              training is hosted by different agencies around the year.
            </li>
          </ul>
          <p style={{ fontWeight: "bolder" }}>AISM</p>
          <ul>
            <li>
              The Association of CISCE Schools Maharashtra region calls for cell
              meetings, which are hosted by various schools affiliated to the
              CISCE council. Here, senior teachers who are experts in different
              subjects (secondary section) give training/orientation; especially
              for Grade X.
            </li>
          </ul>
          <p style={{ fontWeight: "bolder" }}>Publishers Training</p>
          <ul>
            <li>
              Here, teachers interact with various publishers whose books are
              used by the CISCE schools in the secondary section. This helps
              them gain a better perspective on the syllabus.
            </li>
          </ul>
          <p style={{ fontWeight: "bolder" }}>MISA Training</p>
          <ul>
            <li>
              Mumbai International Schools Association conducts this training
              for all the CIE schools teachers/coordinators and examination
              officers. The aim is to be constantly updated with global
              standards.
            </li>
          </ul>
          <p style={{ fontWeight: "bolder" }}>
            Base Training (ONLY Science Training)
          </p>{" "}
          <ul>
            <li>
              This is conducted for various science subjects in the secondary
              section. Teachers from both the National & International Boards
              attend this training. This training is conducted by Bombay
              Association for Science and Education.
            </li>
          </ul>
        </div>
      </div>
    </>
  );
};

export default TTProgram;
