import HeaderLinks from "../Header/HeaderLinks";
import Map from "../GoogleMap/Map"
import FooterLinks from "../Footer/FooterLinks";
import SocialFollow from "../SocialPlatform/SocialFollow";
import Footer from "../Footer/Footer";
import { useLocation } from "react-router-dom";
import Links from "./Links";
import Learning from "./Learning";
import Inclusive from "./Inclusive";
import Curriculum from "./Curriculum";
import Philosophy from "./Philosophy";
import Policy from "./Policy";
import Ratio from "./Ratio";
import Safety from "./Safety";
import TTProgram from "./TTProgram";
import Testimonials from "./Testimonials";

const WhyKanishka = () => {
  const currentUrl = useLocation();
  console.log(currentUrl)
  const location = {
    address: '1600 Amphitheatre Parkway, Mountain View, california.',
    lat: 37.42216,
    lng: -122.08427,
  }
  return (
    <>
      <HeaderLinks />
     <div className="row">
          <div className="container">
            <div className="col-md-12">
              <img
                className="img-fluid w-100"
                style={{ height: 500 }}
                src="https://climate.copernicus.eu/sites/default/files/styles/hero_image_extra_large_2x/public/2019-12/iStock-1133836004.jpg?itok=y49Nigjn"
                alt="about-us"
              />
              <div className="mb-100">
                <h1
                  class="carousel-caption"
                  style={{
                    color: 'black',
                    fontFamily: "unset",
                    fontSize: 90,
                    top: 200,
                    bottom: "auto",
                    left: -500,
                    fontWeight: "bolder",
                  }}
                >
                  Why Vibgyor?
                </h1>
              </div>
            </div>
          </div>
        </div>
     <Links/>
     {currentUrl.hash === "#learning" ? <Learning/> : <></>}
     {currentUrl.hash === "#inclusive" ? <Inclusive /> : <></>}
     {currentUrl.hash === "#curriculum" ? <Curriculum /> : <></>}
     {currentUrl.hash === "#philosophy" ? <Philosophy /> : <></>}
     {currentUrl.hash === "#policies" ? <Policy /> : <></>}
     {currentUrl.hash === "#tsratio" ? <Ratio /> : <></>}
     {currentUrl.hash === "#safety" ? <Safety /> : <></>}
     {currentUrl.hash === "#program" ? <TTProgram /> : <></>}
     {currentUrl.hash === "#testimonials" ? <Testimonials /> : <></>}
     <Map location={location} zoomLevel={17} />
      <FooterLinks/>
      <SocialFollow/>
      <Footer/>   
   </>
  );
};

export default WhyKanishka;
