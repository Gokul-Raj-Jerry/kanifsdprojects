import About from "../../Resources/About.jpg";


const Image = () => {
    return (
        <div className="row">
        <div className="container">
          <div className="col-md-12">
            <img
              className="img-fluid w-100"
              style={{ height: 500 }}
              src={About}
              alt="about-us"
            />{" "}
            <h2 class="carousel-caption text-left">Why Vibgyor?</h2>
          </div>
        </div>
      </div>
    )
}
   
export default Image;