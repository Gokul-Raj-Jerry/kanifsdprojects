import Footer from "../Footer/Footer";
import FooterLinks from "../Footer/FooterLinks";
import HeaderLinks from "../Header/HeaderLinks";
import Map from "../GoogleMap/Map";
import SocialFollow from "../SocialPlatform/SocialFollow";
import Image from "./Image";
import Links from "./Links";
import InclusiveImage from "../../Resources/Inclusive.jpg"
import { Justify } from "react-bootstrap-icons";

const Inclusive = () => {
  const location = {
    address: '1600 Amphitheatre Parkway, Mountain View, california.',
    lat: 37.42216,
    lng: -122.08427,
  };
  return (
    <>
    <div>
       {/*  <HeaderLinks/>
        <Image/>
        <Links/> */}
         <div style={{ margin: 100, marginTop: 20, alignContent: Justify }}>
        <div className="text-center text-primary display-4" id="ourTeam">
          Inclusive Education
        </div>      <hr />
      <p>
        Inclusive Education forms the foundation of our learning system. The
        process of Inclusive Education is the act of including students of
        similar chronological ages in the same classes. Our Inclusive Education
        policies are in tune with the Ministry of Human Resource Development and
        UNESCO. The aim of inclusive quality education is to put an end to all
        forms of discrimination and thereby foster social cohesion. Our
        Inclusive Programme is mentored and monitored by the Resource Team -- a
        multidisciplinary panel of professionals who plan and implement
        individualised education programmes for students with special needs.
        They have the expertise in adaptive curriculum and co-operative
        learning. The Resource Team addresses behavioural and cognitive
        problems, while carefully monitoring the students to assess their level
        of disability. After analysing the student's needs, different diagnostic
        tools and behavioural modification techniques are used to develop the
        personal, educational and social skills of the students. This is done in
        close collaboration with teachers, parents and school administrators.
        The Resource Room consists of a Counselling Centre that provides
        vocational and professional guidance to all students. The team also
        initiates counselling programmes to help motivate the students to
        achieve academic excellence.
      </p>
      <div className="row">
        <div className="container">
          <div className="col-md-12 text-center">
            <img
              style={{ height: 500 }}
              src={InclusiveImage}
              alt="about-us"
            />{" "}
          </div>
        </div>
      </div> <br/>
      <p>
        The services we provide under our Inclusive Education programme include:
      </p>
      <ul>
        <li>Educational assistance for students with special needs.</li>
        <li>Psycho-educational assessments.</li>
        <li>Therapeutic-counselling services and remediation programme.</li>
      </ul>
      <p>Curriculum based ‘life skills programme’.</p>
      <ul>
        <li>Vocational guidance programme.</li>
        <li>
          Workshops, awareness and training programmes for the school community.
        </li>
      </ul>
    </div>  </div>
 {/*    <Map location={location} zoomLevel={17} />
       <FooterLinks/>
       <SocialFollow/>
       <Footer/> */}
       </>
  );
};

export default Inclusive;
