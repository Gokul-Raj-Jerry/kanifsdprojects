import Footer from "../Footer/Footer";
import FooterLinks from "../Footer/FooterLinks";
import HeaderLinks from "../Header/HeaderLinks";
   
import Map from "../GoogleMap/Map";
import SocialFollow from "../SocialPlatform/SocialFollow";
import Image from "./Image";
import Links from "./Links";
import PhilosophyImage from "../../Resources/Philosophy.jpg";

const Philosophy = () => {
  const location = {
    address: '1600 Amphitheatre Parkway, Mountain View, california.',
    lat: 37.42216,
    lng: -122.08427,
  }
  return (
    <>
     <div style={{ margin: 100, marginTop: 20 }}>
        <div className="text-center text-primary display-4" id="ourTeam">
          Philosophy
        </div>
        <hr />
      <div>
        <h2>Philosophy</h2>
        <p>VIBGYOR High offers:</p>
        <ul>
          <li>
            Balanced curriculum that incorporates arts, self-awareness,
            communication and physical education along with regular studies.
          </li>
          <li>
            State-of-the art infrastructure facilities, which are built to
            favour the harmonious growth of a young mind across several
            disciplines
          </li>
        </ul>
        <h2>We ensure that every child is equipped to develop his strengths and latent potential to match global levels.</h2>
        <div className="row">
          <div className="container">
            <div className="col-md-6">
              <img
                style={{ height: 250, width: 1100 }}
                src={PhilosophyImage}
                alt="about-us"
              />
            </div>
          </div>
        </div>
      </div>       </div>
    </>
  );
};

export default Philosophy;
