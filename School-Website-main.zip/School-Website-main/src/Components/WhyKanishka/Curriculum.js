import Footer from "../Footer/Footer";
import FooterLinks from "../Footer/FooterLinks";
import HeaderLinks from "../Header/HeaderLinks";
   
import Map from "../GoogleMap/Map";
import SocialFollow from "../SocialPlatform/SocialFollow";
import Image from "./Image";
import Links from "./Links";
import InclusiveImage from "../../Resources/Inclusive.jpg";

const Curriculum = () => {
  const location = {
    address: '1600 Amphitheatre Parkway, Mountain View, california.',
    lat: 37.42216,
    lng: -122.08427,
  }
  return (
    <>
      <div style={{ margin: 100, marginTop: 20 }}>
        <div className="text-center text-primary display-4" id="ourTeam">
          Curriculum
        </div>
        <hr />
      <div>
        <h2>Curriculum</h2>
        <p>
          We offer CISCE (Indian Certificate of Secondary Education), CBSE
          (Central Board of Secondary Education) and IGCSE (International
          General Certificate of Secondary Examination) curricula. Our
          learner-centric pedagogy approaches each child as a separate entity,
          as opposed to the conventional class-oriented approach. Our teachers
          guide students along every step, encouraging them to experiment and
          come upon their own strengths and weaknesses themselves. Students are
          put in an environment that catalyses their academic, physical,
          emotional, spiritual and intellectual growth. In keeping with our
          inclination towards quality and not quantity, a consistent ratio of
          ten students to one teacher is maintained, allowing adequate time and
          attention for each child to actualise the full capacity of his/her
          potential. We push ourselves constantly to devise unconventional
          methods that are both interactive and spread over a wide spectrum of
          topics; our objective is to develop a sense of context and objectivity
          in our children to equip them for larger challenges. Furthermore, a
          'Life Skills' Unit is included in every academic year, keeping the
          children persistently acquainted with a just, objective vision of
          society.
        </p>
        <p>Our unique curriculum is geared to:</p>
        <ul>
          <li>Map and initiate progress both personally and academically</li>
          <li>
            Create benchmarks for achievements that act as motivational tools
          </li>

          <li>Diagnose and work with learning disabilities</li>

          <li>Facilitate instruction and ease curriculum decisions</li>

          <li>Assist students with their own progress</li>

          <li>Provide guidance for parents</li>
        </ul>
        <h2>Culminating Activity</h2>
        <p>
          Culminating Activities form an integral part of the VIBGYOR High
          learning process. These activities are a part of the regular
          curriculum plan. Culminating activity includes a well-thought and
          organised conceptual network of skills, which essentially is an
          exhibition of students' understanding of the topic. 'Understanding'
          here is defined as the ability to use knowledge in novel situations.
          We believe macroscopic is better than microscopic, and we encourage
          and motivate our students to use knowledge as a reflective tool for
          making judgements rather than just assimilating isolated facts about
          various topics. In the concluding part of teaching units, a
          Culminating Activity is held for both the primary and secondary
          sections. The Culminating Activity covers topics related to languages,
          science and social science. To make this process easy, teaching aids
          and worksheets related to the unit are displayed in the classroom.
          Further, as a gesture of encouragement we exhibit students' art work,
          class activities and project work on all subjects pertaining to the
          unit during the activity. The objective of this activity is to
          showcase students' work and consolidate their learning. In this
          process, we also involve parents, who are invited to view the work
          done by their children and are encouraged to be proactive in these
          events.
        </p>
        <div className="row">
          <div className="container">
            <div className="col-md-12 text-center">
              <img
                style={{ height: 500 }}
                src={InclusiveImage}
                alt="about-us"
              />{" "}
            </div>
          </div>
        </div>
      </div>   </div>
    </>
  );
};

export default Curriculum;
