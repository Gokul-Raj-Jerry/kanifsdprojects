const Learning = () => {
  return (
    <>
      <div style={{ margin: 100, marginTop: 20 }}>
        <div className="text-center text-primary display-4" id="ourTeam">
          Learning System
        </div>
        <hr />
        <div >
          <p>
            The wholesome development of a child is the driving force of our
            entire team. And since starting early is better than catching up, we
            commence this initiative right from the primary level. Grades 1-4,
            therefore, employ a carefully constructed approach to child care and
            education. Every grade is a foundation to the next, and the
            curriculum works in accordance with that: cautiously shaping a
            child’s perspective to accommodate for and adapt to change.
          </p>
        </div>
        <p>For primary school, our focus is on:</p>
        <ul>
          <li>
            Building on a learning curve: VIBGYOR High lays emphasis on the
            overall intellectual, aesthetic, physical and cultural growth of the
            child.
          </li>
          <li>
            Introduction to a foundation course: This is designed to introduce
            cultural differences and recognise the need to adapt.
          </li>
          <li>
            Building academic challenges: Every step of the way is meant to draw
            the children closer to adequately handle the Council For The Indian
            School Certificate Examinations ( CISCE ), CBSE (Central Board of
            Secondary Education) and the International General Certificate of
            Secondary Education (IGCSE) examinations.
          </li>
        </ul>
        <p>
          During these formative academic years, we work consistently towards
          empowering our students for the real world. For this, we emphasis on:
        </p>
        <ul>
          <li>Well-researched projects.</li>
          <li>Field trips.</li>

          <li>
            Augment classroom instructions for the development of positive
            attitudes and healthy habits.
          </li>

          <li>
            Create an environment where students are encouraged to question,
            hypothesise, analyse and be creative.
          </li>
        </ul>
      </div>
    </>
  );
};

export default Learning;
