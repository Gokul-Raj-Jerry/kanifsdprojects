const Safety = () => {

  return (
    <>
          <div style={{ margin: 100, marginTop: 20 }}>
        <div className="text-center text-primary display-4" id="ourTeam">
          Safety
        </div>
        <hr />
      <div>
        <p>
          At VIBGYOR High, we believe that a student’s safety is our prime
          responsibility. Thus, we follow best in-class safety measures for our
          students and staff:
        </p>
        <p style={{fontWeight: 'bolder'}}>Access</p>
        <ul>
          <li>
            Controlled access to school buildings by locking or monitoring doors
            during school hours.
          </li>
          <li>
            Any non-school visitor is vetted at the security gate by noting the
            visit details and the reasons for the same. A Visitors pass/ID is
            issued.
          </li>

          <li>
            Specific days & timings are allocated for parents for walk-in entry
            to our schools.
          </li>

          <li>
            We ensure proper lighting in the corridors, passages and secluded
            sections of the school premises.{" "}
          </li>

          <li>Our campus is accessible for people with special needs.</li>
        </ul>
        <p style={{fontWeight: 'bolder'}}>Personnel</p>
        <ul>
          <li>
            Electronic systems and security personnel are on guard at all times
            during and after school hours.
          </li>
          <li>
            Ten security personnel including a lady security guard are on duty
            in equal shifts 24/7.
          </li>

          <li>
            The Primary section has two teachers in class at any given time. The
            students are assisted by at least one teacher for any out of class
            activity.
          </li>

          <li>
            Educational facilitators in primary classes are with the students at
            all times.{" "}
          </li>

          <li>Dedicated lift attendants.</li>
          <li>
            Dedicated male and female ancillary staff on each floor (male
            ancillary near the boys’ washroom and female ancillary staff near
            the girls’ washroom).
          </li>

          <li>
            Prompt access to medical care and a full-time nurse on the school
            premises.
          </li>

          <li>
            The presence of a full-time counsellor in school and various
            workshops conducted by the resource team, which consists of
            counsellors & special educators, creates awareness against any kind
            of abuse or bullying.
          </li>
        </ul>
        <p style={{fontWeight: 'bolder'}}>Protocol</p>
        <ul>
          <li>
            Unauthorised persons are treated as persona non-grata and are not
            allowed entry.
          </li>
          <li>
            Students are expected to wear badges or picture IDs at all times.
          </li>

          <li>
            Random checks of bags in secondary section for safety purpose.
          </li>

          <li>
            Teachers are assigned duties during breaks (snack & lunch) and
            during arrival & dispersal to monitor students.
          </li>

          <li>
            We maintain a zero-tolerance policy for sexual harassment, drugs,
            and other unacceptable issues.
          </li>
          <li>
            Conduct regular training for security staff, housekeeping,
            transport, and cafeteria staff.
          </li>

          <li>
            Regular audits are conducted to improve/maintain school safety.
          </li>

          <li>
            Regular rounds of the school premises are conducted by the
            authorities to ensure safety against any untoward incident/s.
          </li>

          <li>
            We follow a strict disciplinary policy to discourage any
            unacceptable behaviour.
          </li>
          <li>
            If a student has to leave early due to illness/injury/emergencies,
            he or she is only given permission after due verification with
            parents. We also issue a signed letter that works as an exit pass.
            This letter is authorised by the Principal after various levels of
            check by the class teacher, Nurse and Grade coordinator.
          </li>
        </ul>
      </div>
      </div>
    </>
  );
};

export default Safety;
