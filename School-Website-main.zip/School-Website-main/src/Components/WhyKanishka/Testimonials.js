const Testimonials = () => {

    return (
        <>
          <div style={{ margin: 100, marginTop: 20 }}>
        <div className="text-center text-primary display-4" id="ourTeam">
        Testimonials of our Wonderful Parents
        </div>
        <hr/>
        <div className="row">
          <div className="container">
            <div className="col-md-12">
        <div className="video-responsive text-center">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/cNfINi5CNbY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
      </div>
      </div>
      </div>
      <div className="container">
            <div className="col-md-12">
        <div className="video-responsive text-center">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/bqnlpDEmFUU" title="YouTube video player" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
      </div>
      </div>
      </div>
      <div className="container">
            <div className="col-md-12">
        <div className="video-responsive text-center">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/bqnlpDEmFUU" title="YouTube video player" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
      </div>
      </div>
      </div>
      </div>       </div>
            </>
    )
}

export default Testimonials;