const Ratio = () => {

  return (
    <>
     <div style={{ margin: 100, marginTop: 20 }}>
        <div className="text-center text-primary display-4" id="ourTeam">
          Teacher Student Ratio
        </div>
        <hr />
      <div>
        <h2>Teacher Student Ratio</h2>
        <p>
          Our school appreciates and welcomes individuality. In order to allow a
          child to flourish within his/her own sphere of perception and possibly
          polish that approach, we work in a small class set-up, accommodating
          for sufficient attention for each child.
        </p>
        <p>
          Our motive is to allow students direct access to achievements by
          constantly providing opportunity. Our teachers, thus, ensure that they
          understand every student individually. Academic research confirms that
          students who receive integral education, more often than not follow a
          balanced growth curve. We have interventions, teaching strategies and
          support systems to meet the specific learning styles of an individual
          child. Small classes enable our teachers to implement a curriculum
          that is rich with activities, allowing physical experience to be the
          foundation of their learning. Further, this allows space for more
          meaningful peer interaction and ensures participation, which is
          generally a challenge in large capacity classrooms. To be prompt is to
          be approachable to a child; which is why personalised and immediate
          feedback is a habit in classes across the grades. It also enables the
          teacher to detect emotional blocks/problems, if any, and resolve them
          at the earliest.
        </p>
        
      </div>
      </div>
    </>
  );
};

export default Ratio;
