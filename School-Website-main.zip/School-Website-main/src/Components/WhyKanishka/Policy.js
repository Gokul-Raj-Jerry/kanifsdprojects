const Policy = () => {
  return (
    <>
     <div style={{ margin: 100, marginTop: 20 }}>
        <div className="text-center text-primary display-4" id="ourTeam">
          Policy
        </div>
        <hr />
      <div>
        <h2>Policies</h2>
        <p>
          Each child is unique and requires a different level of attention. This
          individuality needs to be both celebrated and reinforced through
          focused guidance and steady opportunity during their developing years.
          At VIBGYOR High, inclusion advocates the process of enabling all
          students, including those with special educational needs, to learn and
          participate effectively within the mainstream school system. Inclusion
          is an effort students go to regular school, where they receive
          specially designed instructions and support alongside the standard
          curriculum.
        </p>
        <p>
          The following policies, thus, become the cornerstone of our Inclusive
          philosophy:
        </p>
        <ul>
          <li>Inclusion is a continual process, not a momentary one.</li>
          <li>
            Strengthening and sustaining the participation of students,
            teachers, school administrators, parents and community members is a
            duty and a responsibility.
          </li>
          <li>
            Persistent initiative to identify and reduce the barriers to
            learning and participation.{" "}
          </li>
          <li>
            Providing an accessible curriculum and appropriate training
            programmes for teachers and students.
          </li>

          <li>
            Offering constant support, direction and encouragement to the
            students and teaching faculty.{" "}
          </li>
        </ul>
        <p>
          Under the Inclusive Education policy, VIBGYOR High conducts several
          workshops and seminars for students, teachers and parents. At the core
          of the Inclusive Programme is the Resource Team, a multidisciplinary
          group of dedicated professionals, who provide a far-reaching programme
          for students with special needs. Our team of experts address common
          behavioural and cognitive problems. The team uses different diagnostic
          tools and behavioural modification techniques to develop the inter-
          and intra-personal skills of each student so as to in-turn progress
          personal and educational development. We also have a dedicated
          Resource room that houses a Counselling Centre, which provides
          vocational and professional guidance to all our students. The team
          also implements counselling programmes that promote the students'
          academic achievements.
        </p>
        <p>This versatile team offers the following services:</p>{" "}
        <ul>
          <li>Educational assistance for students with special needs.</li>
          <li>Psycho-educational assessments.</li>
          <li>Therapeutic counselling services and remediation programme.</li>
          <li>Curriculum-based life skills programme.</li>
          <li>Vocational guidance programme.</li>
          <li>
            Workshops, awareness and training programmes for the school
            community.
          </li>
        </ul>
      </div>         </div>
    </>
  );
};

export default Policy;
