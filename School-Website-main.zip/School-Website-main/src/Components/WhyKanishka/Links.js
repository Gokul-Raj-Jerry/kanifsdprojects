import * as Icon from "react-bootstrap-icons";
import { useLocation } from "react-router-dom";
import Learning from "./Learning"

const Links = () => {
  let currentUrl = useLocation();

    return (
      <>
        <div className="p-2 bg-danger text-white text-center">
         <a
            style={{ textDecoration: "none", /* fontSize: 30 , */  color: "white", marginTop: 2 }}
            href="#learning"
          >
          Learning System
        </a>    <Icon.Dot />
        <a
            style={{ textDecoration: "none",  /* fontSize: 30, */ color: "white", marginTop: 2 }}
            href="#inclusive"
          >
          Inclusive Education
        </a>    <Icon.Dot />
        <a
            style={{ textDecoration: "none", /* fontSize: 30, */ color: "white", marginTop: 2 }}
            href="#curriculum"
          >
          Curriculum
        </a>    <Icon.Dot /><a
            style={{ textDecoration: "none", /* fontSize: 30, */ color: "white", marginTop: 2 }}
            href="#philosophy"
          >
          Philosophy
        </a>    <Icon.Dot /><a
            style={{ textDecoration: "none", /* fontSize: 30, */ color: "white", marginTop: 2 }}
            href="#policies"
          >
          Policies
        </a>    <Icon.Dot />
   <br/>      <a
            style={{ textDecoration: "none", /* fontSize: 30, */ color: "white", marginTop: 2 }}
            href="#tsratio"
          >
          Teacher Student Ratio
        </a>    <Icon.Dot /><a
            style={{ textDecoration: "none", /* fontSize: 30, */ color: "white", marginTop: 2 }}
            href="#safety"
          >
          Safety
        </a>    <Icon.Dot /><a
            style={{ textDecoration: "none", /* fontSize: 30, */ color: "white", marginTop: 2 }}
            href="#program"
          >
          Teacher Training Program
        </a>    <Icon.Dot /><a
            style={{ textDecoration: "none", /* fontSize: 30, */ color: "white", marginTop: 2 }}
            href="#testimonials"
          >
          Testimonials
        </a>    
      </div>
{currentUrl.hash === "" ? (
  <>
 {/*    {" "}
    <div className="text-center text-primary display-4" id="overview">
      Overview
    </div>
    <hr />
    <div
      data-bs-spy="scroll"
      data-bs-target="#navbar-example2"
      data-bs-offset="0"
      class="scrollspy-example"
      tabindex="0"
    >
      <div class="container">
        <div class="row">
          <div class="col">
            <p
              style={{ fontSize: 14, fontFamily: "italic" }}
              id="overview"
            >
              {" "}
              OXFORD is an institution which was envisaged to provide
              young students with a healthy environment to nurture
              themselves cognitively, intellectually, artistically and
              athletically; along with also imbibing our moral and
              cultural values, which will enable them to become
              responsible global citizens of tomorrow. <br />
              <br />
              Our core teaching methodologies focus on a colourful blend
              of traditional classroom learning combined with extensive
              sports facilities, wide range of extra-curricular
              activities, numerous social and cultural events and
              similar special occasions, which ensure a holistic
              approach to our students’ overall growth and progress.{" "}
              <br /> <br />
              Our caring teachers devote themselves to our students and
              their needs every day; while also being their guardian,
              mentor and friend. <br />
              <br /> At OXFORD, our curriculum is designed with the
              objective to constructively ignite our young students’
              minds and positively navigate their vibrant energy towards
              building a better and brighter future for India and the
              World. <br />
              <br /> We also firmly believe in creating an atmosphere
              for collaborative learning; wherein our students grow with
              experiences from the outside world - their surroundings,
              their families, their peers and through their deep bonds
              of friendship.
            </p>
          </div>
          <div class="col">
            <p style={{ fontSize: 14, fontFamily: "italic" }}>
              The three strong <i>‘pillars’</i> below define us for who
              we are: <br />
              <b>Enthuse: </b>With our well-researched curriculum,
              modern teaching methodologies and wide range of
              extra-curricular activities and facilities, we, at OXFORD
              constantly strive to enthuse our students with fascinating
              learning experiences every single day.
              <br />
              <br /> We work tirelessly towards creating future leaders,
              thinkers, change makers and givers, who would make a real
              difference in tomorrow’s world while also upholding our
              cultural traditions. <br />
              <br />
              <b>Enlighten:</b> At OXFORD, we aspire to provide our
              students with holistic education across the learning
              spectrum. We guide our students to nurture their own
              interests and then channelise their fresh energy towards
              harnessing their special talents and abilities; whether
              academic or otherwise. As a result of this organic
              process, our students also get an insight into their own
              strengths and weaknesses, their likes and dislikes, their
              passion and motivation. As the old saying goes, “Knowing
              others is wisdom, knowing thyself is enlightenment.”
              <br />
              <br /> <b>Empower:</b> Empowering students for a better
              tomorrow is at the heart of the OXFORD world. <br />
              <br />
              It is our belief, our mantra and our inspiration.
            </p>
          </div>
        </div>{" "}
      </div>
    </div>{" "} */}<Learning/>
  </>
) : (
  <></>
)}
</>
    )
}

export default Links;