import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./Components/Home/Home";
import Contact from "./Components/ContactUs/Contact";
import AboutUs from "./Components/About Us/AboutUs";
import WhyKanishka from "./Components/WhyKanishka/WhyKanishka";
import Services from "./Components/Services/Services";
import Careers from "./Components/Careers/Careers";
import ErrorPage from "./Components/ErrorPage/ErrorPage";
import StudentLogin from "./Components/Login/StudentLogin";
import StaffLogin from "./Components/Login/StaffLogin";
import Logout from "./Components/Login/Logout";
import PrivacyPolicy from "./Components/PrivacyPolicy/PrivacyPolicy";
import Signup from "./Components/Login/Signup";
import "../src/Styles/styles.css";
import Reset from "./Components/Login/ResetPassword";
import ParentLogin from "./Components/Login/ParentLogin";
/* import ColorSchemeToggle from "./Components/Theme/ColorSchemeToggle"; */
import Newsletter from "./Components/NewsLetter/NewsLetter";
import Learning from "./Components/WhyKanishka/Learning";
import Inclusive from "./Components/WhyKanishka/Inclusive";
import Curriculum from "./Components/WhyKanishka/Curriculum";
import Philosophy from "./Components/WhyKanishka/Philosophy";
import Policy from "./Components/WhyKanishka/Policy";
import Ratio from "./Components/WhyKanishka/Ratio";
import Safety from "./Components/WhyKanishka/Safety";
import TTProgram from "./Components/WhyKanishka/TTProgram";
import Testimonials from "./Components/WhyKanishka/Testimonials";
import AreYouTheOne from "./Components/Careers/AreYouTheOne";
import GrowAtOxford from "./Components/Careers/GrowAtOxford";
import ProudOxfordian from "./Components/Careers/ProudOxfordian";
import CareerOpportunity from "./Components/Careers/CareerOpportunity";
import Academics from "./Components/Academics/Academics";
import CBSE from "./Components/Academics/CBSE";
import CISE from "./Components/Academics/CISE";
import Cambridge from "./Components/Academics/Cambridge";
import Holistic from "./Components/HolisticDevelopment/Holistic";
import SportsArts from "./Components/HolisticDevelopment/SportsArts";
import Exposure from "./Components/HolisticDevelopment/Exposure";
import Admission from "./Components/Admissions/Admission";
import LifeatOxford from "./Components/Careers/LifeatOxford";

const App = () => {
  return (
    <React.Fragment>
      <div className="content-container">
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="home" element={<Home />} />
            <Route path="aboutUs" element={<AboutUs />} />
            <Route path="why-vibgyor" element={<WhyKanishka />} />
            <Route path="services" element={<Services />} />
            <Route path="contactUs" element={<Contact />} />
            <Route path="studentLogin" element={<StudentLogin />} />
            <Route path="staffLogin" element={<StaffLogin />} />
            <Route path="parentLogin" element={<ParentLogin />} />
            <Route path="resetPassword" element={<Reset />} />
            <Route path="signup" element={<Signup />} />
            <Route path="logout" element={<Logout />} />
            <Route path="newsLetter" element={<Newsletter />} />
            <Route path="learningSystem" element={<Learning />} />
            <Route path="inclusive" element={<Inclusive />} />
            <Route path="curriculum" element={<Curriculum />} />
            <Route path="philosophy" element={<Philosophy />} />
            <Route path="policy" element={<Policy />} />
            <Route path="ratio" element={<Ratio />} />
            <Route path="safety" element={<Safety />} />
            <Route path="program" element={<TTProgram />} />
            <Route path="testimonials" element={<Testimonials />} />
            <Route path="careers" element={<Careers />} />
            <Route path="areYouTheOne" element={<AreYouTheOne />} />
            <Route path="lifeAtK" element={<LifeatOxford />} />
            <Route path="grow" element={<GrowAtOxford />} />
            <Route path="proudToBe" element={<ProudOxfordian />} />
            <Route path="careerOpportunity" element={<CareerOpportunity />} />
            <Route path="privacy-policy" element={<PrivacyPolicy />} />
            <Route path="academics" element={<Academics />} />
            <Route path="cbse" element={<CBSE />} />
            <Route path="cise" element={<CISE />} />
            <Route path="cambridge" element={<Cambridge />} />
            <Route path="holisticDevelopment" element={<Holistic />} />
            <Route path="sportsArts" element={<SportsArts />} />
            <Route path="exposure" element={<Exposure />} />
            <Route path="admission" element={<Admission />} />
            <Route path="*" element={<ErrorPage />} />
          </Routes>
          <br />
        </BrowserRouter>
      </div>
    </React.Fragment>
  );
};

export default App;
