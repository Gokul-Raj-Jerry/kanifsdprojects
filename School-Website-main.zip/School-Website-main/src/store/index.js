import { createStore } from "redux";

const authReducer = (state = { isLoggedIn: false }, action) => {
  if (action.type === "LoggedIn") {
    return {
        isLoggedIn: true,
    };
  }
  return state;
};

const store = createStore(authReducer);

export default store;
