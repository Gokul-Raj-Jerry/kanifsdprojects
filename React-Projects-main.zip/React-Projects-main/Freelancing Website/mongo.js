const mongoose=require("mongoose");
const env = require("dotenv");
env.config();
const URL = process.env.mongoURL;
mongoose

  .connect(URL, {

    useNewUrlParser: true,

  })

  .then(() => {

    console.log("Connected to database");

  })

  .catch((e) => console.log(e));


const newSchema=new mongoose.Schema({
    email:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true
    }
    
})

const collection = mongoose.model("test",newSchema)

module.exports=collection