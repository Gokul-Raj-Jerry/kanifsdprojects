import React from "react";
import Header from "../Header/Header";
import SocialFollow from "../SocialFollow/SocialFollow";
import Footer from "../Footer/Footer";
import FooterLinks from "../Footer/FooterLinks";
import YoutubeEmbed from "../YouTubeEmbed/YouTubeEmbed";
import HomeInfo from "./HomeInfo";
import AfterCarousel from "../AfterCarousel/AfterCarousel";
import NeedSomethingDone from "../NeedSomethingDone/NeedSomethingDone";
import WhatsGreatAboutIt from "../WhatsGreatAboutIt/WhatsGreatAboutIt";
import MakeItReal from "../MakeItReal/MakeItReal";
import GetWorkDone from "../GetWorkDone/GetWorkDone";
import AsSeenBy from "../AsSeenBy/AsSeenBy";
import Article from "../Article/Article";

const Home = () => {
  return (
    <div>
      <Header />
      <Article /> <br />
      <AfterCarousel />
      <NeedSomethingDone />
      <br />
      <br />
      <hr />
      <WhatsGreatAboutIt />
      <br />
      <br />
      <hr />
      <MakeItReal />
      <HomeInfo />
      <GetWorkDone />
      <br />
      <br />
      <hr />
      <AsSeenBy />
      <YoutubeEmbed />
      <FooterLinks />
      <SocialFollow />
      <Footer />
    </div>
  );
};

export default Home;
