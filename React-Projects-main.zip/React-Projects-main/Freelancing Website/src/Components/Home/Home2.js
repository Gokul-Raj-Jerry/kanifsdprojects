import React from "react"
import {useLocation, useNavigate} from 'react-router-dom';

function Home2 (){
    const location=useLocation()

    return (
        <div className="homepage">

            <h1>Pls login to continue</h1>

        </div>
    )
}

export default Home2