import React, { useState } from "react";
import EmptyList from "../BlogList/EmptyList";
import BlogList from "../BlogList/BlogList";
import { blogList } from "../Configuration/Data";

const Home = () => {
  const [blogs, ] = useState(blogList);

  return (
<div>
      {!blogs.length ? <EmptyList /> : <BlogList blogs={blogs} />}
    </div>
  );
};

export default Home;