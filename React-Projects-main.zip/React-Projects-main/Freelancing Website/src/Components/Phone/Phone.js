import React from 'react'
import PhoneImage from './PhoneImage'
import HowDoesItWork from './HowDoesItWork'

const Phone = () => {
  return (
    <div>
    <br />
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-6"><PhoneImage/></div>
        <div className="col-6"><HowDoesItWork/></div>
      </div>
    </div>
  </div>
  )
}

export default Phone