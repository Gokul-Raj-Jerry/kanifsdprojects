import React from "react";

const Results = () => {
  return (
    <div>
      <h1>Still not convinced? Check out the results!</h1>
      <h2>
        Here are just some of the things you could get done on Developers Inc.com.
        For more completed projects, visit our Project Showcase.
      </h2>
    </div>
  );
};

export default Results;
