import React from "react";

const Statistics = () => {
  return (
    <div>
        <br/>
      <h3 style={{ color: "blue" }}>14-DAY HISTORY • TOP 15</h3>     <br/>
      <img
      style={{width: 1349}}
        src="https://jupiter.money/blog/wp-content/uploads/2022/08/19.-Investment_strategies_for_beginners-1.jpg"
        alt=""
      />
    </div>
  );
};

export default Statistics;
