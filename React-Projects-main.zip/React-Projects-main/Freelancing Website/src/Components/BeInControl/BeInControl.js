import React from 'react'
import Content from './Content'
import PhoneImage from './PhoneImage'

const BeInControl = () => {
  return (
    <div>
    <br />
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-6"><Content/></div>
        <div className="col-6"><PhoneImage/></div>
      </div>
    </div>
  </div>
  )
}

export default BeInControl;