import React from 'react'
import Phone from "../../Resources/Phone2.webp";

const PhoneImage = () => {
  return (
    <div><img style={{marginLeft: -50, width: 550, height: 500}} src={Phone} alt=""/></div>
  )
}

export default PhoneImage;