import React from "react";
import BrowsePortfolio from "./BrowsePortfolio";
import FastBids from "./FastBids";
import QualityWork from "./QualityWork";
import TrackProgress from "./TrackProgress";

const WhatsGreatAboutIt = () => {
  return (
    <div>
      <br />
      <h1 style={{ fontWeight: "bolder" }}>
        &nbsp;&nbsp;&nbsp;&nbsp;What's great about it?
      </h1>
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-3">
            <BrowsePortfolio />
          </div>
          <div className="col-3">
            <FastBids />
          </div>
          <div className="col-3">
            <QualityWork />
          </div>
          <div className="col-3">
            <TrackProgress />
          </div>
        </div>{" "}
      </div>
    </div>
  );
};

export default WhatsGreatAboutIt;
