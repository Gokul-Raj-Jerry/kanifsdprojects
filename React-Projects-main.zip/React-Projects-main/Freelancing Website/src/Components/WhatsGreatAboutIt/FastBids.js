import React from 'react'
import Fast from "../../Resources/bids-alt.svg"

const FastBids = () => {
  return (
    <div><div className="text-center">
    <img src={Fast} alt="" />  
    <h3>Fast bids</h3><br/>
    <p>
    Receive obligation free quotes from our talented freelancers fast. 80% of projects get bid on within 60 seconds.
    </p> </div>
  </div>
  )
}

export default FastBids