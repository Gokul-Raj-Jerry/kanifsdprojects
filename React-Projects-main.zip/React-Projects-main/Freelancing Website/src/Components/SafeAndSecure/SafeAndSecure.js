import React from 'react'
import Content from './Content'
import Safety from './Safety'

const SafeAndSecure = () => {
  return (
    <div>
    <br />
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-6"><Safety/></div>
        <div className="col-6"><Content/></div>
      </div>
    </div>
  </div>
  )
}

export default SafeAndSecure;