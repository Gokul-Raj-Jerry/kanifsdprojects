import React from 'react'
import Safe from "../../Resources/safety.webp";

const Safety = () => {
  return (
    <div><img style={{marginLeft: -50, width: 550, height: 500}} src={Safe} alt=""/></div>
  )
}

export default Safety;