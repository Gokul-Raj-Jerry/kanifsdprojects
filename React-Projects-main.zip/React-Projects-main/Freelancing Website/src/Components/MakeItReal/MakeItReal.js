import React from "react";

const MakeItReal = () => {
  return (
    <div>
      <br />
      <h1 style={{ fontWeight: "bolder" }}>
        &nbsp;&nbsp;&nbsp;&nbsp;Make it Real with Developers Inc.
      </h1><br/>
      <h5>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Get some Inspirations from 1800+ skills</h5>
    </div>
  );
};

export default MakeItReal;
