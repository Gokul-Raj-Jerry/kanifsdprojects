import React, { useState, useEffect, useContext } from "react";
import "../../Styles/styles.css";
import { Link, useNavigate } from "react-router-dom";
import OtpInput from "react-otp-input";
import axios from "axios";
import { RecoveryContext } from "../../App";

const ResetPassword = () => {
  const [OTPinput, setOTPinput] = useState([0, 0, 0, 0]);
  const { email, setEmail, otp, setOtp, setPage } = useContext(RecoveryContext);
  /*   const [otp, setOtp] = useState(''); */
  /*   const [email, setEmail] = useState(""); */
  const [timerCount, setTimerCount] = useState(60);
  const [disable, setDisable] = useState(true);
  const [enteredEmailIsTouched, setEnteredEmailIsTouched] = useState(false);
  const [formIsValid, setFormIsValid] = useState(false);
  const navigate = useNavigate();
  const [err, setErr] = useState(false);
  /*   const enteredEmailIsValid = email.trim() !== ""; */
  const enteredEmailIsValid = email !== "";
  const emailInputIsInvalid = !enteredEmailIsValid && enteredEmailIsTouched;

  function verfiyOTP() {
    if (parseInt(OTPinput.join("")) === otp) {
      setPage("GenerateNewPassword");
      return;
    }
    alert(
      "The code you have entered is not correct, try again or re-send the link"
    );
    return;
  }

  function resendOTP() {
    if (disable) return;
    axios
      .post("http://localhost:5000/resetPassword", {
        OTP: otp,
        recipient_email: email,
      })
      .then(() => setDisable(true))
      .then(() => alert("A new OTP has succesfully been sent to your email."))
      .then(() => setTimerCount(60))
      .catch(console.log);
  }

  useEffect(() => {
    let interval = setInterval(() => {
      setTimerCount((lastTimerCount) => {
        lastTimerCount <= 1 && clearInterval(interval);
        if (lastTimerCount <= 1) setDisable(false);
        if (lastTimerCount <= 0) return lastTimerCount;
        return lastTimerCount - 1;
      });
    }, 1000); //each count lasts for a second
    //cleanup the interval on complete
    return () => clearInterval(interval);
  }, [disable]);

  useEffect(() => {
    if (enteredEmailIsValid) {
      setFormIsValid(true);
    } else {
      setFormIsValid(false);
    }
  }, [enteredEmailIsValid]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setEnteredEmailIsTouched(true);
    if (!enteredEmailIsValid) return;

    try {
      navigate("/");
    } catch (err) {
      setErr(true);
    }
    setEnteredEmailIsTouched(false);
    setEmail("");
  };

  const emailInputBlurHandler = () => {
    setEnteredEmailIsTouched(true);
  };

  return (
    <div className="formContainer">
      <div className="formWrapper">
        <div className="text-center">
          {" "}
          {/*  <img style={{ width: 30, height: 30 }} src={BlogIcon} alt="" /> &nbsp;
          &nbsp; */}
          <h3 style={{ color: "black", fontWeight: "bolder" }}>
            Developers Inc.
          </h3>
        </div>
        <span style={{ fontWeight: "bolder", fontSize: 20 }}>
          Email Verification
        </span>
        <span style={{ fontWeight: "bolder", fontSize: 16 }}>
          We have sent a code to your email id {email}
        </span>
        <form onSubmit={handleSubmit}>
            <div className="form-group">
          {/*      <input
            style={{ width: 300 }}
            className="emailInput"
            onChange={(e) => setEmail(e.target.value)}
            onBlur={emailInputBlurHandler}
            value={email}
            type="email"
            placeholder="Email"
          /> 
              <OtpInput
                value={otp}
                onChange={setOtp}
                numInputs={4}
                renderSeparator={<span>-</span>}
                renderInput={(props) => <input {...props} />}
              />{" "}
 */}

<div className="flex flex-row items-center justify-between mx-auto w-full max-w-xs">
                  <div className="w-16 h-16 ">
                    <input
                      maxLength="1"
                      className="w-full h-full flex flex-col items-center justify-center text-center px-5 outline-none rounded-xl border border-gray-200 text-lg bg-white focus:bg-gray-50 focus:ring-1 ring-blue-700"
                      type="text"
                      name=""
                      id=""
                      onChange={(e) =>
                        setOTPinput([
                          e.target.value,
                          OTPinput[1],
                          OTPinput[2],
                          OTPinput[3],
                        ])
                      }
                    ></input>
                  </div>
                  <div className="w-16 h-16 ">
                    <input
                      maxLength="1"
                      className="w-full h-full flex flex-col items-center justify-center text-center px-5 outline-none rounded-xl border border-gray-200 text-lg bg-white focus:bg-gray-50 focus:ring-1 ring-blue-700"
                      type="text"
                      name=""
                      id=""
                      onChange={(e) =>
                        setOTPinput([
                          OTPinput[0],
                          e.target.value,
                          OTPinput[2],
                          OTPinput[3],
                        ])
                      }
                    ></input>
                  </div>
                  <div className="w-16 h-16 ">
                    <input
                      maxLength="1"
                      className="w-full h-full flex flex-col items-center justify-center text-center px-5 outline-none rounded-xl border border-gray-200 text-lg bg-white focus:bg-gray-50 focus:ring-1 ring-blue-700"
                      type="text"
                      name=""
                      id=""
                      onChange={(e) =>
                        setOTPinput([
                          OTPinput[0],
                          OTPinput[1],
                          e.target.value,
                          OTPinput[3],
                        ])
                      }
                    ></input>
                  </div>
                  <div className="w-16 h-16 ">
                    <input
                      maxLength="1"
                      className="w-full h-full flex flex-col items-center justify-center text-center px-5 outline-none rounded-xl border border-gray-200 text-lg bg-white focus:bg-gray-50 focus:ring-1 ring-blue-700"
                      type="text"
                      name=""
                      id=""
                      onChange={(e) =>
                        setOTPinput([
                          OTPinput[0],
                          OTPinput[1],
                          OTPinput[2],
                          e.target.value,
                        ])
                      }
                    ></input>
                  </div>
                </div>
            {emailInputIsInvalid && (
              <span className="text-danger">
                {" "}
                <br />
                Reset Email must not be empty
              </span>
            )}
          </div>
          <br />
          <button
            style={{ width: 300, backgroundColor: "orangeRed", color: "white" }}
            type="submit"
            onClick={() => verfiyOTP()}
            disabled={!formIsValid}
          >
            Verify Account
          </button>
          <br />
          {err && <span>Something went wrong!</span>}
        </form>
        <br />
        <span>
          Didn't receive code?
          <a
            href=""
            className="flex flex-row items-center"
            style={{
              color: disable ? "gray" : "blue",
              cursor: disable ? "none" : "pointer",
              textDecorationLine: disable ? "none" : "underline",
            }}
            onClick={() => resendOTP()}
          >
            {disable ? `Resend OTP in ${timerCount}s` : "Resend OTP"}
          </a>
        </span>
      </div>
    </div>
  );
};

export default ResetPassword;
