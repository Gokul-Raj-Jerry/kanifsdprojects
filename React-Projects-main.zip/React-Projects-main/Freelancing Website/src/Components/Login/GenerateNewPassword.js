import React, { useContext, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { RecoveryContext } from "../../App";

const GenerateNewPassword = () => {
  const { setPage } = useContext(RecoveryContext);
  function changePassword() {
    setPage("recovered");
  }
  const [password1, setPassword1] = useState("");
  const [password2, setPassword2] = useState("");
  const [enteredPassword1IsTouched, setPassword1IsTouched] = useState(false);
  const [enteredPassword2IsTouched, setPassword2IsTouched] = useState(false);
  const [formIsValid, setFormIsValid] = useState(false);
  const navigate = useNavigate();
  const [err, setErr] = useState(false);
  const enteredPassword1IsValid = password1.trim() !== "";
  const enteredPassword2IsValid = password2.trim() !== "";
  const password1InputIsInvalid = !enteredPassword1IsValid && enteredPassword1IsTouched;
  const password2InputIsInvalid = !enteredPassword2IsValid && enteredPassword2IsTouched;

  useEffect(() => {
    if (enteredPassword1IsValid) {
      setFormIsValid(true);
    } else {
      setFormIsValid(false);
    }
  }, [enteredPassword1IsValid]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setPassword1IsTouched(true);
    if (!enteredPassword1IsValid) return;
    setPassword2IsTouched(true);
    if (!enteredPassword2IsValid) return;

    try {
      navigate("/");
    } catch (err) {
      setErr(true);
    }
    setPassword1IsTouched(false);
    setPassword2IsTouched(false);
    setPassword1("");
    setPassword2("");
  };

  const password1InputBlurHandler = () => {
    setPassword1IsTouched(true);
  };

  const password2InputBlurHandler = () => {
    setPassword2IsTouched(true);
  };

  const generateNewPasswordHandler = () => {

  };

  return (
    <div className="formContainer">
      <div className="formWrapper">
        <div className="text-center">
          {/*  <img style={{ width: 30, height: 30 }} src={BlogIcon} alt="" /> &nbsp;
            &nbsp; */}
          <h3 style={{ color: "black", fontWeight: "bolder" }}>
            Developers Inc.
          </h3>
        </div>
        <span style={{ fontWeight: "bolder", fontSize: 20 }}>
          Change Password
        </span>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <input
              style={{ width: 300 }}
              className="emailInput"
              onChange={(e) => setPassword1(e.target.value)}
              onBlur={password1InputBlurHandler}
              value={password1}
              type="email"
              placeholder="New Password"
            />
            {password1InputIsInvalid && (
              <span className="text-danger">
                {" "}
                <br />
                New Password must not be empty
              </span>
            )}
          </div>
       <div className="form-group">
            <input
              style={{ width: 300 }}
              className="emailInput"
              onChange={(e) => setPassword2(e.target.value)}
              onBlur={password2InputBlurHandler}
              value={password2}
              type="text"
              placeholder="Confirm Password"
            />
            {password2InputIsInvalid && (
              <span className="text-danger">
                {" "}
                <br />
                Confirm Password must not be empty
              </span>
            )}
          </div>
          <div className="form-check">
            &nbsp;
            <input
              disabled={!formIsValid}
              className="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <label className="form-check-label" htmlFor="flexCheckDefault">
              I accept to the <Link to="">Terms and Conditions
              </Link>
           
            </label>{" "}
          </div>
          <button
          onClick={changePassword}
            style={{ width: 300, backgroundColor: "orangeRed", color: "white" }}
            type="submit"
            disabled={!formIsValid}
          >
            Reset Password
          </button>
          {err && <span>Something went wrong!</span>}
        </form>
      </div>
    </div>
  );
};

export default GenerateNewPassword;
