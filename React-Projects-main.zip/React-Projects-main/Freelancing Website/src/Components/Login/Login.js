import React, { useState, useEffect, useContext } from "react";
import "../../Styles/styles.css";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios"
import RecoveryContext from "../../App"

const Login = () => {
  const { setEmail, email, otp1, setOtp1, page, setPage } = useContext(RecoveryContext);
/*   const [email, setEmail] = useState(""); */
  const [password, setPassword] = useState("");
  const [enteredEmailIsTouched, setEnteredEmailIsTouched] = useState(false);
  const [enteredPasswordIsTouched, setEnteredPasswordIsTouched] =
    useState(false);
  const [formIsValid, setFormIsValid] = useState(false);
  const history = useNavigate();
  const navigate = useNavigate();
  const [err, setErr] = useState(false);

  const enteredEmailIsValid = email.trim() !== "";
  const enteredPasswordIsValid = password.trim() !== "";
  const emailInputIsInvalid = !enteredEmailIsValid && enteredEmailIsTouched;
  const passwordInputIsInvalid =
    !enteredPasswordIsValid && enteredPasswordIsTouched;

  useEffect(() => {
    if (enteredEmailIsValid && enteredPasswordIsValid) {
      setFormIsValid(true);
    } else {
      setFormIsValid(false);
    }
  }, [enteredEmailIsValid, enteredPasswordIsValid]);

  const submitForm = async (event) => {
    event.preventDefault();
    setEnteredEmailIsTouched(true);
    if (!enteredEmailIsValid) return;
    setEnteredPasswordIsTouched(true);
    if (!enteredPasswordIsValid) return;
    try{

      await axios.post("http://localhost:5000/login",{
          email,password
      })
      .then(res=>{
          if(res.data=="exist"){
              history("/",{state:{id:email}})
          }
          else if(res.data=="notexist"){
              alert("User have not sign up")
          }
      })
      .catch(e=>{
          alert("wrong details")
          console.log(e);
      })

  }
  catch(e){
      console.log(e);

  }
    setEnteredEmailIsTouched(false);
    setEnteredPasswordIsTouched(false);
    setEmail("");
    setPassword("");
  };

  const emailInputBlurHandler = () => {
    setEnteredEmailIsTouched(true);
  };

  const passwordInputBlurHandler = () => {
    setEnteredPasswordIsTouched(true);
  };

  function forgotPasswordHandler() {
    if (email) {
      const OTP = Math.floor(Math.random() * 9000 + 1000);
      console.log(OTP);
      setOtp1(OTP);
      axios
        .post("http://localhost:5000/resetPassword", {
          OTP,
          recipient_email: email,
        })
        .then(() => setPage("otp"))
        .catch(console.log);
      return;
    }
    return alert("Please enter your email");
  }

  return (
    <div className="formContainer">
      <div className="formWrapper">
        <div className="text-center">
          {" "}
          {/*         <img style={{ width: 30, height: 30 }} src={BlogIcon} alt="" /> &nbsp;
          &nbsp;  */}
          <h3 style={{ color: "black", fontWeight: "bolder" }}>
            Developers Inc.
          </h3>
        </div>
        <span style={{ fontWeight: "bolder", fontSize: 20 }}>Welcome Back</span>
        <button
          style={{
            width: 300,
            color: "white",
            backgroundColor: "#3b5998",
          }}
          type="submit"
          disabled={!formIsValid}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            fill="currentColor"
            className="bi bi-facebook"
            viewBox="0 0 16 16"
          >
            <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z" />
          </svg>
          &nbsp;&nbsp;Log in with Facebook
        </button>
        <div style={{ fontWeight: "bolder", fontSize: 15 }}> OR</div>
        <form action="POST" onSubmit={submitForm}>
          <div className="form-group">
            <input
              style={{ width: 300 }}
              className="emailInput"
              onChange={(e) => setEmail(e.target.value)}
              onBlur={emailInputBlurHandler}
              value={email}
              type="email"
              placeholder="Email"
            />
            {emailInputIsInvalid && (
              <span className="text-danger">
                {" "}
                <br />
                Email must not be empty
              </span>
            )}
          </div>
          <div className="form-group pwd-container">
            <input
              style={{ width: 300 }}
              type="password"
              className="emailInput"
              onChange={(e) => setPassword(e.target.value)}
              onBlur={passwordInputBlurHandler}
              value={password}
              placeholder="Password"
            />
            {passwordInputIsInvalid && (
              <span className="text-danger">
                {" "}
                <br />
                Password must not be empty
              </span>
            )}
            <br /> <br />
          </div>
          <div className="form-check">
            &nbsp;
            <input
              className="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <label className="form-check-label" htmlFor="flexCheckDefault">
              Remember Me
            </label>{" "}
            &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{" "}
            <Link onClick={forgotPasswordHandler} to="/resetPassword">Forgot Password?</Link>
          </div>
          <button
            style={{ width: 300, backgroundColor: "orangeRed", color: "white" }}
            type="submit"
            disabled={!formIsValid}
          >
            Log In
          </button>
          {err && <span>Something went wrong!</span>}
          <hr />
        </form>
        <span>
          Don't have an account? <Link to="/signup">Sign Up</Link>
        </span>
      </div>
    </div>
  );
};

export default Login;
