const images = [{
    id: 1,
    src: "https://img.freepik.com/free-photo/html-css-collage-concept-with-person_23-2150062008.jpg?w=740&t=st=1689840516~exp=1689841116~hmac=ccaad77c1300879e5479f56022edc435e1b8caef47284ed1cc3208e36b4cf077",
    alt: "Image 1"
},
{
    id: 2,
    src: "https://img.freepik.com/free-photo/manager-woman-using-laptop-tablet-same-time-working-financial-reports_482257-7704.jpg?w=740&t=st=1689840648~exp=1689841248~hmac=2707099c411b0f6d5a131b34ff54ba25e2ac8d6b6a159dd616f89094067d2ac2",
    alt: "Image 2 "
},
{
    id: 3,
    src: "https://img.freepik.com/free-photo/manager-woman-using-laptop-tablet-same-time-working-financial-reports_482257-7704.jpg?w=740&t=st=1689840648~exp=1689841248~hmac=2707099c411b0f6d5a131b34ff54ba25e2ac8d6b6a159dd616f89094067d2ac2",
    alt: "Image 3"
},
{
    id: 4,
    src: "https://img.freepik.com/premium-photo/crypto-trader-investor-analyst-looking-computer-screen-analyzing-financial-chart-data-pc-laptop-monitor-thinking-about-global-risks-online-stock-exchange-trading-investment-trading_189498-5847.jpg?w=740",
    alt: "Image 4"
}
];
export default images;