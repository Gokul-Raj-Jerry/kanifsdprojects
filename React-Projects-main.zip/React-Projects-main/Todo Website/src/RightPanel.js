import { Sidebar, Menu, MenuItem, useProSidebar } from "react-pro-sidebar";
import {Link} from "react-router-dom"
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import PeopleOutlinedIcon from "@mui/icons-material/PeopleOutlined";
import ContactsOutlinedIcon from "@mui/icons-material/ContactsOutlined";
import ReceiptOutlinedIcon from "@mui/icons-material/ReceiptOutlined";
import CalendarTodayOutlinedIcon from "@mui/icons-material/CalendarTodayOutlined";
import HelpOutlineOutlinedIcon from "@mui/icons-material/HelpOutlineOutlined";
import MenuOutlinedIcon from "@mui/icons-material/MenuOutlined";
import { useState, useEffect } from "react";
import "./App.css"
import {
  Add,
  FlagOutlined,
  FoodBankOutlined,
  Mood,
  RunCircleOutlined,
  Search,
} from "@mui/icons-material";


const RightPanel = () => {
  const { collapseSidebar, toggleSidebar, collapsed, toggled, broken, rtl } =
  useProSidebar();

const toggle = () => {
  toggleSidebar();
  if (toggled) {
    console.log(true);
    collapseSidebar();
  } else {
    console.log(false);
    collapseSidebar();
  }
};
  return (
    <div id="rightbar">
<Sidebar
breakPoint="sm"
transitionDuration={800}
backgroundColor="white"
rtl={false}
style={{ height: "100vh" }}
>
{/* {!broken && ( */}
<Menu>
  <MenuItem
    icon={<MenuOutlinedIcon />}
    // onClick={() => {
    //   collapseSidebar();
    // }}
    onClick={() => {
      toggle();
    }}
  >
    <h2>To Do</h2>
  </MenuItem>
  <MenuItem icon={<Search />}>
    <input
      style={{ width: 145, height: 30 }}
      type="search"
      placeholder="Search"
    />
  </MenuItem>

  <Link style={{textDecoration: 'none'}} to="/myDay"><MenuItem icon={<Mood />}>My Day</MenuItem></Link>
  <MenuItem icon={<PeopleOutlinedIcon />}><Link style={{textDecoration: 'none'}} to="/important">Important</Link></MenuItem>
  <MenuItem icon={<ContactsOutlinedIcon />}><Link style={{textDecoration: 'none'}} to="/planned">Planned</Link></MenuItem>
  <MenuItem icon={<ReceiptOutlinedIcon />}><Link style={{textDecoration: 'none'}} to="/assignedToMe">Assigned To Me</Link></MenuItem>
  <MenuItem icon={<FlagOutlined />}><Link style={{textDecoration: 'none'}} to="/flaggedEmail">Flagged Email</Link></MenuItem>
  <MenuItem icon={<CalendarTodayOutlinedIcon />}><Link style={{textDecoration: 'none'}} to="/tasks">Tasks</Link></MenuItem>
  <MenuItem icon={<RunCircleOutlined />}><Link style={{textDecoration: 'none'}} to="/gettingStarted">Getting Started</Link></MenuItem>
  <MenuItem icon={<FoodBankOutlined />}><Link style={{textDecoration: 'none'}} to="/groceries">Groceries</Link></MenuItem>
  <MenuItem icon={<Add />}><Link style={{textDecoration: 'none'}} to="/newList">New List</Link></MenuItem>
</Menu>
</Sidebar>
</div>
  )
}

export default RightPanel;