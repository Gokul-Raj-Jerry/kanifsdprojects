import { Sidebar, Menu, MenuItem, useProSidebar } from "react-pro-sidebar";
import React, { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import PeopleOutlinedIcon from "@mui/icons-material/PeopleOutlined";
import ContactsOutlinedIcon from "@mui/icons-material/ContactsOutlined";
import ReceiptOutlinedIcon from "@mui/icons-material/ReceiptOutlined";
import CalendarTodayOutlinedIcon from "@mui/icons-material/CalendarTodayOutlined";
import MenuOutlinedIcon from "@mui/icons-material/MenuOutlined";
import "./App.css";
import { BsSearch } from "react-icons/bs";
import {
  Add,
  FlagOutlined,
  FoodBankOutlined,
  Mood,
  RunCircleOutlined,
  Search,
} from "@mui/icons-material";
const productList = [
  "My Day",
  "Important",
  "Planned",
  "Assigned To Me",
  "Flagged Email",
  "Tasks",
  "Getting Started",
  "Groceries",
  "New List",
];

const SidePanel = () => {
  const [products, setProducts] = useState(productList);
  const [searchVal, setSearchVal] = useState("");
  const handleSearchClick = () => {
    if (searchVal === "") {
      setProducts(productList);
      return;
    }
    const filterBySearch = productList.filter((item) => {
      if (item.toLowerCase().includes(searchVal.toLowerCase())) {
        return item;
      }
    });
    setProducts(filterBySearch);
  };

  const mystyle = {
    marginLeft: "-45px",
    marginTop: "20px",
    fontWeight: "700",
  };

  const { collapseSidebar, toggleSidebar, toggled /* broken, /* rtl */ } =
    useProSidebar();

  const toggle = () => {
    toggleSidebar();
    if (toggled) {
      collapseSidebar();
    } else {
      collapseSidebar();
    }
  };

  const myDayHandler = () => {
    const variable = document.getElementById("important").remove();
   /*  console.log(variable); */
  };

  const importantHandler = () => {
    console.log(products,"HANDKER")
 /* document.getElementById("myDay").remove();
 document.getElementById("planned").remove();
 document.getElementById("tasks").remove();
 */
    /* const variable1 = */ /* document.getElementById("assignedToMe").remove(); */
    /* const variable2 = */ /* document.getElementById("flaggedEmail").remove(); */
   /*  const variable3 = */ /* document.getElementById("gettingStarted").remove(); */
    /* const variable4 = */ /* document.getElementById("groceries").remove(); */
    /* const variable5 = */ /* document.getElementById("newList").remove(); */
/*     const variable6 = document.getElementById("myDay").remove();
    const variable7 = document.getElementById("myDay").remove();
    const variable8 = document.getElementById("myDay").remove(); */
  };

  return (
    <div id="sidebar">
      <Sidebar
        breakPoint="sm"
        transitionDuration={800}
        backgroundColor="white"
        rtl={false}
        style={{ height: "100vh", padding: 0 }}
      >
        <Menu>
          <MenuItem
            icon={<MenuOutlinedIcon />}
            // onClick={() => {
            //   collapseSidebar();
            // }}
            onClick={() => {
              toggle();
            }}
          >
            <h2>To Do</h2>
          </MenuItem>
          <MenuItem /* icon={<Search /> */>
            <div /* style={mystyle} */>
              <input
                /* style={{ width: 145, height: 30 }} */
                type="search"
                onKeyPress={handleSearchClick}
                onChange={(e) => setSearchVal(e.target.value)}
                placeholder="Search"
              />
              <BsSearch onClick={handleSearchClick} />
            </div>
            {searchVal == "" ? (
              <>
                <Link style={{ textDecoration: "none" }} to="/myDay">
                  <MenuItem icon={<Mood />}>My Day</MenuItem>
                </Link>
                <br />
                <MenuItem icon={<PeopleOutlinedIcon />}>
                  <Link style={{ textDecoration: "none" }} to="/important">
                    Important
                  </Link>
                </MenuItem>
                <br />
                <MenuItem icon={<ContactsOutlinedIcon />}>
                  <Link style={{ textDecoration: "none" }} to="/planned">
                    Planned
                  </Link>
                </MenuItem>
                <br />
                <MenuItem icon={<ReceiptOutlinedIcon />}>
                  <Link style={{ textDecoration: "none" }} to="/assignedToMe">
                    Assigned To Me
                  </Link>
                </MenuItem>
                <br />
                <MenuItem icon={<FlagOutlined />}>
                  <Link style={{ textDecoration: "none" }} to="/flaggedEmail">
                    Flagged Email
                  </Link>
                </MenuItem>
                <br />
                <MenuItem icon={<CalendarTodayOutlinedIcon />}>
                  <Link style={{ textDecoration: "none" }} to="/tasks">
                    Tasks
                  </Link>
                </MenuItem>
                <br />
                <MenuItem icon={<RunCircleOutlined />}>
                  <Link style={{ textDecoration: "none" }} to="/gettingStarted">
                    Getting Started
                  </Link>
                </MenuItem>
                <br />
                <MenuItem icon={<FoodBankOutlined />}>
                  <Link style={{ textDecoration: "none" }} to="/groceries">
                    Groceries
                  </Link>
                </MenuItem>
                <br />
                <MenuItem icon={<Add />}>
                  <Link style={{ textDecoration: "none" }} to="/newList">
                    New List
                  </Link>
                </MenuItem>{" "}
              </>
            ) : (
              products.map((product) => {
                /*     console.log(product)  */
                return (
                  <>
                    <MenuItem onChange={myDayHandler} id="myDay" style={mystyle}>
                      {product === "My Day" ? (
                        <Link style={{ textDecoration: "none" }} to="/myDay">
                          <MenuItem icon={<Mood />}>My Day</MenuItem>
                        </Link>
                      ) : (
                        <>  </>
                      )}
                    </MenuItem>
                    <br />
                    <MenuItem onChange={myDayHandler} id="important" style={mystyle}>
                      {product === "Important" ? (
                        <Link style={{ textDecoration: "none" }} to="/important">
                          <MenuItem icon={<Mood />}>Important</MenuItem>
                        </Link>
                      ) : (
                        <>  </>
                      )}
                    </MenuItem>
                    <br />
                    <MenuItem id="planned" style={mystyle}>
                      {product === "Planned" ? (
                        <Link style={{ textDecoration: "none" }} to="/planned">
                          <MenuItem icon={<Mood />}>Planned</MenuItem>
                        </Link>
                      ) : (
                        <> </>
                      )}
                    </MenuItem>
                    <br />
                    <MenuItem id="assignedToMe" style={mystyle}>
                      {product === "Assigned To Me" ? (
                        <Link
                          style={{ textDecoration: "none" }}
                          to="/assignedToMe"
                        >
                          <MenuItem icon={<Mood />}>Assigned To Me</MenuItem>
                        </Link>
                      ) : (
                        <>  </>
                      )}
                    </MenuItem>
                    <br />
                    <MenuItem id="flaggedEmail" style={mystyle}>
                      {product === "Flagged Email" ? (
                        <Link
                          style={{ textDecoration: "none" }}
                          to="/flaggedEmail"
                        >
                          <MenuItem icon={<Mood />}>Flagged Email</MenuItem>
                        </Link>
                      ) : (
                        <> </>
                      )}
                    </MenuItem>
                    <br />
                    <MenuItem id="tasks" style={mystyle}>
                      {product === "Tasks" ? (
                        <Link style={{ textDecoration: "none" }} to="/tasks">
                          <MenuItem icon={<Mood />}>Tasks</MenuItem>
                        </Link>
                      ) : (
                        <> </>
                      )}
                    </MenuItem>
                    <br />
                    <MenuItem id="gettingStarted" style={mystyle}>
                      {product === "Getting Started" ? (
                        <Link
                          style={{ textDecoration: "none" }}
                          to="/gettingStarted"
                        >
                          <MenuItem icon={<Mood />}>Getting Started</MenuItem>
                        </Link>
                      ) : (
                        <> </>
                      )}
                    </MenuItem>
                    <br />
                    <MenuItem id="groceries" style={mystyle}>
                      {product === "Groceries" ? (
                        <Link
                          style={{ textDecoration: "none" }}
                          to="/groceries"
                        >
                          <MenuItem icon={<Mood />}>Groceries</MenuItem>
                        </Link>
                      ) : (
                        <>   </>
                      )}
                    </MenuItem>
                    <br />
                    <MenuItem id="newList" style={mystyle}>
                      {product === "New List" ? (
                        <Link style={{ textDecoration: "none" }} to="/newList">
                          <MenuItem icon={<Mood />}>New List</MenuItem>
                        </Link>
                      ) : (
                        <>   </>
                      )}
                    </MenuItem>
                    <br />
                  </>
                );
              })
            )}
          </MenuItem>
        </Menu>
      </Sidebar>
    </div>
  );
};

export default SidePanel;
