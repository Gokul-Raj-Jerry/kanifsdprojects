import "./App.css"
import { Routes, Route } from "react-router-dom";
import Home from "./Components/Home";
import Important from "./Components/Important";
import Planned from "./Components/Planned";
import AssignedToMe from "./Components/AssignedToMe";
import FlaggedEmail from "./Components/FlaggedEmail";
import Tasks from "./Components/Tasks";
import GettingStarted from "./Components/GettingStarted";
import Groceries from "./Components/Groceries";
import NewList from "./Components/NewList";

const App = () => {
  return (
    <Routes>
      <Route path="/" element={<Home/>}/>
      <Route path="/myDay" element={<Home/>}/>
      <Route path="/important" element={<Important/>}/>
      <Route path="/planned" element={<Planned/>}/>
      <Route path="/assignedToMe" element={<AssignedToMe/>}/>
      <Route path="/flaggedEmail" element={<FlaggedEmail/>}/>
      <Route path="/tasks" element={<Tasks/>}/>
      <Route path="/gettingStarted" element={<GettingStarted/>}/>
      <Route path="/groceries" element={<Groceries/>}/>
      <Route path="/newList" element={<NewList/>}/>
    </Routes>
  );
}

export default App;