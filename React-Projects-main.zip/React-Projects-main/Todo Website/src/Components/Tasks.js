import { Add, CalendarMonthOutlined, Home, Search, Star } from "@mui/icons-material";
import SidePanel from "../LeftPanel";
import "../App.css";

const Tasks = () => {
  return (
    <div
      id="app"
      style={
        ({ height: "100vh" },
        { display: "flex", flexDirection: "row", color: 'black' },
        {
          backgroundImage: `url("https://cdn.pixabay.com/photo/2018/02/08/22/27/flower-3140492_1280.jpg")`,
        })
      }
    >
      <SidePanel />
      <main>
        <div
          id="content"
          className="text-center"
          style={{ color: "white", marginLeft: "20rem" }}
        >
          <h1>
            <Home />
            Tasks
          </h1>
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
        <div className="text-center">
          <h4>
            <CalendarMonthOutlined />  
                Tasks with due dates or remainders show up here  
          </h4>    </div>    <br />        <br />        <br />        <br />        <br />        <br />        <br />
          <input
            style={{ width: 1000, height: 50 }}
            type="search"
            placeholder="+ Add a task"
          />
        </div>
      </main>
    </div>
  );
};

export default Tasks;
