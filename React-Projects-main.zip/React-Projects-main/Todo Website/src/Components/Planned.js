import { Add, CalendarMonthOutlined, Search, Star } from "@mui/icons-material";
import SidePanel from "../LeftPanel";
import "../App.css";

const Planned = () => {
  return (
    <div
      id="app"
      style={
        ({ height: "100vh" },
        { display: "flex", flexDirection: "row" },
        {
          backgroundImage: `url("https://www.hdwallpapers.in/download/pink_glittering_flower_background_hd_pink_background-1920x1080.jpg")`,
        })
      }
    >
      <SidePanel />
      <main>
        <div
          id="content"
          className="text-center"
          style={{ color: "white", marginLeft: "20rem" }}
        >
          <h1>
            <CalendarMonthOutlined />
            Planned
          </h1>
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
        <div className="text-center">
          <h4>
            <CalendarMonthOutlined />  
                Tasks with due dates or remainders show up here  
          </h4>    </div>    <br />        <br />        <br />        <br />        <br />        <br />        <br />
          <input
            style={{ width: 1000, height: 50 }}
            type="search"
            placeholder="+ Add a task"
          />
        </div>
      </main>
    </div>
  );
};

export default Planned;
