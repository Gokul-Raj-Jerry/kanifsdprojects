import { Add, CalendarMonthOutlined, FlagOutlined, Search, Star } from "@mui/icons-material";
import SidePanel from "../LeftPanel";
import "../App.css";

const FlaggedEmail = () => {
  return (
    <div
      id="app"
      style={
        ({ height: "100vh" },
        { display: "flex", flexDirection: "row", color: 'black' },
        {
          backgroundColor: 'red',
        })
      }
    >
      <SidePanel />
      <main>
        <div
          id="content"
          className="text-center"
          style={{ color: "white", marginLeft: "20rem" }}
        >
          <h1>
            <FlagOutlined />
            Flagged Email
          </h1>
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
        <div className="text-center">
          <h4>
            <FlagOutlined />  
                Messages you flag will show up as tasks here  
          </h4>    </div>    <br />        <br />        <br />        <br />        <br />        <br />        <br />
      
        </div>
      </main>
    </div>
  );
};

export default FlaggedEmail;
