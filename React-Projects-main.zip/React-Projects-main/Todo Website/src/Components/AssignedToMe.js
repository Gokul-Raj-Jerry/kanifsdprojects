import { Add, CalendarMonthOutlined, GirlOutlined, Person, Search, Star } from "@mui/icons-material";
import SidePanel from "../LeftPanel";
import "../App.css";
import React, { useState } from 'react';
import { BsSearch } from 'react-icons/bs';

const AssignedToMe = () => {
  const [products, setProducts] = useState(productList);
  const [searchVal, setSearchVal] = useState("");
  const productList = ["My Day"
        , "Important"
        , "Planned"
        , "Assigned To Me"
        , "Flagged Email"
        , "Tasks"
        , "Getting Started"
        , "Groceries"
        , "New List"];
        function handleSearchClick() {
          if (searchVal === "") { setProducts(productList); return; }
          const filterBySearch = productList.filter((item) => {
              if (item.toLowerCase()
                  .includes(searchVal.toLowerCase())) { return item; }
          })
          setProducts(filterBySearch);
      }
      const mystyle = {
        marginLeft: "600px",
        marginTop: "20px",
        fontWeight: "700"
    };

  return (
    <div class="bg-image" 
    style={({backgroundImage: `url('https://cdn.pixabay.com/photo/2018/02/08/22/27/flower-3140492_1280.jpg')`,
           height: '100vh',
           position: 'fixed',
           display: "flex",flexDirection: "row",
           backgroundSize: 'cover',
           })}>
{/*     <div
       id="app" 
      class="bg-image"
      style={
        ({ height: "100vh" },
        { display: "flex", flexDirection: "row", color: 'black' },
        {
          backgroundImage: `url("https://cdn.pixabay.com/photo/2018/02/08/22/27/flower-3140492_1280.jpg")`,
        })
      }
    >  */}
      <SidePanel />
      <main>
        <div
          id="content"
        /*   className="text-center" */
          style={{ color: "white", marginLeft: "5rem", marginRight: "50rem"}}
        >
          <h1>
            <Person />
            Assigned To Me
          </h1>
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
        <div className="text-center">
          <h4>
            <GirlOutlined />  
                Tasks assigned to you appear here  
          </h4>    </div>    <br />        <br />        <br />        <br />        <br />        <br />        <br />
      
        </div>
        <div style={mystyle}>
                <input onChange={e => setSearchVal(e.target.value)}>
                </input>
                <BsSearch onClick={handleSearchClick} />
            </div>
            <div>
  
                {products.map((product) => {
                    return (
                        <div style={mystyle}>{product}</div>
                    )
                })
                }
  
            </div>
      </main>
    </div>
  );
};

export default AssignedToMe;
