import SidePanel from "../LeftPanel";
import "../App.css";
import { CalendarMonthOutlined } from "@mui/icons-material";
import { useState } from "react";
import RightPanel from "../RightPanel";

const Home = () => {
  const [selectedInput, setSelectedInput] = useState("+ Add a task");

  const date = new Date();
  let currentDay = String(date.getDate()).padStart(2, "0");
  let currentMonth = String(date.getMonth() + 1).padStart(2, "0");
  let currentYear = date.getFullYear();
  let currentDate = `${currentDay}-${currentMonth}-${currentYear}`;
  console.log("The current date is " + currentDate);

  const placeholderHandler = () => {
    setSelectedInput("Type something like Submit report by Friday 3PM");
  };

  return (
    <div class="bg-image" 
     style={({backgroundImage: `url('https://images5.alphacoders.com/344/344289.jpg')`,
            height: '100vh',
            position: 'fixed',
            display: "flex",flexDirection: "row",
            backgroundSize: 'cover',
            })}>
{/*      <div
      id="app"
      className="bg-image"
      style={
        ({ height: '100vh', position: 'fixed', backgroundSize: 50 },
        { display: "flex", flexDirection: "row" },
        {
          backgroundImage: `url("https://images5.alphacoders.com/344/344289.jpg")`,
          backgroundSize: 'cover'
        })
      }
    >  */}
      <SidePanel />
      <main>
        <div id="content" style={{ color: "white", marginLeft: "5rem", marginRight: "10rem" }}>
          <h1>My Day</h1>
          <h2>{currentDate}</h2>
          <br />
          <br />
          <br />
          <br />
          <br />
          <div style={{ textAlign: "center" }}>
            <CalendarMonthOutlined />
            <h3>Focus on your day</h3>
            <h4>
              Get things done with my Day, a list <br />
              that refreshes everyday
            </h4>{" "}
          </div>

          <input
            style={{ width: 1000, height: 50, marginBottom: 0 }}
            type="search"
            placeholder={selectedInput}
            onClick={placeholderHandler}
          />
        </div>
      </main>
   {/*    <RightPanel/> */}
    </div>
  );
};

export default Home;
