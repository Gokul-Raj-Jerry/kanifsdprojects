import { Add, CalendarMonthOutlined, Search, Star } from "@mui/icons-material";
import SidePanel from "../LeftPanel";
import "../App.css";

const Groceries = () => {
  return (
    <div
      id="app"
      style={
        ({ height: "100vh" },
        { display: "flex", flexDirection: "row", color: "black" },
        {
          backgroundImage: `url("https://cdn.pixabay.com/photo/2018/02/08/22/27/flower-3140492_1280.jpg")`,
        })
      }
    >
      <SidePanel />
      <main>
        <div
          id="content"
          className="text-center"
          style={{ color: "white", marginLeft: "20rem" }}
        >
          <h1>
            <CalendarMonthOutlined />
            Groceries
          </h1>
          <br />
          <input
            style={{ width: 1000, height: 50 }}
            type="search"
            placeholder="Milk"
            readOnly
          />
          <br /> <br />
          <input
            style={{ width: 1000, height: 50 }}
            type="search"
            placeholder="Bread"
            readOnly
          />{" "}
          <br /> <br />
          <input
            style={{ width: 1000, height: 50 }}
            type="search"
            placeholder="Potatoes"
            readOnly
          />{" "}
          <br /> <br />
          <input
            style={{ width: 1000, height: 50 }}
            type="search"
            placeholder="Bananas"
            readOnly
          />{" "}
          <br /> <br />
          <input
            style={{ width: 1000, height: 50 }}
            type="search"
            placeholder="Butter"
            readOnly
          />
        </div>
      </main>
    </div>
  );
};

export default Groceries;
