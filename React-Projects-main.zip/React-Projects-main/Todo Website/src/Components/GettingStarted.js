import { Add, CalendarMonthOutlined, Search, Star } from "@mui/icons-material";
import SidePanel from "../LeftPanel";
import "../App.css";
import { Radio } from "@mui/material";

const Planned = () => {
  return (
    <div
      id="app"
      style={
        ({ height: "100vh" },
        { display: "flex", flexDirection: "row", color: 'black' },
        {
          backgroundImage: `url("https://cdn.pixabay.com/photo/2018/02/08/22/27/flower-3140492_1280.jpg")`,
        })
      }
    >
      <SidePanel />
      <main>
        <div
          id="content"
          className="text-center"
          style={{ color: "white", marginLeft: "20rem" }}
        >
          <h1>
            <CalendarMonthOutlined />
            Getting Started
          </h1>
          <br /> <input
            style={{ width: 1000, height: 50 }}
            type="search"
            placeholder="Add your first task by clicking on + Add a task"
            readOnly
          />
         <br />  <br /> 
            <input
            style={{ width: 1000, height: 50 }}
            type="search"
            placeholder="Select this task to add a remainder and due date"
            readOnly
          /> <br />  <br /> 
               <input
            style={{ width: 1000, height: 50 }}
            type="search"
            placeholder="Break this task into smaller steps"
            readOnly
          />    <br />  <br /> 
            <input
          style={{ width: 1000, height: 50 }}
          type="search"
          placeholder="Open this task's detail view to add it to My Day☀️"
          readOnly
        /> <br />  <br /> 
            <input
          style={{ width: 1000, height: 50 }}
          type="search"
          placeholder="Add hastags to a task's title to categorise it"
          readOnly
        /> <br />  <br /> 
            <input
          style={{ width: 1000, height: 50 }}
          type="search"
          placeholder="Check out our simple grocery list and customize it for yourself"
          readOnly
        /> <br />  <br /> 
            <input
          style={{ width: 1000, height: 50 }}
          type="search"
          placeholder="Check all the circles in the list to complete your tasks✅"
          readOnly
        /> <br />  <br /> 
           <input
      style={{ width: 1000, height: 50 }}
      type="search"
      placeholder="+ Add a task"
    />
        </div>
      </main>
    </div>
  );
};

export default Planned;
