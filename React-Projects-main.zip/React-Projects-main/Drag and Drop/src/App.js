import DragAndDrop from "./DragAndDrop";

function App() {
  return <DragAndDrop />;
}

export default App;