import React from "react";
import styles from "./Modal.module.css";
import { RiCloseLine } from "react-icons/ri";
import { Link } from "react-router-dom";
const Modal = ({ setIsOpen }) => {
  return (
    <>
      <div className={styles.darkBG} onClick={() => setIsOpen(false)} />
      <div className={styles.centered}>
        <div className={styles.modal}>
          <div className={styles.modalHeader}>
            <h5 className={styles.heading}>Login</h5>
          </div>
          <button className={styles.closeBtn} onClick={() => setIsOpen(false)}>
            <RiCloseLine style={{ marginBottom: "-3px" }} />
          </button>
          <div className={styles.modalContent}>
            <input placeholder="Enter Email/Phone number" type="text" />
            <br />
            <br />
            <div>
              By continuing, you agree to Flipkart's Terms of Use and Privacy
              Policy.
            </div>
          </div>
          <div className={styles.modalActions}>
            <div className={styles.actionsContainer}>
              <button
                className={styles.deleteBtn}
                onClick={() => {
                  setIsOpen(false);
                }}
              >
                Request OTP
              </button>
              <Link
                className={styles.cancelBtn}
                onClick={() => setIsOpen(false)}
              >
                New to Flipkart? Create an account
              </Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Modal;