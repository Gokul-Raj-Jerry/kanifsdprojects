import React, { useState } from "react";
import "./styles.css";
import HeaderImage from "../Assets/HeaderImages/HeaderImage.jpg";
import FlipkartImage from "../Assets/HeaderImages/flipkart-plus_8d85f4.png";
import HeaderCartButton from "./HeaderCartButton";
import classes from "./Header.module.css";
import Select, { components } from "react-select";
import { Link } from "react-router-dom";
import * as Icon from "react-bootstrap-icons";
import ImageSlider from "../Carousel/ImageSlider";
import images from "../Carousel/CarouselImages";
/* import Modal from "react-overlays/Modal"; */
import styles from "../../App.module.css";
import Modal from "../../Modal/Modal";
import OtpInput from 'react-otp-input';

const options = [
  { value: "mobiles", label: "Mobiles" },
  { value: "shoes", label: "Shoes" },
  { value: "tshirts", label: "t shirts" },
  { value: "laptops", label: "Laptops" },
  { value: "watches", label: "Watches" },
  { value: "tv", label: "tv" },
  { value: "sarees", label: "Sarees" },
];

const customStyles = {
  control: (base) => ({
    ...base,
    width: 500,
  }),
};

/*   const DropdownIndicator = props => {
    return (
      components.DropdownIndicator && (
        <components.DropdownIndicator {...props}>
          <FontAwesomeIcon icon={props.selectProps.menuIsOpen ? "caret-up" : "caret-down"}/>
        </components.DropdownIndicator>
      )
    );
  }; */


const Header = (props) => {
  const [showModal, setShowModal] = useState(false);
  const [otp, setOtp] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  const [selectedOption, setSelectedOption] = useState(null);
  const renderBackdrop = (props) => <div className="backdrop" {...props} />;

  var handleClose = () => setShowModal(false);

var handleSave = () => {
  console.log("success");
};


var handleSuccess = () => {
  console.log("success");
};
  return (
    <React.Fragment>
      <header className={classes.header}>
        <h6 style={{ width: 200/* , marginLeft: 30 */ }}>
          {" "}
          <img
            style={{ width: 80, height: 15 }}
            src={FlipkartImage}
            alt="flipkart"
          />
          <br />
          <Link
            style={{ textDecoration: "none", width: 80, height: 10 }}
            className="link-warning"
            to="/plus"
          >
            Explore Plus
          </Link>
        </h6>
        <Select
          styles={customStyles}
          placeholder="Search for products, brands and more"
          isSearchable
          defaultValue={selectedOption}
          onChange={setSelectedOption}
          options={options}
        />{" "}
        &nbsp; &nbsp; &nbsp; &nbsp;
       {/*  <button type="button" className={styles.primaryBtn} onClick={() => setIsOpen(true)} class="btn btn-light ">
          Login
        </button>  */} 
        <nav class="navbar navbar-default">
  <div class="container-fluid">
      <ul class="nav navbar-nav">
        <li class="dropdown">
          <button href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Login {/* <span class="caret"></span> */}</button>
          <ul class="dropdown-menu">
            <li><Link to="/signup">New Customer? Sign Up</Link></li>
            <li><a href="#">My Profile</a></li>
            <li><a href="#">Flipkart Plus Zone</a></li>
            <li><a href="#">Orders</a></li>
            <li><a href="#">Wishlist</a></li>
            <li><a href="#">Rewards</a></li>
            <li><a href="#">Gift Cards</a></li>
         {/*    <li role="separator" class="divider"></li>
            <li><a href="#">Separated link</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="#">One more separated link</a></li> */}
          </ul>
        </li>
      </ul>
  </div>
</nav>  {isOpen && <Modal setIsOpen={setIsOpen} />}
        &nbsp; &nbsp; &nbsp; &nbsp;
        <h6>Become a Seller</h6> &nbsp; &nbsp;
        <h6>
          More
        </h6>
        &nbsp; &nbsp;&nbsp; &nbsp;
        <HeaderCartButton onClick={props.onShowCart} />
      </header>{" "}
      &nbsp; &nbsp;
      {/*   <div  className={classes['main-image']} >
            <img style={{ width: 1500, height:400}} src={HeaderImage} alt="headericon"/>
        </div>  */}
      <ImageSlider images={images} />
      <OtpInput
      value={otp}
      onChange={setOtp}
      numInputs={10}
      renderSeparator={<span>-</span>}
      renderInput={(props) => <input {...props} />}
    />

    </React.Fragment>
  );
};

export default Header;