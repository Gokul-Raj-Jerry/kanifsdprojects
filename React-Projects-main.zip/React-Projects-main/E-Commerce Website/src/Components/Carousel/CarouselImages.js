import FirstImage from "../../Assets/FirstImage.jpeg";
import SecondImage from "../../Assets/SecondImage.webp";
import ThirdImage from "../../Assets/ThirdImage.jpg";

const images = [{
    id: 1,
    src: "https://www.apple.com/v/iphone/home/bo/images/meta/iphone__ky2k6x5u6vue_og.png",
    alt: "Image 1"
},
{
    id: 2,
    src: "https://m.media-amazon.com/images/S/aplus-media-library-service-media/18b0c619-53c5-4031-b1fe-62e051bdf441.__CR0,0,970,600_PT0_SX970_V1___.jpg",
    alt: "Image 2 "
},
{
    id: 3,
    src: "https://images.hindustantimes.com/img/2023/02/03/1600x900/Indigo-recorded_1675424472908_1675424473122_1675424473122.jpg",
    alt: "Image 3"
},
{
    id: 4,
    src: "https://assets-prd.ignimgs.com/2023/04/17/best-iphones-to-buy-2-1681764220182.jpg",
    alt: "Image 4"
},
{
    id: 5,
    src: "https://www.nykaa.com/beauty-blog/wp-content/uploads/images/issue203/natural-beauty-OI.jpg",
    alt: "Image 5"
}
];
export default images;