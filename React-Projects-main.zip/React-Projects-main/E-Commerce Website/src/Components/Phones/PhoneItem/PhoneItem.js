import CartContext from "../../../store/cart-context";
import classes from "./PhoneItem.module.css";
import PhoneItemForm from "./PhoneItemForm";
import { useContext } from "react";
const PhoneItem = (props) => {
  const cartCtx = useContext(CartContext);
  const price = `$${props.price.toFixed(2)}`;
  const addToCartHandler = (amount) => {
    cartCtx.addItem({
      id: props.id,
      name: props.name,
      amount: amount,
      price: props.price,
    });
  };
  return (
    <li className={classes.meal}>
      <div>
        <h3>{props.name}</h3>
        <img src={props.image} alt="" />
        <div className={classes.description}>{props.rating}</div>
        <div className={classes.price}>{price}</div>
      </div>
      <div>
        <PhoneItemForm id={props.id} onAddToCart={addToCartHandler} />
      </div>
    </li>
  );
};

export default PhoneItem;
