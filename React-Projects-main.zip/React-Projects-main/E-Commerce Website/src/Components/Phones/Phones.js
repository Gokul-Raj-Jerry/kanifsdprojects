import Item1 from "../Assets/ItemsImages/Item1.webp";
import Item2 from "../Assets/ItemsImages/Item2.webp";
import Item3 from "../Assets/ItemsImages/Item3.webp";
import Item4 from "../Assets/ItemsImages/Item4.webp";
import Item5 from "../Assets/ItemsImages/Item5.webp";
import Item6 from "../Assets/ItemsImages/Item6.webp";
import Item7 from "../Assets/ItemsImages/Item7.webp";
import Item8 from "../Assets/ItemsImages/Item8.webp";
import Item9 from "../Assets/ItemsImages/Item9.webp";
import Item10 from "../Assets/ItemsImages/Item10.webp";
import React, { useState } from "react";
import Heart from "react-animated-heart";
import * as Icon from "react-bootstrap-icons";
import Card from "../UI/Card";
import PhoneItem from "./PhoneItem/PhoneItem";

const AVAILABLE_PHONES = [
  {
    id: "p1",
    name: "SAMSUNG Galaxy A73 5G (Awesome Mint, 128 GB)",
    image: { Item1 },
    rating: 4.6,
    price: 1245.8,
  },
  {
    id: "p2",
    name: "SAMSUNG Galaxy A33 (Awesome Blue, 128 GB)",
    image: { Item2 },
    rating: 4.4,
    price: 1854.3,
  },
  {
    id: "p3",
    name: "POCO X5 Pro 5G (Astral Black, 256 GB)",
    image: { Item3 },
    rating: 4.1,
    price: 1423.8,
  },
  {
    id: "p4",
    name: "MOTOROLA g31 (Meteorite Grey, 64 GB)",
    image: { Item4 },
    rating: 4.6,
    price: 1523.9,
  },
  {
    id: "p5",
    name: "APPLE iPhone 14 (Purple, 128 GB)",
    image: { Item5 },
    rating: 4.4,
    price: 1254.7,
  },
  {
    id: "p6",
    name: "Realme C30 - Locked with Airtel Prepaid (Denim Black, 32 GB)",
    image: { Item6 },
    rating: 4.9,
    price: 1752.4,
  },
  {
    id: "p7",
    name: "SAMSUNG Galaxy Z Flip3 5G (Phantom Black, 128 GB)",
    image: { Item7 },
    rating: 3.9,
    price: 1985.2,
  },
  {
    id: "p8",
    name: "vivo V27 5G (Magic Blue, 128 GB)",
    image: { Item8 },
    rating: 4.9,
    price: 1289.6,
  },
  {
    id: "p9",
    name: "APPLE iPhone 14 Plus (Blue, 128 GB)",
    image: { Item9 },
    rating: 4.2,
    price: 1274.9,
  },
  {
    id: "p10",
    name: "SAMSUNG Galaxy F04 (Opal Green, 64 GB)",
    image: { Item10 },
    rating: 3.9,
    price: 1425.1,
  },
];
const Items = () => {
  const [isClick, setClick] = useState(false);

  const phonesList = AVAILABLE_PHONES.map((phone) => (
    <PhoneItem
      id={phone.id}
      key={phone.id}
      name={phone.name}
      image={phone.image}
      rating={phone.rating}
      price={phone.price}
    />
  ));
  return (
    <>
      {/*     <section className={classes.meals}> */}
      <Card>
        <ul>{phonesList}</ul>
      </Card>
      {/*     </section> */}
      {/*   <div class="container">
        <div class="row">
            <div class="card-group">
            <div class="col-4">
              <div class="card text-center">
                <div className="text-center"> 
                <img
                  style={{ width: 100, height: 150 }}
                  class="card-img-top"
                  src={phonesList.image}
                  alt="phone1"
                />    <Heart isClick={isClick} onClick={() => setClick(!isClick)} />
                 </div> 
                <div class="card-body">
                  <h5 class="card-title">{phonesList}</h5>
                  <button type="button" class="btn btn-success btn-sm">4.6 <Icon.StarFill/></button> <p>(1526)</p>  </div>
                  <div class="card-footer">
                  <button type="button" class="btn btn-primary">Add to Cart</button> 
                  </div>
                </div>
              </div>
            </div>   </div>   </div>  */}
      {/*      <div class="col-4">
              <div class="card  text-center">  <div className="text-center"> 
                <img
                  style={{ width: 100, height: 150 }}
                  class="card-img-top"
                  src={Item2}
                  alt="phone2"
                />
                <Heart isClick={isClick} onClick={() => setClick(!isClick)} />
                </div>
                <div class="card-body">
                  <h5 class="card-title">SAMSUNG Galaxy A33 (Awesome Blue, 128 GB)</h5>
                  <button type="button" class="btn btn-success btn-sm">4.6 <Icon.StarFill/></button> <p>(1526)</p>
                  <div class="card-footer">
                  <button type="button" class="btn btn-primary">Add to Cart</button> 
                  </div>
                </div>
              </div>{" "}
            </div>
            <div class="col-4">
              <div class="card text-center">
              <div className="text-center"> 
                <img
                  style={{ width: 100, height: 150 }}
                  class="card-img-top"
                  src={Item3}
                  alt="phone3"
                />
                <Heart isClick={isClick} onClick={() => setClick(!isClick)} />
                </div>
                <div class="card-body">
                  <h5 class="card-title">POCO X5 Pro 5G (Astral Black, 256 GB)</h5>
                  <button type="button" class="btn btn-success btn-sm">4.6 <Icon.StarFill/></button> <p>(1526)</p>
                  <div class="card-footer">
                  <button type="button" class="btn btn-primary">Add to Cart</button> 
                  </div>
                </div>
              </div>
            </div>
            <div class="col-4">
              <div class="card text-center">
              <div className="text-center"> 
                <img
                  style={{ width: 100, height: 150 }}
                  class="card-img-top"
                  src={Item4}
                  alt="phone4"
                />
                <Heart isClick={isClick} onClick={() => setClick(!isClick)} />
                </div>
                <div class="card-body">
                  <h5 class="card-title">MOTOROLA g31 (Meteorite Grey, 64 GB)</h5>
                  <button type="button" class="btn btn-success btn-sm">4.6 <Icon.StarFill/></button> <p>(1526)</p>
                  <div class="card-footer">
                  <button type="button" class="btn btn-primary">Add to Cart</button> 
                  </div>
                </div>
              </div>{" "}
            </div>
            <div class="col-4">
              <div class="card text-center">   <div className="text-center"> 
                <img
                  style={{ width: 100, height: 150 }}
                  class="card-img-top"
                  src={Item5}
                  alt="phone5"
                />
                <Heart isClick={isClick} onClick={() => setClick(!isClick)} />
                </div>
                <div class="card-body">
                  <h5 class="card-title">APPLE iPhone 14 (Purple, 128 GB)</h5>
                  <button type="button" class="btn btn-success btn-sm">4.6 <Icon.StarFill/></button> <p>(1526)</p>
                  <div class="card-footer">
                  <button type="button" class="btn btn-primary">Add to Cart</button> 
                  </div>
                </div>
              </div>{" "}
            </div>
            <div class="col-4">
              <div class="card text-center">   <div className="text-center"> 
                <img
                  style={{ width: 100, height: 150 }}
                  class="card-img-top"
                  src={Item6}
                  alt="phone6"
                />
                <Heart isClick={isClick} onClick={() => setClick(!isClick)} />
                </div>
                <div class="card-body">
                  <h5 class="card-title">Realme C30 - Locked with Airtel Prepaid (Denim Black, 32 GB)</h5>
                  <button type="button" class="btn btn-success btn-sm">4.6 <Icon.StarFill/></button> <p>(1526)</p>
                  <div class="card-footer">
                  <button type="button" class="btn btn-primary">Add to Cart</button> 
                  </div>
                </div>
              </div>{" "}
            </div>
            <div class="col-4">
              <div class="card text-center">   <div className="text-center"> 
                <img
                  style={{ width: 100, height: 150 }}
                  class="card-img-top"
                  src={Item7}
                  alt="phone7"
                />
                <Heart isClick={isClick} onClick={() => setClick(!isClick)} />
                </div>
                <div class="card-body">
                  <h5 class="card-title">SAMSUNG Galaxy Z Flip3 5G (Phantom Black, 128 GB)</h5>
                  <button type="button" class="btn btn-success btn-sm">4.6 <Icon.StarFill/></button> <p>(1526)</p>
                  <div class="card-footer">
                  <button type="button" class="btn btn-primary">Add to Cart</button> 
                  </div>
                </div>
              </div>{" "}
            </div>
            <div class="col-4">
              <div class="card text-center">   <div className="text-center"> 
                <img
                  style={{ width: 100, height: 150 }}
                  class="card-img-top"
                  src={Item8}
                  alt="phone8"
                />
                <Heart isClick={isClick} onClick={() => setClick(!isClick)} />
                </div>
                <div class="card-body">
                  <h5 class="card-title">vivo V27 5G (Magic Blue, 128 GB)</h5>
                  <button type="button" class="btn btn-success btn-sm">4.6 <Icon.StarFill/></button> <p>(1526)</p>
                  <div class="card-footer">
                  <button type="button" class="btn btn-primary">Add to Cart</button> 
                  </div>
                </div>
              </div>{" "}
            </div>{" "}
            <div class="col-4">
              <div class="card text-center">   <div className="text-center"> 
                <img
                  style={{ width: 100, height: 150 }}
                  class="card-img-top"
                  src={Item9}
                  alt="phone9"
                />
                <Heart isClick={isClick} onClick={() => setClick(!isClick)} />
                </div>
                <div class="card-body">
                  <h5 class="card-title">APPLE iPhone 14 Plus (Blue, 128 GB)</h5>
                  <button type="button" class="btn btn-success btn-sm">4.6 <Icon.StarFill/></button> <p>(1526)</p>
                  <div class="card-footer">
                  <button type="button" class="btn btn-primary">Add to Cart</button> 
                  </div>
                </div>
              </div>{" "}
            </div>{" "}
            <div class="col-4">
              <div class="card text-center">   <div className="text-center"> 
                <img
                  style={{ width: 100, height: 150 }}
                  class="card-img-top"
                  src={Item10}
                  alt="phone10"
                />
                <Heart isClick={isClick} onClick={() => setClick(!isClick)} />
                </div>
                <div class="card-body">
                  <h5 class="card-title">SAMSUNG Galaxy F04 (Opal Green, 64 GB)</h5>
                  <button type="button" class="btn btn-success btn-sm">4.6 <Icon.StarFill/></button> <p>(1526)</p>
                  <div class="card-footer">
                  <button type="button" class="btn btn-primary">Add to Cart</button> 
                  </div>
                </div>
              </div>{" "}
            </div> 
          </div>
      </div>
      </div> */}
    </>
  );
};

export default Items;
