import React, { useState } from "react";
import Header from "./Components/Header/Header";
import Items from "./Components/Phones/Phones";
import Cart from "./Components/Cart/Cart";
import CartProvider from "./store/cartProvider";
import { BrowserRouter, Routes, Route } from "react-router-dom/dist";

const App = () => {

  const [cartIsShown, setcartIsShown] = useState(false);
  const showCartHandler = () => {
    setcartIsShown(false);
  };

  const hideCartHandler = () => {
    setcartIsShown(false);
  };

  return (
    <BrowserRouter>
    <CartProvider>
      {cartIsShown && <Cart onClose={hideCartHandler} />}
      <Header onShowCart={showCartHandler} />
      <main>
        <Items />
      </main>
    </CartProvider>
    </BrowserRouter>
  );
}

export default App;