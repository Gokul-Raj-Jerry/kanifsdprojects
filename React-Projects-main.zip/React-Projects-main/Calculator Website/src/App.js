import { useState } from "react";
import { useSelector, useDispatch } from "react-redux";

const App = () => {
  const [addValue1, setAddValue1] = useState("");
  const [addValue2, setAddValue2] = useState("");
  const [subValue1, setSubValue1] = useState("");
  const [subValue2, setSubValue2] = useState("");
  const [mulValue1, setMulValue1] = useState("");
  const [mulValue2, setMulValue2] = useState("");
  const [divValue1, setDivValue1] = useState("");
  const [divValue2, setDivValue2] = useState("");
  const dispatch = useDispatch();
  const additionResult = useSelector((state) => state.additionResult)
  const subtractionResult = useSelector((state) => state.subtractionResult)
  const multiplicationResult = useSelector(
    (state) => state.multiplicationResult
  );
  const divisionResult = useSelector((state) => state.divisionResult);
  const additionHandlerInput1 = (event) => {
    setAddValue1(event.target.value);
  };

  const additionHandlerInput2 = (event) => {
    setAddValue2(event.target.value);
  };
  const subtractionHandlerInput1 = (event) => {
    setSubValue1(event.target.value);
  };

  const subtractionHandlerInput2 = (event) => {
    setSubValue2(event.target.value);
  };
  const multiplicationHandlerInput1 = (event) => {
    setMulValue1(event.target.value);
  };

  const multiplicationHandlerInput2 = (event) => {
    setMulValue2(event.target.value);
  };
  const divisionHandlerInput1 = (event) => {
    setDivValue1(event.target.value);
  };

  const divisionHandlerInput2 = (event) => {
    setDivValue2(event.target.value);
  };

  const additionHandler = () => {
    dispatch({
      type: "add",
      payload: parseInt(addValue1),
      payload2: parseInt(addValue2),
    });
    setAddValue1("");
    setAddValue2("");
  };

  const subtractionHandler = () => {
    dispatch({
      type: "sub",
      payload: parseInt(subValue1),
      payload2: parseInt(subValue2),
    });
  };

  const multiplicationHandler = () => {
    dispatch({
      type: "mul",
      payload: parseInt(mulValue1),
      payload2: parseInt(mulValue2),
    });
  };

  const divisionHandler = () => {
    dispatch({
      type: "div",
      payload: parseInt(divValue1),
      payload2: parseInt(divValue2),
    });
  };

  return (
    <>
      <div className="text-center">
        <h1>Calculator App</h1>
        <br />
        <label>Addition</label> &nbsp;
        <input
          onChange={additionHandlerInput1}
          value={addValue1}
          type="number"
        />
        &nbsp;
        <button>+</button> &nbsp;
        <input
          onChange={additionHandlerInput2}
          value={addValue2}
          type="number"
        />
        &nbsp;
        <button onClick={additionHandler}>= </button> &nbsp;&nbsp;
        {additionResult ? additionResult : '0'} <br /> <br />
        <label>Subtraction</label> &nbsp;
        <input
          onChange={subtractionHandlerInput1}
          value={subValue1}
          type="number"
        />
        &nbsp;
        <button>-</button> &nbsp;
        <input
          onChange={subtractionHandlerInput2}
          value={subValue2}
          type="number"
        />
        &nbsp;
        <button onClick={subtractionHandler}>= </button> &nbsp;&nbsp;
        {subtractionResult} <br /> <br />
        <label>Multiplication</label> &nbsp;
        <input
          onChange={multiplicationHandlerInput1}
          value={mulValue1}
          type="number"
        />
        &nbsp;
        <button>*</button> &nbsp;
        <input
          onChange={multiplicationHandlerInput2}
          value={mulValue2}
          type="number"
        />
        &nbsp;
        <button onClick={multiplicationHandler}>= </button> &nbsp;&nbsp;
        {multiplicationResult} <br /> <br />
        <label>Division</label> &nbsp;
        <input
          onChange={divisionHandlerInput1}
          value={divValue1}
          type="number"
        />
        &nbsp;
        <button>/</button> &nbsp;
        <input
          onChange={divisionHandlerInput2}
          value={divValue2}
          type="number"
        />
        &nbsp;
        <button onClick={divisionHandler}>= </button> &nbsp;&nbsp;
        {divisionResult}<br/> <br/><br/>
        <h1>Thank You for using my Calculator!🙂😊</h1>
      </div>
    </>
  );
};

export default App;
