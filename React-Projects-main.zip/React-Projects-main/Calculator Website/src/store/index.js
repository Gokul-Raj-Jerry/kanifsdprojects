const { createStore } = require("redux");

const initialValue = {
  result: 0,
  additionResult: 0,
  subtractionResult: 0,
  multiplicationResult: 0,
  divisionResult: 0,
};

const calcReducer = (state = initialValue, action) => {
  if (action.type === "add") {
    return {
        additionResult: action.payload + action.payload2,
    };
  }
  if (action.type === "sub") {
    return {
        subtractionResult: action.payload - action.payload2,
    };
  }
  if (action.type === "mul") {
    return {
        multiplicationResult: action.payload * action.payload2,
    };
  }
  if (action.type === "div") {
    return {
        divisionResult: action.payload / action.payload2,
    };
  }
  return state;
};

const store = createStore(calcReducer);

export default store;
