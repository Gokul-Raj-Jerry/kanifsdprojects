import { useState, useEffect } from "react";
import Geocode from "react-geocode";
import "./index.css";
import axios from "axios";
const App = () => {
  const [time, setTime] = useState();
  const [lat, setLat] = useState([]);
  const [long, setLong] = useState([]);
  const [data, setData] = useState({});
  const [location, setLocation] = useState("");

  const url = `https://api.openweathermap.org/data/2.5/weather?q=${location}&units=imperial&appid=895284fb2d2c50a520ea537456963d9c`;

  const searchLocation = (event) => {
    if (event.key === "Enter") {
      axios.get(url).then((response) => {
        setData(response.data);
        console.log(response.data, "RESPONSEDATA");
      });
      setLocation("");
    }
  };

  var days = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ];
  var months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
  var today = new Date();
  const currentDay = days[new Date().getDay()];
  const currentMonth = months[new Date().getMonth()];
  var minutesTwoDigitsWithLeadingZero = ("0" + today.getMinutes()).substr(-2);
  var secondsTwoDigitsWithLeadingZero = ("0" + today.getSeconds()).substr(-2);
  const currentTime =
    today.getHours() +
    ":" +
    minutesTwoDigitsWithLeadingZero +
    ":" +
    secondsTwoDigitsWithLeadingZero;
  const date = today.getDate() + " " + currentMonth + " " + today.getFullYear();

  useEffect(() => {
    setTimeout(() => {
      setTime(new Date());
    }, 1000);
  }, [currentTime]);

  useEffect(() => {
    const fetchData = async () => {
      navigator.geolocation.getCurrentPosition(function (position) {
        setLat(position.coords.latitude);
        setLong(position.coords.longitude);
      });

      await fetch(
        `${process.env.REACT_APP_API_URL}/weather/?lat=${lat}&lon=${long}&units=metric&APPID=${process.env.REACT_APP_API_KEY}`
      )
        .then((res) => res.json())
        .then((result) => {
          setData(result);
          console.log(result, "RESULT");
        });
    };
    fetchData();
  }, [lat, long]);

  Geocode.setApiKey("895284fb2d2c50a520ea537456963d9c");
  Geocode.setLanguage("en");

  Geocode.fromLatLng(lat, long).then(
    (response) => {
      const address = response.results[0].formatted_address;
      console.log(address, "ADDRESS");
    },
    (error) => {
      console.error(error);
    }
  );

  return (
    <>
      <div className="text-center text-dark">
        <h1 className="text-dark">Weather App</h1>
        <h2>{currentTime}</h2>
        <h2>
          {currentDay}, {date}
        </h2>
        <br />
        <div class="search">
          <input
            value={location}
            onChange={(event) => setLocation(event.target.value)}
            onKeyPress={searchLocation}
            placeholder=" Enter Location"
            type="text"
          />
        </div>{" "}
      </div>
      <br />
      <div className="text-center text-light">
        <div className="location">
          <p>{data.name}</p>
        </div>
        {data.main ? (
          <p>Temparature - {data.main.temp.toFixed()}°F ☀️</p>
        ) : null}
        {data.weather ? <p>Weather - {data.weather[0].main} 🌦️</p> : null}
        {data.name !== undefined && (
          <div className="text-center">
            {data.main ? (
              <p>
                Feels Like - {data.main.feels_like.toFixed()}°F{" "}
                {data.main.feels_like.toFixed() < 100 ? "😍" : "😟"}
              </p>
            ) : null}

            {data.main ? <p>Humidity - {data.main.humidity}% ☔</p> : null}

            {data.wind ? (
              <p>Wind Speed - {data.wind.speed.toFixed()} MPH 🍃</p>
            ) : null}
          </div>
        )}
      </div>
    </>
  );
};

export default App;