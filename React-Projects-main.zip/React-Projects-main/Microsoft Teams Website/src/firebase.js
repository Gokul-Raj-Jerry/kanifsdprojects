import { getAuth} from "firebase/auth";
import { initializeApp } from "firebase/app";
import { getStorage } from "firebase/storage";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyDct12hToVRWMpbeXhjHzzFSlm95dAae0c",
  authDomain: "course-project-354513.firebaseapp.com",
  projectId: "course-project-354513",
  storageBucket: "course-project-354513.appspot.com",
  messagingSenderId: "620264690272",
  appId: "1:620264690272:web:042ba6965a0a860f59e905"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth();
export const storage = getStorage();
export const db = getFirestore();