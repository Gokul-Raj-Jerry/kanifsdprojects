import React, {useContext} from "react";
import { useSelector } from "react-redux";
import { ListItem } from "@material-ui/core";
import { AuthContext } from "../context/AuthContext";


export const Onlinebar = () => {
  const { isLoggedIn } = useSelector((state) => state.isLoggedIn);
  const { currentUser } = useContext(AuthContext);

  return (
    <div style={{flex: 0.9, backgroundColor: '#3e3c61'}}>
         <div className="chatInfo">
        <br/>
           &nbsp;  &nbsp;   <span style={{color:'white', fontWeight: 'bold'}}>People available now</span><br/>
           <hr/>
      {isLoggedIn === undefined ? (
          <>
            <ListItem style={{color: 'white'}}>{currentUser.displayName}    &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;🟢</ListItem>
            {
              currentUser.displayName === "Kanishka" ?
              <ListItem style={{color: 'white'}}>Priyanka    &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;    &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;🟢</ListItem>
            : 
            <ListItem style={{color: 'white'}}>Kanishka    &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;    &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;🟢</ListItem>
            }
          </>
        ) : null}
        </div>
    </div>
  );
};