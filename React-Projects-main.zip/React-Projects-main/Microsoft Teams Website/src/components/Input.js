import React, { useContext, useState } from "react";
import Img from "../img/img.png";
import Attach from "../img/attach.png";
import { AuthContext } from "../context/AuthContext";
import { ChatContext } from "../context/ChatContext";
import TypeIndicator from "../img/indicator1.gif";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import {
  arrayUnion,
  doc,
  serverTimestamp,
  setDoc,
  getDoc,
  Timestamp,
  updateDoc,
} from "firebase/firestore";
import "react-toastify/dist/ReactToastify.css";
import { db, storage } from "../firebase";
import { v4 as uuid } from "uuid";
import { getDownloadURL, ref, uploadBytesResumable } from "firebase/storage";
import { useEffect } from "react";

const Input = () => {
  const notify = () => toast("Wow so easy!");
  const [text, setText] = useState("");
  const [showIndicator, setShowIndicator] = useState(false);
  const [img, setImg] = useState(null);
  const { currentUser } = useContext(AuthContext);
  const { data } = useContext(ChatContext);
  const handleSend = async () => {
    if (img) {
      const storageRef = ref(storage, uuid());

      const uploadTask = uploadBytesResumable(storageRef, img);

      uploadTask.on(
        (error) => {
          //TODO:Handle Error
        },
        () => {
          getDownloadURL(uploadTask.snapshot.ref).then(async (downloadURL) => {
            await updateDoc(doc(db, "chats", data.chatId), {
              messages: arrayUnion({
                id: uuid(),
                text,
                senderId: currentUser.uid,
                date: Timestamp.now(),
                img: downloadURL,
              }),
            });
          });
        }
      );
    } else {
      await updateDoc(doc(db, "chats", data.chatId), {
        messages: arrayUnion({
          id: uuid(),
          text,
          senderId: currentUser.uid,
          date: Timestamp.now(),
        }),
      });
    }

    await updateDoc(doc(db, "userChats", currentUser.uid), {
      [data.chatId + ".lastMessage"]: {
        text,
      },
      [data.chatId + ".date"]: serverTimestamp(),
    });

    await updateDoc(doc(db, "userChats", data.user.uid), {
      [data.chatId + ".lastMessage"]: {
        text,
      },
      [data.chatId + ".date"]: serverTimestamp(),
    });
    checkPageStatus(text, currentUser.uid);
    setText("");
    setImg(null);
  };

  function sendNotification(text, user) {
    const notification = new Notification("New message from Microsoft Teams", {
      icon: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSKyQwAugiqIv9ZFORm5nCem0JhQXzJKKL9Jap4IWeQBT3zucQP7SI73DmGeDft0BlHnyY&usqp=CAU  ",
      body: `@${user}: ${text}`,
    });
    notification.onclick = () =>
      function () {
        window.open("http://localhost:3000");
      };
  }

  const checkPageStatus = () => {
    if (!("Notification" in window)) {
      alert("This browser does not support system notifications!");
    } else if (Notification.permission === "granted") {
      sendNotification(text, currentUser.displayName);
    } else if (Notification.permission !== "denied") {
      Notification.requestPermission((permission) => {
        if (permission === "granted") {
          sendNotification(text, currentUser.displayName);
        }
      });
    }
  };

  let status = "User is typing";

  const typingIndicator = async (e) => {
    setShowIndicator(true);
    setText(e.target.value);
    localStorage.setItem("userTyping", status);
    showIndicator &&
      (await setDoc(doc(db, "typingStatus", "typingStatus"), {
        typingStatus: true,
      }));
  };

  useEffect(() => {
    const showTyper = setTimeout(() => {
      setShowIndicator(false);
    }, 1000);
    setDoc(doc(db, "typingStatus", "typingStatus"), {
      typingStatus: false,
    });
    return () => {
      clearTimeout(showTyper);
    };
  });

  /* const status = () => { */
  /*  const docRef = doc(db, "typingStatus", "typingStatus");
  const typing =  getDocs(docRef);
  if (typing.exists()) {
    console.log("Document data:", typing.data());
  } else {
    // docSnap.data() will be undefined in this case
    console.log("No such document!");
  } */
  /* }; */

  /* console.log(status,"STATUS") */

  /* useEffect(()=>{
  const docSnap = getDoc(doc(db, "typingStatus", "typingStatus"));
      if (docSnap.exists()) {
       console.log(docSnap.data());
      } else {
        // docSnap.data() will be undefined in this case
        console.log("No such document!");
      }
    }
  ) */

  /*   const docSnap = getDoc(doc(db, "typingStatus", "typingStatus")).then(
    (docSnap) => {
      if (docSnap.exists()) {
        const status = "User is typing";
        }
       else {
        // docSnap.data() will be undefined in this case
        console.log("No such document!");
      }
    }
  ); */

  localStorage.setItem("userTyping", "");

  const typing = localStorage.getItem("userTyping");

  console.log(data, "DOCSNAP");

  return (
    <>
      <div className="input">
        {typing !== "User is typing" && showIndicator && (
          <>
            {" "}
         {/*    <span>{currentUser.displayName} is typing...</span> */}
         <div className="text-center">
         <img style={{ width: 60, borderRadius: 200, height: 45 }} src={TypeIndicator} alt="" />
         </div>
          </>
        )}
        <input
          autoComplete="off"
          id="message"
          type="text"
          placeholder="Type something...🖊️"
          value={text}
          onChange={typingIndicator}
        />

        <div className="send">
          <img src={Attach} alt="" />
          <input
            type="file"
            style={{ display: "none" }}
            id="file"
            onChange={(e) => setImg(e.target.files[0])}
          />
          <label htmlFor="file">
            <img src={Img} alt="" />
          </label>
          <button onClick={handleSend}>Send</button>
        </div>
      </div>
    </>
  );
};

export default Input;
