import { doc, onSnapshot } from "firebase/firestore";
import React, { useContext, useEffect, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import { ChatContext } from "../context/ChatContext";
import { db } from "../firebase";
import Pagination from "https://cdn.skypack.dev/rc-pagination@3.1.15";
import "./Chats.css";
import "react-toastify/dist/ReactToastify.css";
import { useSelector } from "react-redux";
import { ListItem } from "@material-ui/core";

const Chats = () => {
  const { isLoggedIn } = useSelector((state) => state.isLoggedIn);
  const [messages, setMessages] = useState([]);
  const { data } = useContext(ChatContext);
  const [read, setRead] = useState(false);
  const [textColor, setTextColor] = useState("red");
  const [chats, setChats] = useState([]);
  const { currentUser } = useContext(AuthContext);
  const { dispatch } = useContext(ChatContext);
  const [perPage] = useState(10);
  const [size, setSize] = useState(perPage);
  const [current, setCurrent] = useState(1);

  const PerPageChange = (value) => {
    setSize(value);
    const newPerPage = Math.ceil(Object.entries(chats)?.length / value);
    if (current > newPerPage) {
      setCurrent(newPerPage);
    }
  };

  const PaginationChange = (page, pageSize) => {
    setCurrent(page);
    setSize(pageSize);
  };

  const PrevNextArrow = (current, type, originalElement) => {
    if (type === "prev") {
      return (
        <button>
          <i className="fa fa-angle-double-left"></i>
        </button>
      );
    }
    if (type === "next") {
      return (
        <button>
          <i className="fa fa-angle-double-right"></i>
        </button>
      );
    }
    return originalElement;
  };

  useEffect(() => {
    const getChats = () => {
      const unsub = onSnapshot(doc(db, "userChats", currentUser.uid), (doc) => {
        setChats(doc.data());
      });

      return () => {
        unsub();
      };
    };

    currentUser.uid && getChats();
  }, [currentUser.uid]);

  const handleSelect = (u) => {
    setRead(true);
    setTextColor("white");
    dispatch({ type: "CHANGE_USER", payload: u });
  };

  useEffect(() => {
    const unSub = onSnapshot(doc(db, "chats", data.chatId), (doc) => {
      doc.exists() && setMessages(doc.data().messages);
    });

    return () => {
      unSub();
    };
  }, [data.chatId]);

  return (
    <div className="chats">
      {Object.entries(chats)
        ?.sort((a, b) => b[1].date - a[1].date)
        .map((chat) => (
          <div
            className="userChat"
            key={chat[0]}
            onClick={() => handleSelect(chat[1].userInfo)}
          >
            <img src={chat[1].userInfo?.photoURL} alt="" />
            <div className="userChatInfo">
              <span>{chat[1].userInfo?.displayName}</span>
              <p id="lastMessage">{chat[1].lastMessage?.text}</p>
              {textColor === "red" && (
                <p style={{ color: textColor }}>
                  {chat[1].lastMessage?.text.length} unread messages
                </p>
              )}
            </div>
          </div>
        ))}
      
   
   
        <br/> 
      <div id="pagination" style={{ justifyContent: "center" }}>

          <Pagination
          className="pagination-data"
          style={{ color: "white", justifyContent: "center" }}
          showTotal={(total, range) =>
         `Showing ${range[0]}-${range[1]} of ${total} chats`
          }
          onChange={PaginationChange}
          total={Object.entries(chats).length}
          current={current}
          pageSize={size}
          showSizeChanger={false}
          itemRender={PrevNextArrow}
          onShowSizeChange={PerPageChange}
        />
      </div>
    </div>
  );
};

export default Chats;
