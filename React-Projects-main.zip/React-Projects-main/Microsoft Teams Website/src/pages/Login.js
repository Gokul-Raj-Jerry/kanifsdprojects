import React, { useState, useEffect } from "react";
import "../style.scss";
import { Link, useNavigate } from "react-router-dom";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "../firebase";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [enteredEmailIsTouched, setEnteredEmailIsTouched] =
  useState(false);
  const [enteredPasswordIsTouched, setEnteredPasswordIsTouched] =
  useState(false);
  const [formIsValid, setFormIsValid] = useState(false);

  const navigate = useNavigate();
  const [err, setErr] = useState(false);

  const enteredEmailIsValid = email.trim() !== "";
  const enteredPasswordIsValid = password.trim() !== "";
  const emailInputIsInvalid = !enteredEmailIsValid && enteredEmailIsTouched;
  const passwordInputIsInvalid =!enteredPasswordIsValid && enteredPasswordIsTouched;

  useEffect(() => {
    if (
      enteredEmailIsValid &&
      enteredPasswordIsValid
    ) {
      setFormIsValid(true);
    } else {
      setFormIsValid(false);
    }
  }, [
    enteredEmailIsValid,
    enteredPasswordIsValid,
  ]);


  const handleSubmit = async (event) => {
    event.preventDefault();
    setEnteredEmailIsTouched(true);
    if (!enteredEmailIsValid) return;
    setEnteredPasswordIsTouched(true);
    if(!enteredPasswordIsValid) return;
    const email = event.target[0].value;
    const password = event.target[1].value;
    
    try {
     await signInWithEmailAndPassword(auth, email, password)
      navigate("/");
    } catch (err) {
      setErr(true);
    }
    setEnteredEmailIsTouched(false);
    setEnteredPasswordIsTouched(false);
    setEmail("");
    setPassword("");
  };

    const emailInputBlurHandler = () => {
    setEnteredEmailIsTouched(true);
  };

    const passwordInputBlurHandler = () => {
    setEnteredPasswordIsTouched(true);
  };

  return (
    <div className="formContainer">
      <div className="formWrapper">
        <span className="logo">Microsoft Teams</span>
        <span className="title">Login</span>
        <form onSubmit={handleSubmit}>
        <label>Email<span className="text-danger">*</span></label>
          <input onChange={e=>setEmail(e.target.value)} onBlur={emailInputBlurHandler} value={email} type="email" placeholder="Email" />
          {emailInputIsInvalid && <span className="text-danger">Email must not be empty</span>}
          <label>Password<span className="text-danger">*</span></label>
          <input onChange={e=>setPassword(e.target.value)} onBlur={passwordInputBlurHandler} value={password} type="password" placeholder="Password" />
          {passwordInputIsInvalid && <span className="text-danger">Password must not be empty</span>}
          <button className="btn btn-primary" type="submit" disabled={!formIsValid}>Sign in</button>
          {err && <span>Something went wrong!</span>}
        </form>
        <p>You don't have an account? <Link to="/register">Register</Link></p>
      </div>
    </div>
  );
};

export default Login;
