import React, { useState, useEffect } from "react";
import "../style.scss";
import { Link } from "react-router-dom";
import { auth, storage, db } from "../firebase";
import Add from "../img/addAvatar.png";
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";
import { doc, setDoc } from "firebase/firestore";
import { useNavigate } from "react-router-dom";

const Register = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [formIsValid, setFormIsValid] = useState(false);
  const [enteredNameIsTouched, setEnteredNameIsTouched] = useState(false);
  const [enteredEmailIsTouched, setEnteredEmailIsTouched] = useState(false);
  const [enteredPasswordIsTouched, setEnteredPasswordIsTouched] =
    useState(false);
  const navigate = useNavigate();
  const [err, setErr] = useState(false);

  const enteredNameIsValid = name.trim() !== "";
  const enteredEmailIsValid = email.trim() !== "";
  const enteredPasswordIsValid = password.trim() !== "";

  const nameInputIsInvalid = !enteredNameIsValid && enteredNameIsTouched;
  const emailInputIsInvalid = !enteredEmailIsValid && enteredEmailIsTouched;
  const passwordInputIsInvalid =
    !enteredPasswordIsValid && enteredPasswordIsTouched;

  useEffect(() => {
    if (enteredNameIsValid && enteredEmailIsValid && enteredPasswordIsValid) {
      setFormIsValid(true);
    } else {
      setFormIsValid(false);
    }
  }, [enteredEmailIsValid, enteredNameIsValid, enteredPasswordIsValid]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const displayName = event.target[0].value;
    const email = event.target[1].value;
    const password = event.target[2].value;
    const file = event.target[3].files[0];
    setEnteredNameIsTouched(true);
    if (!enteredNameIsValid) return;
    setEnteredEmailIsTouched(true);
    if (!enteredEmailIsValid) return;
    setEnteredPasswordIsTouched(true);
    if (!enteredPasswordIsValid) return;

    try {
      const res = await createUserWithEmailAndPassword(auth, email, password);
      const storageRef = ref(storage, displayName);

      const uploadTask = uploadBytesResumable(storageRef, file);

      uploadTask.on(
        (error) => {
          setErr(true);
        },
        () => {
          getDownloadURL(uploadTask.snapshot.ref).then(async (downloadURL) => {
            try {
              await updateProfile(res.user, {
                displayName,
                photoURL: downloadURL,
              });
              await setDoc(doc(db, "users", res.user.uid), {
                uid: res.user.uid,
                displayName,
                email,
                photoURL: downloadURL,
              });
              await setDoc(doc(db, "userChats", res.user.uid), {});
              navigate("/");
            } catch (err) {
              setErr(true);
            }
          });
        }
      );
    } catch (err) {
      setErr(true);
    }
    setEnteredNameIsTouched(false);
    setEnteredEmailIsTouched(false);
    setEnteredPasswordIsTouched(false);
    setName("");
    setEmail("");
    setPassword("");
  };

  const nameInputBlurHandler = () => {
    setEnteredNameIsTouched(true);
  };

  const emailInputBlurHandler = () => {
    setEnteredEmailIsTouched(true);
  };

  const passwordInputBlurHandler = () => {
    setEnteredPasswordIsTouched(true);
  };

  return (
    <div className="formContainer">
      <div className="formWrapper">
        <span className="logo">Microsoft Teams</span>
        <span className="title">Register</span>
        <form onSubmit={handleSubmit}>
          <label>Display Name<span className="text-danger">*</span></label>
          <input
            onChange={(e) => setName(e.target.value)}
            onBlur={nameInputBlurHandler}
            value={name}
            type="text"
            placeholder="Display Name"
          />
          {nameInputIsInvalid && (
            <p className="text-danger">Name must not be empty</p>
          )}
          <label>Email Address<span className="text-danger">*</span></label>
          <input
            onChange={(e) => setEmail(e.target.value)}
            onBlur={emailInputBlurHandler}
            value={email}
            type="email"
            placeholder="Email"
          />
          {emailInputIsInvalid && (
            <p className="text-danger">Email must not be empty</p>
          )}
          <label>Password<span className="text-danger">*</span></label>
          <input
            onChange={(e) => setPassword(e.target.value)}
            onBlur={passwordInputBlurHandler}
            value={password}
            type="password"
            placeholder="Password"
          />
          {passwordInputIsInvalid && (
            <p className="text-danger">Password must not be empty</p>
          )}
          <input style={{ display: "none" }} id="file" type="file" />
          <label htmlFor="file">
            <img src={Add} alt="" />
            <span>Add an Avatar</span>
          </label>
          <button
            className="btn btn-primary"
            type="button"
            disabled={!formIsValid}
          >
            Sign Up
          </button>
          {err && <span>Something went wrong!</span>}
        </form>
        <p>
          Already have an account? <Link to="/login">Login</Link>
        </p>
      </div>
    </div>
  );
};

export default Register;
