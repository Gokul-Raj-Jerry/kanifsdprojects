import Chat from "../components/Chat";
import { Onlinebar } from "../components/Onlinebar";
import { Sidebar } from "../components/Sidebar";

const Home = () => {
    return (
        <div className="home">
            <div className="container">
                <Sidebar/>
                <Chat/>
                <Onlinebar/>
            </div>
        </div>
    )
};

export default Home;